const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { useFonts } from "expo-font";
import Start from "./screens/Start";
import TestIcon from "./components/Test";
import VectorIcon from "./components/Vector";
import Chat from "./components/Chat";
import VectorIcon1 from "./components/Vector1";
import EncuentrosImage from "./components/Encuentros";
import VectorImage from "./components/Vector2";
import ShapeIcon from "./components/Shape";
import ShapeIcon1 from "./components/Shape1";
import AjustesPerfil from "./screens/AjustesPerfil";
import ExitoEliminarCuenta from "./screens/ExitoEliminarCuenta";
import ModalDeleteAccount from "./components/ModalDeleteAccount";
import AjustesSeguridad from "./screens/AjustesSeguridad";
import AjustesPlanBasico from "./screens/AjustesPlanBasico";
import AjustesPlanEstandar from "./screens/AjustesPlanEstandar";
import AjustesPlanPremium from "./screens/AjustesPlanPremium";
import AjustesPlanes from "./screens/AjustesPlanes";
import ModalLogOut from "./components/ModalLogOut";
import Ajustes1 from "./screens/Ajustes1";
import Ajustes from "./components/Ajustes";
import Sidebar from "./components/Sidebar";
import TerminosCondiciones from "./screens/TerminosCondiciones";
import PoliticaPrivacidad from "./screens/PoliticaPrivacidad";
import Register3 from "./screens/Register3";
import Register2 from "./screens/Register2";
import Register1 from "./screens/Register1";
import PassRecovery from "./components/PassRecovery";
import QuizAdentro from "./screens/QuizAdentro";
import Quizzes from "./screens/Quizzes";
import Encuentros from "./screens/Encuentros";
import HomeScreen from "./screens/HomeScreen";
import Login1 from "./components/Login1";
import Onboarding4 from "./screens/Onboarding4";
import Onboarding3 from "./screens/Onboarding3";
import Onboarding2 from "./screens/Onboarding2";
import Onboarding1 from "./screens/Onboarding1";
import Splash from "./screens/Splash";
import ZicochatConversacion from "./screens/ZicochatConversacion";
import Property1Default3 from "./components/Property1Default3";
import QuizCompletado from "./screens/QuizCompletado";
import QuizAdentroPreguntas from "./screens/QuizAdentroPreguntas";
import Zicochat from "./screens/Zicochat";
import ExitoPassRecovery from "./screens/ExitoPassRecovery";
import ModalSinSuscripcion from "./components/ModalSinSuscripcion";
import ModalTestIncompleto from "./components/ModalTestIncompleto";
import ModalWelcome from "./components/ModalWelcome";
import Property1CelesteImage from "./components/Property1CelesteImage";
import ShapeIcon11 from "./components/Shape11";
import ShapeIcon2 from "./components/Shape2";
import VectorImage1 from "./components/Vector5";
import VectorImage2 from "./components/Vector4";
import VectorIcon3 from "./components/Vector3";
import VectorIcon2 from "./components/Vector21";
import VectorIcon11 from "./components/Vector11";
import VectorIcon4 from "./components/Vector6";
import BottomNavBar3 from "./components/BottomNavBar3";
import BottomNavBar2 from "./components/BottomNavBar2";
import BottomNavBar1 from "./components/BottomNavBar1";
import BottomNavBar from "./components/BottomNavBar";
import Frame2 from "./components/Frame2";
import Frame1 from "./components/Frame1";
import Frame from "./components/Frame";
import Encuentros1 from "./components/Encuentros1";
import BarraDeNavegacin from "./components/BarraDeNavegacin";
import Component from "./components/Component";
import Component1 from "./components/Component1";
import Property1Default1 from "./components/Property1Default1";
import Component2 from "./components/Component2";
import ExitoAjustesPerfil from "./screens/ExitoAjustesPerfil";
import MIcon from "react-native-vector-icons/MaterialCommunityIcons";
import { IconRegistry, ApplicationProvider } from "@ui-kitten/components";
import * as eva from "@eva-design/eva";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import {
  View,
  Text,
  Pressable,
  TouchableOpacity,
  StyleSheet,
} from "react-native";

import { createDrawerNavigator } from "@react-navigation/drawer";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

const Drawer = createDrawerNavigator();

const Tab = createBottomTabNavigator();

function DrawerRoot({ navigation }) {
  return (
    <Drawer.Navigator
      screenOptions={{ headerShown: false, drawerStyle: { width: 260 } }}
      drawerContent={(props) => <Sidebar {...props} />}
    >
      <Drawer.Screen name="BottomTabsRoot" component={BottomTabsRoot} />
      <Drawer.Screen
        name="Ajustes1"
        component={Ajustes1}
        options={{ headerShown: false }}
      />
    </Drawer.Navigator>
  );
}
function BottomTabsRoot({ navigation }) {
  const [bottomTabItemsNormal] = React.useState([
    <ShapeIcon />,
    <EncuentrosImage />,
    <Chat />,
    <TestIcon />,
  ]);
  const [bottomTabItemsActive] = React.useState([
    <ShapeIcon1 />,
    <VectorImage />,
    <VectorIcon1 />,
    <VectorIcon />,
  ]);
  return (
    <Tab.Navigator
      screenOptions={{ headerShown: false }}
      tabBar={({ state, descriptors, navigation }) => {
        const activeIndex = state.index;
        return (
          <View
            style={{
              alignSelf: "stretch",
              backgroundColor: "#fff",
              shadowColor: "rgba(0, 0, 0, 0.1)",
              shadowOffset: {
                width: 0,
                height: -6,
              },
              shadowRadius: 15,
              elevation: 15,
              shadowOpacity: 1,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              paddingHorizontal: 30,
              paddingVertical: 20,
              height: 77,
            }}
          >
            {bottomTabItemsNormal.map((item, index) => {
              const isFocused = state.index === index;
              return (
                <Pressable
                  key={index}
                  onPress={() => {
                    navigation.navigate({
                      name: state.routes[index].name,
                      merge: true,
                    });
                  }}
                >
                  {activeIndex === index
                    ? bottomTabItemsActive[index] || item
                    : item}
                </Pressable>
              );
            })}
          </View>
        );
      }}
    >
      <Tab.Screen
        name="HomeScreen"
        component={HomeScreen}
        options={{ headerShown: false }}
      />
      <Tab.Screen
        name="Encuentros"
        component={Encuentros}
        options={{ headerShown: false }}
      />
      <Tab.Screen
        name="Zicochat"
        component={Zicochat}
        options={{ headerShown: false }}
      />
      <Tab.Screen
        name="Quizzes"
        component={Quizzes}
        options={{ headerShown: false }}
      />
    </Tab.Navigator>
  );
}

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(false);

  const [fontsLoaded, error] = useFonts({
    "Poppins-Light": require("./assets/fonts/Poppins-Light.ttf"),
    "Poppins-Regular": require("./assets/fonts/Poppins-Regular.ttf"),
    "Poppins-Medium": require("./assets/fonts/Poppins-Medium.ttf"),
    "Poppins-SemiBold": require("./assets/fonts/Poppins-SemiBold.ttf"),
    "Poppins-Bold": require("./assets/fonts/Poppins-Bold.ttf"),
    "Poppins-ExtraBold": require("./assets/fonts/Poppins-ExtraBold.ttf"),
    "Epilogue-Regular": require("./assets/fonts/Epilogue-Regular.ttf"),
    "Epilogue-Bold": require("./assets/fonts/Epilogue-Bold.ttf"),
    "Epilogue-ExtraBold": require("./assets/fonts/Epilogue-ExtraBold.ttf"),
    "Inter-SemiBold": require("./assets/fonts/Inter-SemiBold.ttf"),
  });

  React.useEffect(() => {
    setTimeout(() => {
      setHideSplashScreen(true);
    }, 2000);
  }, []);

  function MaterialIcon({ name, style }) {
    const { height, tintColor, ...iconStyle } = StyleSheet.flatten(style);
    return (
      <MIcon name={name} size={height} color={tintColor} style={iconStyle} />
    );
  }

  const IconProvider = (name) => ({
    toReactElement: (props) => MaterialIcon({ name, ...props }),
  });

  function createIconsMap() {
    return new Proxy(
      {},
      {
        get(target, name) {
          return IconProvider(name);
        },
      }
    );
  }
  const MaterialIconsPack = {
    name: "material",
    icons: createIconsMap(),
  };

  if (!fontsLoaded && !error) {
    return null;
  }

  return (
    <>
      <IconRegistry icons={[MaterialIconsPack]} />
      <ApplicationProvider {...eva} theme={eva.light}>
        <NavigationContainer>
          {hideSplashScreen ? (
            <Stack.Navigator
              initialRouteName="Home"
              screenOptions={{ headerShown: false }}
            >
              <Stack.Screen name="DrawerRoot" component={DrawerRoot} />

              <Stack.Screen
                name="Start"
                component={Start}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="TestIcon"
                component={TestIcon}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="VectorIcon"
                component={VectorIcon}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="Chat"
                component={Chat}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="VectorIcon1"
                component={VectorIcon1}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="EncuentrosImage"
                component={EncuentrosImage}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="VectorImage"
                component={VectorImage}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="ShapeIcon"
                component={ShapeIcon}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="ShapeIcon1"
                component={ShapeIcon1}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="AjustesPerfil"
                component={AjustesPerfil}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="ExitoEliminarCuenta"
                component={ExitoEliminarCuenta}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="AjustesSeguridad"
                component={AjustesSeguridad}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="AjustesPlanBasico"
                component={AjustesPlanBasico}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="AjustesPlanEstandar"
                component={AjustesPlanEstandar}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="AjustesPlanPremium"
                component={AjustesPlanPremium}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="AjustesPlanes"
                component={AjustesPlanes}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="ModalLogOut"
                component={ModalLogOut}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="Ajustes"
                component={Ajustes}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="TerminosCondiciones"
                component={TerminosCondiciones}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="PoliticaPrivacidad"
                component={PoliticaPrivacidad}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="Register3"
                component={Register3}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="Register2"
                component={Register2}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="Register1"
                component={Register1}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="PassRecovery"
                component={PassRecovery}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="QuizAdentro"
                component={QuizAdentro}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="Login1"
                component={Login1}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="Onboarding4"
                component={Onboarding4}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="Onboarding3"
                component={Onboarding3}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="Onboarding2"
                component={Onboarding2}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="Onboarding1"
                component={Onboarding1}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="Splash"
                component={Splash}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="ZicochatConversacion"
                component={ZicochatConversacion}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="QuizCompletado"
                component={QuizCompletado}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="QuizAdentroPreguntas"
                component={QuizAdentroPreguntas}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="ExitoPassRecovery"
                component={ExitoPassRecovery}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="ShapeIcon11"
                component={ShapeIcon11}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="ShapeIcon2"
                component={ShapeIcon2}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="VectorImage1"
                component={VectorImage1}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="VectorImage2"
                component={VectorImage2}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="VectorIcon3"
                component={VectorIcon3}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="VectorIcon2"
                component={VectorIcon2}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="VectorIcon11"
                component={VectorIcon11}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="VectorIcon4"
                component={VectorIcon4}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="BottomNavBar3"
                component={BottomNavBar3}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="BottomNavBar2"
                component={BottomNavBar2}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="BottomNavBar1"
                component={BottomNavBar1}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="BottomNavBar"
                component={BottomNavBar}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="Frame2"
                component={Frame2}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="Frame1"
                component={Frame1}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="Frame"
                component={Frame}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="BarraDeNavegacin"
                component={BarraDeNavegacin}
                options={{ headerShown: false }}
              />
              <Stack.Screen
                name="ExitoAjustesPerfil"
                component={ExitoAjustesPerfil}
                options={{ headerShown: false }}
              />
            </Stack.Navigator>
          ) : (
            <Splash />
          )}
        </NavigationContainer>
      </ApplicationProvider>
    </>
  );
};
export default App;
