import React, { useMemo } from "react";
import { Image } from "expo-image";
import { StyleSheet, ImageSourcePropType } from "react-native";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1CelesteImage = ({
  property1CelesteImageProp,
  property1CelesteIconPosition,
  property1CelesteIconMarginLeft,
  property1CelesteIconTop,
  property1CelesteIconLeft,
  property1CelesteIconWidth,
}) => {
  const property1CelesteIconStyle = useMemo(() => {
    return {
      ...getStyleValue("position", property1CelesteIconPosition),
      ...getStyleValue("marginLeft", property1CelesteIconMarginLeft),
      ...getStyleValue("top", property1CelesteIconTop),
      ...getStyleValue("left", property1CelesteIconLeft),
      ...getStyleValue("width", property1CelesteIconWidth),
    };
  }, [
    property1CelesteIconPosition,
    property1CelesteIconMarginLeft,
    property1CelesteIconTop,
    property1CelesteIconLeft,
    property1CelesteIconWidth,
  ]);

  return (
    <Image
      style={[styles.property1celesteIcon, property1CelesteIconStyle]}
      contentFit="cover"
      source={property1CelesteImageProp}
    />
  );
};

const styles = StyleSheet.create({
  property1celesteIcon: {
    width: 372,
    height: 45,
  },
});

export default Property1CelesteImage;
