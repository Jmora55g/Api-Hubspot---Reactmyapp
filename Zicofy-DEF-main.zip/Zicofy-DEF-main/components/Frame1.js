import * as React from "react";
import {
  StyleProp,
  ViewStyle,
  StyleSheet,
  Pressable,
  Text,
  View,
} from "react-native";
import { Image } from "expo-image";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const Frame1 = ({ style }) => {
  return (
    <View style={[styles.frame, style]}>
      <Pressable style={styles.materialSymbolsprivacyTipO} onPress={() => {}}>
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/materialsymbolsprivacytipoutline1.png")}
        />
      </Pressable>
      <Pressable onPress={() => {}}>
        <Text style={styles.seguridad1}>Seguridad</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  icon: {
    width: "100%",
    height: "100%",
    overflow: "hidden",
  },
  materialSymbolsprivacyTipO: {
    width: 32,
    height: 30,
  },
  seguridad1: {
    fontSize: FontSize.size_base,
    lineHeight: 14,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.colorBlack,
    textAlign: "left",
    width: 86,
  },
  frame: {
    width: 157,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    overflow: "hidden",
  },
});

export default Frame1;
