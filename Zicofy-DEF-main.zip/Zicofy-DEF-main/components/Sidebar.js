import React, { useState } from "react";
import Ajustes from "./Ajustes";
import { Image } from "expo-image";
import { StyleSheet, View, Text } from "react-native";
import { Border, Padding } from "../GlobalStyles";

const Sidebar = ({ state, navigation }) => {
  const [drawerItemsNormal] = useState([<Ajustes />]);
  const [drawerItemsActive] = useState([<Ajustes />]);
  const stateIndex = !state ? 0 : state.index - 1;

  return (
    <View style={[styles.sidebar, styles.textoFlexBox]}>
      <View style={styles.sidebar1}>
        <View style={styles.logo}>
          <Image
            style={styles.imagenIcon}
            contentFit="cover"
            source={require("../assets/artboard-22-2.png")}
          />
        </View>
        {stateIndex === 0 ? drawerItemsActive[0] : drawerItemsNormal[0]}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  mt20: {
    marginTop: 20,
  },
  textoFlexBox: {
    flexDirection: "row",
    justifyContent: "center",
  },
  imagenIcon: {
    width: 90,
    height: 34,
  },
  logo: {
    alignItems: "center",
    justifyContent: "center",
  },
  sidebar1: {
    height: "100%",
    borderTopRightRadius: Border.br_mini,
    borderBottomRightRadius: Border.br_mini,
    backgroundColor: "#fafafa",
    paddingHorizontal: Padding.p_xl,
    paddingVertical: Padding.p_27xl,
    minHeight: 145,
    maxHeight: 873,
    alignItems: "center",
    flex: 1,
  },
  sidebar: {
    width: 260,
    justifyContent: "center",
    borderRadius: Border.br_mini,
    flexDirection: "row",
  },
});

export default Sidebar;
