import * as React from "react";
import { StyleProp, ViewStyle, StyleSheet } from "react-native";
import { Image } from "expo-image";

const VectorImage = ({ style }) => {
  return (
    <Image
      style={[styles.vectorIcon, style]}
      contentFit="center"
      source={require("../assets/vector2.png")}
    />
  );
};

const styles = StyleSheet.create({
  vectorIcon: {
    width: 51,
    height: 35,
  },
});

export default VectorImage;
