import * as React from "react";
import {
  Pressable,
  StyleProp,
  ViewStyle,
  StyleSheet,
  TouchableHighlight,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";

const EncuentrosImage = ({ style }) => {
  const navigation = useNavigation();

  return (
    <TouchableHighlight
      style={[styles.encuentros, style]}
      underlayColor="#74c2ef"
      onPress={() => navigation.navigate("Encuentros")}
    >
      <Image
        style={styles.icon}
        button="ver_calendario"
        contentFit="cover"
        source={require("../assets/encuentros.png")}
      />
    </TouchableHighlight>
  );
};

const styles = StyleSheet.create({
  icon: {
    width: "100%",
    height: "100%",
  },
  encuentros: {
    width: 51,
    height: 35,
  },
});

export default EncuentrosImage;
