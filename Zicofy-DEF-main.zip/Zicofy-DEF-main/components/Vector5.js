import * as React from "react";
import { StyleProp, ViewStyle, StyleSheet } from "react-native";
import { Image } from "expo-image";

const VectorImage1 = ({ style }) => {
  return (
    <Image
      style={[styles.vectorIcon, style]}
      contentFit="cover"
      source={require("../assets/vector51.png")}
    />
  );
};

const styles = StyleSheet.create({
  vectorIcon: {
    width: 51,
    height: 35,
  },
});

export default VectorImage1;
