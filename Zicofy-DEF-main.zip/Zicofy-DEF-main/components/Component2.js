import React, { useMemo } from "react";
import { Image } from "expo-image";
import { StyleSheet, View, ImageSourcePropType } from "react-native";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Component2 = ({ prop, prop1, prop2, prop3, viewPosition }) => {
  const circulitosStyle = useMemo(() => {
    return {
      ...getStyleValue("position", viewPosition),
    };
  }, [viewPosition]);

  return (
    <View style={[styles.circulitos, circulitosStyle]}>
      <Image style={styles.iconLayout} contentFit="cover" source={prop} />
      <Image
        style={[styles.icon1, styles.iconLayout]}
        contentFit="cover"
        source={prop1}
      />
      <Image
        style={[styles.icon1, styles.iconLayout]}
        contentFit="cover"
        source={prop2}
      />
      <Image
        style={[styles.icon1, styles.iconLayout]}
        contentFit="cover"
        source={prop3}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    height: 10,
    width: 10,
  },
  icon1: {
    marginLeft: 13,
  },
  circulitos: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
});

export default Component2;
