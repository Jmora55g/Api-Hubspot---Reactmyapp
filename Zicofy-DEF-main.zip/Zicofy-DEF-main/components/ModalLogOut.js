import * as React from "react";
import { View, Text, StyleSheet, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Padding, FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const ModalLogOut = ({ onClose }) => {
  const navigation = useNavigation();

  return (
    <View style={[styles.modalLogOut, styles.modalLogOutFlexBox]}>
      <View style={[styles.textoArriba, styles.modalLogOutFlexBox]}>
        <Text style={styles.advertencia}>
          <Text style={styles.estasPorCerrar}>{`Estas por cerrar sesión
`}</Text>
          <Text style={styles.estsSeguro}>¿Estás seguro?</Text>
        </Text>
      </View>
      <View style={[styles.linea, styles.lineaFlexBox]}>
        <View style={styles.linea1} />
      </View>
      <Pressable
        style={[styles.textoAbajo, styles.lineaFlexBox]}
        onPress={() => navigation.navigate("Login1")}
      >
        <Pressable onPress={() => navigation.navigate("Login1")}>
          <Text style={[styles.cerrarSesin, styles.modalLogOutFlexBox]}>
            Cerrar sesión
          </Text>
        </Pressable>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  modalLogOutFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  lineaFlexBox: {
    padding: Padding.p_3xs,
    justifyContent: "center",
    alignItems: "center",
  },
  estasPorCerrar: {
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    fontSize: FontSize.size_base,
  },
  estsSeguro: {
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsRegular,
  },
  advertencia: {
    color: Color.colorGray_200,
    textAlign: "center",
    flex: 1,
  },
  textoArriba: {
    paddingHorizontal: Padding.p_3xs,
    paddingTop: Padding.p_xl,
    paddingBottom: Padding.p_3xs,
    flexDirection: "row",
    width: 295,
  },
  linea1: {
    borderStyle: "solid",
    borderColor: Color.colorGainsboro,
    borderTopWidth: 1,
    height: 1,
    alignSelf: "stretch",
  },
  linea: {
    width: 295,
  },
  cerrarSesin: {
    letterSpacing: 0,
    lineHeight: 22,
    color: Color.colorSalmon,
    display: "flex",
    width: 102,
    alignSelf: "stretch",
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_base,
    textAlign: "center",
  },
  textoAbajo: {
    alignSelf: "stretch",
    flex: 1,
    flexDirection: "row",
  },
  modalLogOut: {
    borderRadius: Border.br_mini,
    backgroundColor: Color.colorsNeutralWhite,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 2,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    height: 157,
    maxWidth: "100%",
    maxHeight: "100%",
  },
});

export default ModalLogOut;
