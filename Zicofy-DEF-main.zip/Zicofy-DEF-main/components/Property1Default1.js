import React, { useMemo } from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1Default1 = ({
  texto,
  property1DefaultPosition,
  textoFlex,
  textoFontSize,
  textoLineHeight,
  textoFontWeight,
  textoFontFamily,
  textoColor,
  textoTextAlign,
  onBotnPress,
  onTextoPress,
}) => {
  const property1Default2Style = useMemo(() => {
    return {
      ...getStyleValue("position", property1DefaultPosition),
    };
  }, [property1DefaultPosition]);

  const texto1Style = useMemo(() => {
    return {
      ...getStyleValue("flex", textoFlex),
      ...getStyleValue("fontSize", textoFontSize),
      ...getStyleValue("lineHeight", textoLineHeight),
      ...getStyleValue("fontWeight", textoFontWeight),
      ...getStyleValue("fontFamily", textoFontFamily),
      ...getStyleValue("color", textoColor),
      ...getStyleValue("textAlign", textoTextAlign),
    };
  }, [
    textoFlex,
    textoFontSize,
    textoLineHeight,
    textoFontWeight,
    textoFontFamily,
    textoColor,
    textoTextAlign,
  ]);

  return (
    <View
      style={[styles.property1default, property1Default2Style]}
      onPress={onBotnPress}
    >
      <Text style={[styles.texto, texto1Style]} onPress={onTextoPress}>
        {texto}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  texto: {
    fontSize: FontSize.size_mid,
    lineHeight: 24,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.colorGray_200,
    textAlign: "center",
  },
  property1default: {
    borderRadius: Border.br_6xl,
    backgroundColor: Color.colorThistle,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: Padding.p_10xl,
    paddingVertical: Padding.p_sm,
    alignSelf: "stretch",
  },
});

export default Property1Default1;
