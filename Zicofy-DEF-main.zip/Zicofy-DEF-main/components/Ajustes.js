import * as React from "react";
import {
  Pressable,
  StyleProp,
  ViewStyle,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const Ajustes = ({ style }) => {
  const navigation = useNavigation();

  return (
    <Pressable
      style={[styles.ajustes, style, styles.textoFlexBox]}
      onPress={() => navigation.navigate("Ajustes1")}
    >
      <Image
        style={styles.icono}
        contentFit="cover"
        source={require("../assets/icono.png")}
      />
      <View style={[styles.texto, styles.textoFlexBox]}>
        <Text style={styles.texto1}>Ajustes</Text>
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  textoFlexBox: {
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  icono: {
    width: 18,
    height: 18,
  },
  texto1: {
    fontSize: FontSize.size_lg,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.colorGray_200,
    textAlign: "left",
    flex: 1,
  },
  texto: {
    marginLeft: 12,
    flex: 1,
  },
  ajustes: {
    alignSelf: "stretch",
    borderRadius: Border.br_mini,
    backgroundColor: Color.colorWhitesmoke_300,
    padding: Padding.p_3xs,
  },
});

export default Ajustes;
