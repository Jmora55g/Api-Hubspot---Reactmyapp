import * as React from "react";
import { StyleProp, ViewStyle, StyleSheet } from "react-native";
import { Image } from "expo-image";

const ShapeIcon11 = ({ style }) => {
  return (
    <Image
      style={[styles.shapeIcon, style]}
      contentFit="cover"
      source={require("../assets/shape11.png")}
    />
  );
};

const styles = StyleSheet.create({
  shapeIcon: {
    width: 40,
    height: 40,
  },
});

export default ShapeIcon11;
