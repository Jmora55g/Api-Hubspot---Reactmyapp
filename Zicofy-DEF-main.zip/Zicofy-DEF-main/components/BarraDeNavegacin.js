import * as React from "react";
import {
  StyleProp,
  ViewStyle,
  StyleSheet,
  View,
  Pressable,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, Padding } from "../GlobalStyles";

const BarraDeNavegacin = ({ style }) => {
  const navigation = useNavigation();

  return (
    <View style={[styles.barraDeNavegacin, style]}>
      <View style={[styles.naviationRectangle, styles.conosPosition]} />
      <View style={[styles.conos, styles.conosPosition]}>
        <Pressable style={styles.shape} onPress={() => {}}>
          <Image
            style={styles.icon}
            contentFit="cover"
            source={require("../assets/shape111.png")}
          />
        </Pressable>
        <Pressable
          style={[styles.vector, styles.vectorSpaceBlock]}
          onPress={() => navigation.navigate("")}
        >
          <Image
            style={styles.icon}
            contentFit="cover"
            source={require("../assets/vector61.png")}
          />
        </Pressable>
        <Image
          style={[styles.vectorIcon, styles.vectorSpaceBlock]}
          contentFit="cover"
          source={require("../assets/vector311.png")}
        />
        <Pressable
          style={[styles.vector1, styles.vectorSpaceBlock]}
          onPress={() => {}}
        >
          <Image
            style={styles.icon}
            contentFit="cover"
            source={require("../assets/vector10.png")}
          />
        </Pressable>
      </View>
      <Image
        style={styles.barraDeNavegacinChild}
        contentFit="cover"
        source={require("../assets/ellipse-4.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  conosPosition: {
    left: "0%",
    bottom: "0%",
    right: "0%",
    top: "0%",
    width: "100%",
    height: "100%",
    position: "absolute",
  },
  vectorSpaceBlock: {
    marginLeft: 60,
    height: 35,
  },
  naviationRectangle: {
    backgroundColor: Color.colorsNeutralWhite,
    shadowColor: "rgba(0, 0, 0, 0.11)",
    shadowOffset: {
      width: 0,
      height: -2,
    },
    shadowRadius: 12,
    elevation: 12,
    shadowOpacity: 1,
  },
  icon: {
    width: "100%",
    height: "100%",
  },
  shape: {
    height: 40,
    width: 40,
  },
  vector: {
    width: 51,
  },
  vectorIcon: {
    width: 40,
  },
  vector1: {
    width: 35,
  },
  conos: {
    flexDirection: "row",
    flexWrap: "wrap",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: Padding.p_6xl,
    paddingVertical: Padding.p_xl,
  },
  barraDeNavegacinChild: {
    height: "8.24%",
    width: "3.19%",
    right: "35.66%",
    bottom: "91.76%",
    left: "61.15%",
    maxWidth: "100%",
    maxHeight: "100%",
    top: "0%",
    position: "absolute",
    overflow: "hidden",
  },
  barraDeNavegacin: {
    width: 442,
    height: 85,
    overflow: "hidden",
  },
});

export default BarraDeNavegacin;
