import * as React from "react";
import { StyleProp, ViewStyle, StyleSheet, View } from "react-native";
import { Image } from "expo-image";

const Chat = ({ style }) => {
  return (
    <View style={[styles.chat, style]}>
      <Image
        style={styles.chatIcon}
        contentFit="center"
        source={require("../assets/chat.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  chatIcon: {
    position: "absolute",
    height: "108.39%",
    width: "107.03%",
    top: "-4.19%",
    right: "-3.51%",
    bottom: "-4.19%",
    left: "-3.51%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
  },
  chat: {
    width: 37,
    height: 31,
  },
});

export default Chat;
