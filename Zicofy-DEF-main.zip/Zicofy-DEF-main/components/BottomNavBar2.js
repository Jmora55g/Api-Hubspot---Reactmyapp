import * as React from "react";
import { StyleProp, ViewStyle, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Border, Color, Padding } from "../GlobalStyles";

const BottomNavBar2 = ({ style }) => {
  return (
    <View style={[styles.bottomNavBar, style]}>
      <Image
        style={styles.shapeIcon}
        contentFit="cover"
        source={require("../assets/shape2.png")}
      />
      <Image
        style={styles.vectorIcon1}
        contentFit="cover"
        source={require("../assets/vector12.png")}
      />
      <Image
        style={[styles.vectorIcon2, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector13.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  vectorIconLayout: {
    height: 35,
    marginLeft: 50,
  },
  shapeIcon: {
    height: 40,
    width: 40,
  },
  vectorIcon1: {
    height: 34,
    marginLeft: 50,
    width: 40,
  },
  vectorIcon2: {
    width: 35,
    marginLeft: 50,
  },
  bottomNavBar: {
    position: "absolute",
    borderRadius: Border.br_11xl,
    backgroundColor: Color.colorsNeutralWhite,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 15,
    elevation: 15,
    shadowOpacity: 1,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Padding.p_31xl,
    paddingVertical: Padding.p_3xl,
  },
});

export default BottomNavBar2;
