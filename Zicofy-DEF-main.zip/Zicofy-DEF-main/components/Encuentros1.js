import * as React from "react";
import {
  StyleProp,
  ViewStyle,
  StyleSheet,
  View,
  Text,
  Pressable,
} from "react-native";
import { Image } from "expo-image";
import Property1CelesteImage from "./Property1CelesteImage";
import { Color, FontSize, FontFamily, Border, Padding } from "../GlobalStyles";

const Encuentros1 = ({ style }) => {
  return (
    <View style={[styles.encuentros, style]}>
      <Property1CelesteImage
        property1CelesteImageProp={require("../assets/men-superior.png")}
        property1CelesteIconPosition="absolute"
        property1CelesteIconMarginLeft={-187.5}
        property1CelesteIconTop={50}
        property1CelesteIconLeft="50%"
        property1CelesteIconWidth={372}
      />
      <View style={[styles.rectangle, styles.rectanglePosition]} />
      <Text style={[styles.toBuildResponsibly, styles.buildTypo]}>
        Tu próximo encuentro
      </Text>
      <Text
        style={[styles.toBuildResponsibly1, styles.toBuildResponsibly1Position]}
      >
        Jueves 9 de Noviembre, 16.00 hs
      </Text>
      <Text
        style={[styles.agendaEncuentrosCon, styles.howAreYouTypo]}
      >{`Agenda encuentros con tu Zico, seleccionado por nuestra IA, en el calendario. 

¡Elige un horario, y comienza a trabajar en tu bienestar emocional!`}</Text>
      <Text style={[styles.howAreYou, styles.howAreYouTypo]}>
        Agenda tu encuentro
      </Text>
      <Image
        style={[styles.image3Icon, styles.image3IconPosition]}
        contentFit="cover"
        source={require("../assets/image-3.png")}
      />
      <View style={[styles.barraDeNavegacin, styles.image3IconPosition]}>
        <View style={[styles.naviationRectangle, styles.conosPosition]} />
        <View style={[styles.conos, styles.conosPosition]}>
          <Image
            style={styles.shapeIcon}
            contentFit="cover"
            source={require("../assets/shape111.png")}
          />
          <Image
            style={styles.vectorIcon}
            contentFit="cover"
            source={require("../assets/vector18.png")}
          />
          <Pressable style={styles.vector} onPress={() => {}}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/vector21.png")}
            />
          </Pressable>
          <Image
            style={styles.vectorIcon1}
            contentFit="cover"
            source={require("../assets/vector10.png")}
          />
        </View>
        <Image
          style={styles.barraDeNavegacinChild}
          contentFit="cover"
          source={require("../assets/ellipse-41.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  rectanglePosition: {
    width: 368,
    marginLeft: -183.5,
    left: "50%",
  },
  buildTypo: {
    textAlign: "center",
    color: Color.colorsNeutralWhite,
    lineHeight: 28,
    fontSize: FontSize.size_lg,
    top: "50%",
    position: "absolute",
  },
  toBuildResponsibly1Position: {
    fontFamily: FontFamily.poppinsRegular,
    width: 368,
    left: "50%",
    marginLeft: -183.5,
  },
  howAreYouTypo: {
    textAlign: "left",
    fontSize: FontSize.size_lg,
    position: "absolute",
  },
  image3IconPosition: {
    left: "50%",
    position: "absolute",
  },
  conosPosition: {
    left: "0%",
    bottom: "0%",
    right: "0%",
    top: "0%",
    width: "100%",
    height: "100%",
    position: "absolute",
  },
  rectangle: {
    top: 124,
    borderRadius: Border.br_xl,
    backgroundColor: Color.colorLightskyblue,
    height: 108,
    position: "absolute",
    width: 368,
    marginLeft: -183.5,
  },
  toBuildResponsibly: {
    marginTop: -318,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    width: 368,
    marginLeft: -183.5,
    left: "50%",
  },
  toBuildResponsibly1: {
    marginTop: -286,
    textAlign: "center",
    color: Color.colorsNeutralWhite,
    lineHeight: 28,
    fontSize: FontSize.size_lg,
    top: "50%",
    position: "absolute",
  },
  agendaEncuentrosCon: {
    top: 250,
    color: Color.colorGray_200,
    fontFamily: FontFamily.poppinsRegular,
    width: 368,
    left: "50%",
    marginLeft: -183.5,
  },
  howAreYou: {
    top: 430,
    left: 31,
    color: Color.colorGray_500,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
  },
  image3Icon: {
    marginLeft: -185.5,
    top: 475,
    borderRadius: Border.br_mini,
    width: 372,
    height: 549,
  },
  naviationRectangle: {
    shadowColor: "rgba(0, 0, 0, 0.11)",
    shadowOffset: {
      width: 0,
      height: -2,
    },
    shadowRadius: 12,
    elevation: 12,
    shadowOpacity: 1,
    backgroundColor: Color.colorsNeutralWhite,
  },
  shapeIcon: {
    height: 40,
    width: 40,
  },
  vectorIcon: {
    width: 48,
    height: 32,
    marginLeft: 60,
  },
  icon: {
    width: "100%",
    height: "100%",
  },
  vector: {
    height: 34,
    marginLeft: 60,
    width: 40,
  },
  vectorIcon1: {
    width: 35,
    height: 35,
    marginLeft: 60,
  },
  conos: {
    flexDirection: "row",
    flexWrap: "wrap",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: Padding.p_6xl,
    paddingVertical: Padding.p_xl,
  },
  barraDeNavegacinChild: {
    height: "8.24%",
    width: "3.21%",
    right: "59.35%",
    bottom: "91.76%",
    left: "37.44%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
    top: "0%",
    position: "absolute",
  },
  barraDeNavegacin: {
    marginLeft: -214.5,
    bottom: 0,
    width: 430,
    height: 85,
  },
  encuentros: {
    width: 505,
    height: 932,
    backgroundColor: Color.colorsNeutralWhite,
  },
});

export default Encuentros1;
