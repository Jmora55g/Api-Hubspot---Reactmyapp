import * as React from "react";
import { StyleProp, ViewStyle, StyleSheet } from "react-native";
import { Image } from "expo-image";

const TestIcon = ({ style }) => {
  return (
    <Image
      style={[styles.testIcon, style]}
      contentFit="center"
      source={require("../assets/test.png")}
    />
  );
};

const styles = StyleSheet.create({
  testIcon: {
    width: 41,
    height: 42,
  },
});

export default TestIcon;
