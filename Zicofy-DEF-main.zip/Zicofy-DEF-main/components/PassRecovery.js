import React, { useCallback } from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
  Alert,
} from "react-native";
import { Image } from "expo-image";
import { Input } from "@rneui/themed";
import { useNavigation } from "@react-navigation/native";
import Property1Default3 from "./Property1Default3";
import { Color, FontSize, FontFamily, Padding } from "../GlobalStyles";

const PassRecovery = () => {
  const navigation = useNavigation();

  const onIniciarSesinClick = useCallback(() => {
    Alert.alert("Correo electronico enviado", "enviado", [
      {
        text: "ok",
        onPress: () => console.log("ok pressed"),
      },
    ]);
  }, []);

  return (
    <View style={styles.passRecovery}>
      <View style={styles.contenido}>
        <View style={[styles.logo, styles.logoFlexBox]}>
          <Pressable style={styles.volver} onPress={() => navigation.goBack()}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/volver11.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <ScrollView
          style={[styles.interactuable, styles.inputSpaceBlock]}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.interactuableScrollViewContent}
        >
          <View style={[styles.iniciaSesion, styles.logoFlexBox]}>
            <Text style={[styles.titulo, styles.textoFlexBox]}>
              Recuperar contraseña
            </Text>
          </View>
          <View style={[styles.explicacion, styles.inputSpaceBlock]}>
            <Text style={[styles.texto, styles.textoFlexBox]}>
              Llena tu correo y recibirás un email con un link para reestablecer
              tu contraseña
            </Text>
          </View>
          <Input
            style={styles.inputSpaceBlock}
            label="Correo electrónico"
            placeholder="Ingresa tu correo electrónico"
            required={true}
            leftIcon={{ name: "email-outline", type: "material-community" }}
            inputStyle={{ color: "#0b0b0b" }}
          />
          <View style={[styles.iniciarSesion, styles.inputSpaceBlock]}>
            <Property1Default3
              texto="Recuperar contraseña"
              property1DefaultPosition="unset"
              property1DefaultAlignSelf="stretch"
              property1DefaultBackgroundColor="#ffd7f3"
              textoFlex={1}
              onIniciarSesinPress={onIniciarSesinClick}
            />
          </View>
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  logoFlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  inputSpaceBlock: {
    marginTop: 20,
    alignSelf: "stretch",
  },
  textoFlexBox: {
    textAlign: "left",
    color: Color.colorGray_200,
    flex: 1,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  logo: {
    alignSelf: "stretch",
    justifyContent: "space-between",
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
  },
  iniciaSesion: {
    justifyContent: "center",
    alignSelf: "stretch",
  },
  texto: {
    fontSize: FontSize.size_lg,
    fontFamily: FontFamily.poppinsRegular,
  },
  explicacion: {
    flexDirection: "row",
    alignItems: "center",
  },
  iniciarSesion: {
    alignItems: "center",
  },
  interactuable: {
    flex: 1,
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignSelf: "stretch",
    alignItems: "center",
    flex: 1,
  },
  passRecovery: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    paddingTop: Padding.p_27xl,
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    flex: 1,
  },
});

export default PassRecovery;
