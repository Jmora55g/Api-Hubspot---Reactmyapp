import React, { useMemo } from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1Default3 = ({
  texto,
  textoNumberOfLines,
  property1DefaultPosition,
  property1DefaultAlignSelf,
  property1DefaultBackgroundColor,
  textoFlex,
  onIniciarSesinPress,
}) => {
  const property1DefaultStyle = useMemo(() => {
    return {
      ...getStyleValue("position", property1DefaultPosition),
      ...getStyleValue("alignSelf", property1DefaultAlignSelf),
      ...getStyleValue("backgroundColor", property1DefaultBackgroundColor),
    };
  }, [
    property1DefaultPosition,
    property1DefaultAlignSelf,
    property1DefaultBackgroundColor,
  ]);

  const textoStyle = useMemo(() => {
    return {
      ...getStyleValue("flex", textoFlex),
    };
  }, [textoFlex]);

  return (
    <View
      style={[styles.property1default, property1DefaultStyle]}
      onPress={onIniciarSesinPress}
    >
      <Text style={[styles.texto, textoStyle]}>{texto}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  texto: {
    fontSize: FontSize.size_mid,
    lineHeight: 24,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.colorGray_200,
    textAlign: "center",
  },
  property1default: {
    borderRadius: Border.br_6xl,
    backgroundColor: Color.colorThistle,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: Padding.p_10xl,
    paddingVertical: Padding.p_sm,
    alignSelf: "stretch",
  },
});

export default Property1Default3;
