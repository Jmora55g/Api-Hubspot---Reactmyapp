import * as React from "react";
import { StyleProp, ViewStyle, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Border, Color, Padding } from "../GlobalStyles";

const BottomNavBar3 = ({ style }) => {
  return <View style={[styles.bottomNavBar, style]} />;
};

const styles = StyleSheet.create({
  bottomNavBar: {
    position: "absolute",
    left: 12,
    borderRadius: Border.br_11xl,
    backgroundColor: Color.colorsNeutralWhite,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 15,
    elevation: 15,
    shadowOpacity: 1,
    width: 407,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Padding.p_31xl,
    paddingVertical: Padding.p_3xl,
  },
});

export default BottomNavBar3;
