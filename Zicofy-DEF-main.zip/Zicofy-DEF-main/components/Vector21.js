import * as React from "react";
import { StyleProp, ViewStyle, StyleSheet } from "react-native";
import { Image } from "expo-image";

const VectorIcon2 = ({ style }) => {
  return (
    <Image
      style={[styles.vectorIcon, style]}
      contentFit="cover"
      source={require("../assets/vector21.png")}
    />
  );
};

const styles = StyleSheet.create({
  vectorIcon: {
    width: 40,
    height: 34,
  },
});

export default VectorIcon2;
