import * as React from "react";
import { View, Text, StyleSheet, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Padding, FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const ModalDeleteAccount = ({ onClose }) => {
  const navigation = useNavigation();

  return (
    <View style={[styles.modalDeleteAccount, styles.modalDeleteAccountFlexBox]}>
      <View style={styles.textoArriba}>
        <Text style={[styles.advertencia, styles.advertenciaFlexBox]}>
          <Text
            style={styles.lamentamosQueQuieras}
          >{`Lamentamos que quieras irte :c
`}</Text>
          <Text style={styles.estsSeguroDe}>
            ¿Estás seguro de que quieres eliminar tu cuenta?
          </Text>
        </Text>
      </View>
      <View style={[styles.linea, styles.lineaFlexBox]}>
        <View style={styles.linea1} />
      </View>
      <Pressable
        style={[styles.textoAbajo, styles.lineaFlexBox]}
        onPress={() => navigation.navigate("ExitoEliminarCuenta")}
      >
        <Pressable onPress={() => navigation.navigate("Login1")}>
          <Text
            style={[styles.sQuieroEliminarMiCuenta, styles.advertenciaFlexBox]}
          >
            Sí, quiero eliminar mi cuenta
          </Text>
        </Pressable>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  modalDeleteAccountFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  advertenciaFlexBox: {
    textAlign: "center",
    flex: 1,
  },
  lineaFlexBox: {
    padding: Padding.p_3xs,
    justifyContent: "center",
    alignItems: "center",
  },
  lamentamosQueQuieras: {
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    fontSize: FontSize.size_base,
  },
  estsSeguroDe: {
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsRegular,
  },
  advertencia: {
    color: Color.colorGray_200,
  },
  textoArriba: {
    paddingHorizontal: Padding.p_3xs,
    paddingTop: Padding.p_xl,
    paddingBottom: Padding.p_3xs,
    flexDirection: "row",
    width: 295,
    justifyContent: "center",
    alignItems: "center",
  },
  linea1: {
    borderStyle: "solid",
    borderColor: Color.colorGainsboro,
    borderTopWidth: 1,
    height: 1,
    alignSelf: "stretch",
  },
  linea: {
    padding: Padding.p_3xs,
    width: 295,
  },
  sQuieroEliminarMiCuenta: {
    letterSpacing: 0,
    lineHeight: 22,
    color: Color.colorSalmon,
    display: "flex",
    alignSelf: "stretch",
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_base,
    justifyContent: "center",
    alignItems: "center",
  },
  textoAbajo: {
    alignSelf: "stretch",
    flex: 1,
    padding: Padding.p_3xs,
    flexDirection: "row",
  },
  modalDeleteAccount: {
    borderRadius: Border.br_mini,
    backgroundColor: Color.colorsNeutralWhite,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 2,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    height: 157,
    maxWidth: "100%",
    maxHeight: "100%",
  },
});

export default ModalDeleteAccount;
