import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Padding, FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const ModalSinSuscripcion = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.modalSinSuscripcion}>
      <View style={[styles.textoArriba, styles.textoFlexBox]}>
        <Text style={[styles.advertencia, styles.advertenciaFlexBox]}>
          <Text style={styles.mejoraTuSuscripcin}>{`¡Mejora tu suscripción!
`}</Text>
          <Text style={styles.paraAgendarTu}>
            Para agendar tu primer encuentro, tendrás que suscribirte a uno de
            los planes de pago
          </Text>
        </Text>
      </View>
      <View style={styles.linea}>
        <View style={styles.linea1} />
      </View>
      <Pressable
        style={[styles.textoAbajo, styles.textoFlexBox]}
        onPress={() => navigation.navigate("AjustesPlanes")}
      >
        <Text style={[styles.cerrarSesion, styles.advertenciaFlexBox]}>
          Ver planes
        </Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  textoFlexBox: {
    paddingHorizontal: Padding.p_3xs,
    flexDirection: "row",
    width: 295,
    justifyContent: "center",
    alignItems: "center",
  },
  advertenciaFlexBox: {
    textAlign: "center",
    flex: 1,
  },
  mejoraTuSuscripcin: {
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    fontSize: FontSize.size_base,
  },
  paraAgendarTu: {
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsRegular,
  },
  advertencia: {
    color: Color.colorGray_200,
  },
  textoArriba: {
    paddingTop: Padding.p_xl,
    paddingBottom: Padding.p_3xs,
  },
  linea1: {
    alignSelf: "stretch",
    borderStyle: "solid",
    borderColor: Color.colorGainsboro,
    borderTopWidth: 1,
    height: 1,
  },
  linea: {
    padding: Padding.p_3xs,
    width: 295,
    justifyContent: "center",
    alignItems: "center",
  },
  cerrarSesion: {
    letterSpacing: 0,
    lineHeight: 22,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.colorLightskyblue,
    fontSize: FontSize.size_base,
  },
  textoAbajo: {
    paddingTop: Padding.p_3xs,
    paddingBottom: Padding.p_xl,
  },
  modalSinSuscripcion: {
    borderRadius: Border.br_mini,
    backgroundColor: Color.colorsNeutralWhite,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 2,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});

export default ModalSinSuscripcion;
