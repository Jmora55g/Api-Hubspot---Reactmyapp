import React, { useState } from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
} from "react-native";
import { Image } from "expo-image";
import { Input, Button } from "@rneui/themed";
import { Checkbox } from "react-native-paper";
import { useNavigation } from "@react-navigation/native";
import Property1Default3 from "./Property1Default3";
import { FontFamily, FontSize, Color, Padding } from "../GlobalStyles";

const Login1 = () => {
  const [checkboxchecked, setCheckboxchecked] = useState(false);
  const navigation = useNavigation();

  return (
    <View style={styles.login1}>
      <View style={styles.contenido}>
        <View style={[styles.logo, styles.logoFlexBox]}>
          <Pressable style={styles.volver} onPress={() => navigation.goBack()}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/volver11.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <ScrollView
          style={styles.interactuable}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.interactuableScrollViewContent}
        >
          <View style={[styles.iniciaSesion, styles.texto3FlexBox]}>
            <Text style={styles.titulo}>Inicia sesión</Text>
          </View>
          <View style={[styles.explicacion, styles.logoFlexBox]}>
            <Pressable onPress={() => navigation.navigate("Register1")}>
              <Text style={[styles.text, styles.textTypo]}>
                <Text style={styles.siNoTienes}>{`Si no tienes una cuenta,
`}</Text>
                <Text style={styles.regstrateAqu}>¡Regístrate aquí!</Text>
              </Text>
            </Pressable>
          </View>
          <Input
            style={styles.input}
            label="Correo electrónico"
            placeholder="ingrese correo electrónico"
            leftIcon={{ name: "email-outline", type: "material-community" }}
            inputStyle={{ color: "#000" }}
          />
          <View style={styles.input}>
            <Input
              style={styles.input1}
              label="Contraseña"
              placeholder="***********"
              required={true}
              leftIcon={{ name: "lock-outline", type: "material-community" }}
              rightIcon={{
                name: "eye-off-outline",
                type: "material-community",
              }}
              inputStyle={{ color: "#000" }}
            />
            <View style={[styles.recuperacionContrasea, styles.texto3FlexBox]}>
              <Button
                title="Olvidé mi contraseña"
                radius="5"
                iconPosition="left"
                type="clear"
                color="#adadad"
                titleStyle={styles.texto1Btn}
                onPress={() => navigation.navigate("PassRecovery")}
                containerStyle={styles.texto1Btn1}
                buttonStyle={styles.texto1Btn2}
              />
            </View>
          </View>
          <View style={[styles.explicacion, styles.logoFlexBox]}>
            <View>
              <Checkbox
                status={checkboxchecked ? "checked" : "unchecked"}
                onPress={() => setCheckboxchecked(!checkboxchecked)}
                color="#73e60e"
                uncheckedColor="#020202"
              />
            </View>
            <View style={[styles.texto1, styles.logoFlexBox]}>
              <Text style={[styles.texto2, styles.textTypo]}>Recordarme</Text>
            </View>
          </View>
          <Pressable
            style={styles.iniciarSesion}
            onPress={() =>
              navigation.navigate("DrawerRoot", { screen: "BottomTabsRoot" })
            }
          >
            <Property1Default3
              texto="Iniciar sesión"
              property1DefaultPosition="unset"
              property1DefaultAlignSelf="stretch"
              property1DefaultBackgroundColor="#ffd7f3"
              textoFlex={1}
              onIniciarSesinPress={() =>
                navigation.navigate("DrawerRoot", { screen: "BottomTabsRoot" })
              }
            />
          </Pressable>
          <View style={[styles.texto3, styles.texto3FlexBox]}>
            <Text style={styles.oContinaCon} numberOfLines={1}>
              o continúa con
            </Text>
          </View>
          <Pressable
            style={[styles.google, styles.texto3FlexBox]}
            onPress={() => {}}
          >
            <Image
              style={styles.icono}
              contentFit="cover"
              source={require("../assets/vector7.png")}
            />
          </Pressable>
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  texto1Btn: {
    color: "#adadad",
    fontSize: 12,
    fontFamily: "Poppins-Regular",
  },
  texto1Btn1: {
    position: "relative",
  },
  texto1Btn2: {
    flex: 1,
  },
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  logoFlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  texto3FlexBox: {
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
  },
  textTypo: {
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
    flex: 1,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  logo: {
    alignSelf: "stretch",
    justifyContent: "space-between",
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    textAlign: "left",
    color: Color.colorGray_200,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    flex: 1,
  },
  iniciaSesion: {
    alignSelf: "stretch",
  },
  siNoTienes: {
    color: Color.colorGray_200,
  },
  regstrateAqu: {
    color: Color.colorLightskyblue,
  },
  text: {
    fontSize: FontSize.size_lg,
  },
  explicacion: {
    marginTop: 20,
    alignSelf: "stretch",
  },
  input: {
    marginTop: 20,
    alignSelf: "stretch",
  },
  input1: {
    alignSelf: "stretch",
  },
  recuperacionContrasea: {
    marginTop: 5,
    alignSelf: "stretch",
  },
  texto2: {
    fontSize: FontSize.size_sm,
    color: Color.colorGray_200,
  },
  texto1: {
    marginLeft: 10,
    flex: 1,
  },
  iniciarSesion: {
    marginTop: 20,
    alignSelf: "stretch",
    alignItems: "center",
  },
  oContinaCon: {
    fontSize: FontSize.size_base,
    textAlign: "center",
    transform: [
      {
        rotate: "-0.33deg",
      },
    ],
    color: Color.colorGray_200,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  texto3: {
    marginTop: 20,
    alignSelf: "stretch",
  },
  icono: {
    width: 30,
    height: 30,
  },
  google: {
    marginTop: 20,
  },
  interactuable: {
    marginTop: 20,
    alignSelf: "stretch",
    flex: 1,
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignSelf: "stretch",
    alignItems: "center",
    flex: 1,
  },
  login1: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    paddingTop: Padding.p_27xl,
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    flex: 1,
  },
});

export default Login1;
