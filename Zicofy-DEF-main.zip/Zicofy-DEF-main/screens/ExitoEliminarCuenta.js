import * as React from "react";
import {
  View,
  StyleSheet,
  Pressable,
  ImageBackground,
  ScrollView,
  Text,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border, Padding } from "../GlobalStyles";

const ExitoEliminarCuenta = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.exitoEliminarCuenta}>
      <View style={styles.contenido}>
        <View style={styles.logo}>
          <Pressable style={styles.volver} onPress={() => navigation.goBack()}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/volver1.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <ScrollView
          style={[styles.interactuable, styles.interactuableSpaceBlock]}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.interactuableScrollViewContent}
        >
          <View style={styles.botonFlexBox}>
            <Text style={[styles.titulo, styles.textoClr]}>
              ¡Tu cuenta ha sido eliminada con éxito!
            </Text>
          </View>
          <Pressable
            style={[styles.finalizarTest, styles.interactuableSpaceBlock]}
            onPress={() => navigation.navigate("Start")}
          >
            <Pressable
              style={[styles.boton, styles.botonFlexBox]}
              onPress={() =>
                navigation.navigate("DrawerRoot", { screen: "BottomTabsRoot" })
              }
            >
              <Text style={[styles.texto, styles.textoClr]} numberOfLines={1}>
                Volver al inicio
              </Text>
            </Pressable>
          </Pressable>
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  interactuableSpaceBlock: {
    marginTop: 20,
    alignSelf: "stretch",
  },
  textoClr: {
    color: Color.colorGray_200,
    flex: 1,
  },
  botonFlexBox: {
    justifyContent: "center",
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  logo: {
    flexDirection: "row",
    alignSelf: "stretch",
    justifyContent: "space-between",
    alignItems: "center",
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    textAlign: "left",
  },
  texto: {
    fontSize: FontSize.size_mid,
    lineHeight: 24,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    textAlign: "center",
  },
  boton: {
    borderRadius: Border.br_6xl,
    backgroundColor: Color.colorThistle,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    paddingHorizontal: Padding.p_10xl,
    paddingVertical: Padding.p_sm,
  },
  finalizarTest: {
    alignItems: "center",
    marginTop: 20,
  },
  interactuable: {
    marginTop: 20,
    flex: 1,
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignSelf: "stretch",
    alignItems: "center",
  },
  exitoEliminarCuenta: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    paddingTop: Padding.p_27xl,
    paddingBottom: Padding.p_xl,
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    flex: 1,
  },
});

export default ExitoEliminarCuenta;
