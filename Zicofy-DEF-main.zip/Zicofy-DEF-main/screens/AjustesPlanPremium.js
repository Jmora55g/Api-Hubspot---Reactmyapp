import * as React from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  Text,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Property1Default3 from "../components/Property1Default3";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const AjustesPlanPremium = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.ajustesPlanPremium, styles.logoFlexBox]}>
      <View style={styles.contenido}>
        <View style={[styles.logo, styles.logoFlexBox]}>
          <Pressable style={styles.volver} onPress={() => navigation.goBack()}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/volver.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <View style={styles.interactuableFlexBox}>
          <Text style={styles.titulo}>Plan premium</Text>
        </View>
        <View
          style={[
            styles.conElPlanPremiumDeZicofyWrapper,
            styles.interactuableFlexBox,
          ]}
        >
          <Text style={styles.conElPlanContainer}>
            <Text
              style={styles.conElPlan}
            >{`Con el Plan Premium de Zicofy, disfruta de una atención exclusiva y personalizada con cuatro encuentros al mes para `}</Text>
            <Text
              style={styles.unBienestarSin}
            >{`un bienestar sin comparaciones.
`}</Text>
            <Text style={styles.conElPlan}>{`
Recuerda, tienes 30 días completos desde la compra para agendar tus encuentros en el momento que te sea más conveniente.

`}</Text>
            <Text style={styles.unBienestarSin}>{`Incluye
`}</Text>
            <Text style={styles.conElPlan}>{`ZicoChat
Test de Bienestar
Hasta 4 encuentros mensuales
Libre de anuncios
Biblioteca de recursos

`}</Text>
            <Text style={styles.unBienestarSin}>Suscribete</Text>
            <Text style={styles.conElPlan}> por €59.99/mes</Text>
          </Text>
        </View>
        <Pressable style={styles.interactuableFlexBox} onPress={() => {}}>
          <Property1Default3
            texto="Suscribete al plan premium"
            property1DefaultPosition="unset"
            property1DefaultAlignSelf="stretch"
            property1DefaultBackgroundColor="#ffd7f3"
            textoFlex={1}
            onIniciarSesinPress={() =>
              navigation.navigate("DrawerRoot", { screen: "BottomTabsRoot" })
            }
          />
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  logoFlexBox: {
    justifyContent: "space-between",
    alignItems: "center",
  },
  interactuableFlexBox: {
    marginTop: 20,
    alignSelf: "stretch",
    alignItems: "center",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  logo: {
    flexDirection: "row",
    alignSelf: "stretch",
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    textAlign: "center",
    width: 380,
    color: Color.colorGray_200,
    height: 45,
  },
  conElPlan: {
    fontFamily: FontFamily.poppinsRegular,
  },
  unBienestarSin: {
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
  },
  conElPlanContainer: {
    fontSize: FontSize.size_lg,
    textAlign: "left",
    color: Color.colorGray_200,
    alignSelf: "stretch",
  },
  conElPlanPremiumDeZicofyWrapper: {
    borderRadius: Border.br_xl,
    backgroundColor: Color.colorIndianred,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    overflow: "hidden",
    justifyContent: "center",
    padding: Padding.p_xl,
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignSelf: "stretch",
    alignItems: "center",
    flex: 1,
  },
  ajustesPlanPremium: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    paddingTop: Padding.p_27xl,
    width: "100%",
    flex: 1,
    justifyContent: "space-between",
  },
});

export default AjustesPlanPremium;
