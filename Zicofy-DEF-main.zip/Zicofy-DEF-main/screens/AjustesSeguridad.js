import React, { useState, useCallback } from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
  Modal,
} from "react-native";
import { Image } from "expo-image";
import { Input } from "@rneui/themed";
import { useNavigation } from "@react-navigation/native";
import Property1Default3 from "../components/Property1Default3";
import ModalDeleteAccount from "../components/ModalDeleteAccount";
import { FontFamily, FontSize, Color, Border, Padding } from "../GlobalStyles";

const AjustesSeguridad = () => {
  const navigation = useNavigation();
  const [botonVisible, setBotonVisible] = useState(false);

  const openBoton = useCallback(() => {
    setBotonVisible(true);
  }, []);

  const closeBoton = useCallback(() => {
    setBotonVisible(false);
  }, []);

  return (
    <>
      <View style={styles.ajustesSeguridad}>
        <View style={styles.contenido}>
          <View style={[styles.logo, styles.logoFlexBox]}>
            <Pressable
              style={styles.volver}
              onPress={() => navigation.goBack()}
            >
              <Image
                style={styles.icon}
                contentFit="cover"
                source={require("../assets/volver.png")}
              />
            </Pressable>
            <ImageBackground
              style={styles.logoIcon}
              resizeMode="center"
              source={require("../assets/logo.png")}
            />
            <Image
              style={styles.notificationsIcon}
              contentFit="cover"
              source={require("../assets/notifications.png")}
            />
          </View>
          <ScrollView
            style={[styles.interactuable, styles.botonSpaceBlock]}
            showsVerticalScrollIndicator={false}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.interactuableScrollViewContent}
          >
            <View style={[styles.iniciaSesion, styles.logoFlexBox]}>
              <Text style={styles.titulo}>Seguridad</Text>
            </View>
            <View style={[styles.explicacion, styles.botonSpaceBlock]}>
              <Text
                style={[styles.texto, styles.textoFlexBox]}
              >{`En Zicofy, tu seguridad es nuestra prioridad. No almacenamos tus datos más allá de lo necesario para ofrecerte una experiencia personalizada. Una vez que ya no son necesarios, los datos se eliminan de forma segura.
Puedes estar tranquilo/a de que tu información está manejada con el mayor cuidado y protección.`}</Text>
            </View>
            <View style={[styles.inputs, styles.botonSpaceBlock]}>
              <Input
                style={styles.input}
                label="Contraseña anterior"
                placeholder="*********"
                required={true}
                leftIcon={{ name: "lock-outline", type: "material-community" }}
                rightIcon={{
                  name: "eye-off-outline",
                  type: "material-community",
                }}
                inputStyle={{ color: "#292929" }}
              />
              <Input
                style={styles.input1}
                label="Nueva contraseña"
                placeholder="**********"
                required={true}
                leftIcon={{ name: "lock-outline", type: "material-community" }}
                rightIcon={{
                  name: "eye-off-outline",
                  type: "material-community",
                }}
                inputStyle={{ color: "#292929" }}
              />
              <Input
                style={styles.input1}
                label="Confirma tu nueva contraseña"
                placeholder="**********"
                required={true}
                leftIcon={{ name: "lock-outline", type: "material-community" }}
                rightIcon={{
                  name: "eye-off-outline",
                  type: "material-community",
                }}
                inputStyle={{ color: "#292929" }}
              />
            </View>
            <View style={[styles.inputs, styles.botonSpaceBlock]}>
              <Property1Default3
                texto="Actualizar datos"
                property1DefaultPosition="unset"
                property1DefaultAlignSelf="stretch"
                property1DefaultBackgroundColor="#ffd7f3"
                textoFlex={1}
                onIniciarSesinPress={() =>
                  navigation.navigate("DrawerRoot", {
                    screen: "BottomTabsRoot",
                  })
                }
              />
            </View>
            <Pressable
              style={[styles.boton, styles.botonSpaceBlock]}
              onPress={openBoton}
            >
              <Image
                style={styles.icon1}
                contentFit="cover"
                source={require("../assets/icon.png")}
              />
              <View style={[styles.editarPerfil, styles.logoFlexBox]}>
                <Text style={[styles.texto1, styles.textoFlexBox]}>
                  Eliminar mi cuenta
                </Text>
              </View>
            </Pressable>
          </ScrollView>
        </View>
      </View>

      <Modal animationType="fade" transparent visible={botonVisible}>
        <View style={styles.botonOverlay}>
          <Pressable style={styles.botonBg} onPress={closeBoton} />
          <ModalDeleteAccount onClose={closeBoton} />
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  logoFlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  botonSpaceBlock: {
    marginTop: 20,
    alignSelf: "stretch",
  },
  textoFlexBox: {
    textAlign: "left",
    fontFamily: FontFamily.poppinsRegular,
    flex: 1,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  logo: {
    alignSelf: "stretch",
    justifyContent: "space-between",
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    textAlign: "center",
    color: Color.colorGray_200,
    flex: 1,
  },
  iniciaSesion: {
    justifyContent: "center",
    alignSelf: "stretch",
  },
  texto: {
    fontSize: FontSize.size_lg,
    color: Color.colorGray_200,
  },
  explicacion: {
    flexDirection: "row",
    alignItems: "center",
  },
  input: {
    alignSelf: "stretch",
  },
  input1: {
    marginTop: 10,
    alignSelf: "stretch",
  },
  inputs: {
    alignItems: "center",
  },
  botonOverlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(113, 113, 113, 0.3)",
  },
  botonBg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    left: 0,
    top: 0,
  },
  icon1: {
    width: 23,
    height: 23,
  },
  texto1: {
    fontSize: FontSize.size_sm,
    color: "#ff0000",
  },
  editarPerfil: {
    marginLeft: 15,
    flex: 1,
  },
  boton: {
    borderRadius: Border.br_mini,
    backgroundColor: Color.colorWhitesmoke_200,
    paddingHorizontal: Padding.p_mini,
    paddingVertical: Padding.p_3xs,
    flexDirection: "row",
    alignItems: "center",
  },
  interactuable: {
    flex: 1,
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignSelf: "stretch",
    alignItems: "center",
    flex: 1,
  },
  ajustesSeguridad: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    paddingTop: Padding.p_27xl,
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    flex: 1,
  },
});

export default AjustesSeguridad;
