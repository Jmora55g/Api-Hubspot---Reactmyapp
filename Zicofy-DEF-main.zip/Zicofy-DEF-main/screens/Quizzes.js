import * as React from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border, Padding } from "../GlobalStyles";

const Quizzes = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.quizzes, styles.navbarBg]}>
      <View style={styles.contenido}>
        <View style={[styles.logo, styles.logoFlexBox]}>
          <Pressable
            style={styles.sidebar}
            onPress={() => navigation.toggleDrawer()}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/sidebar.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo1.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <ScrollView
          style={[styles.interactuable, styles.interactuableSpaceBlock]}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.interactuableScrollViewContent}
        >
          <View style={styles.logoFlexBox}>
            <Text style={styles.texto}>
              <Text
                style={styles.bienvenidoALa}
              >{`Bienvenido a la sección de Tests, donde puedes obtener insights y divertirte aprendiendo, `}</Text>
              <Text style={styles.todoDeForma}>¡todo de forma gratuita!</Text>
              <Text style={styles.bienvenidoALa}>
                {" "}
                Comienza con el Test de Bienestar.
              </Text>
            </Text>
          </View>
          <Pressable
            style={[styles.testDeBienestar, styles.interactuableSpaceBlock]}
            onPress={() => navigation.navigate("QuizAdentro")}
          >
            <ImageBackground
              style={styles.imageIcon}
              resizeMode="center"
              source={require("../assets/image.png")}
            />
            <View style={styles.textos}>
              <Text style={[styles.categora, styles.tituloFlexBox]}>
                Bienestar
              </Text>
              <Text style={[styles.titulo, styles.tituloFlexBox]}>
                Test de Bienestar
              </Text>
            </View>
          </Pressable>
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  navbarBg: {
    backgroundColor: Color.colorsNeutralWhite,
    justifyContent: "space-between",
  },
  logoFlexBox: {
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  interactuableSpaceBlock: {
    marginTop: 20,
    alignSelf: "stretch",
  },
  tituloFlexBox: {
    color: Color.colorsNeutralWhite,
    textAlign: "left",
    alignSelf: "stretch",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  sidebar: {
    height: 17,
    width: 25,
  },
  logoIcon: {
    height: 45,
    width: 40,
  },
  notificationsIcon: {
    height: 27,
    width: 25,
  },
  logo: {
    justifyContent: "space-between",
  },
  bienvenidoALa: {
    fontFamily: FontFamily.poppinsRegular,
  },
  todoDeForma: {
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
  },
  texto: {
    color: Color.colorGray_200,
    textAlign: "left",
    fontSize: FontSize.size_lg,
    flex: 1,
  },
  imageIcon: {
    borderRadius: Border.br_6xl,
    width: 380,
    height: 368,
    zIndex: 0,
  },
  categora: {
    fontSize: FontSize.size_base,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
  },
  titulo: {
    lineHeight: 22,
    fontWeight: "800",
    fontFamily: FontFamily.poppinsExtraBold,
    marginTop: 279,
    fontSize: FontSize.size_lg,
    color: Color.colorsNeutralWhite,
  },
  textos: {
    position: "absolute",
    marginLeft: -162,
    top: 21,
    left: "50%",
    width: 346,
    height: 325,
    zIndex: 1,
    justifyContent: "center",
  },
  testDeBienestar: {
    justifyContent: "center",
    alignItems: "center",
  },
  interactuable: {
    flex: 1,
  },
  contenido: {
    height: 750,
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignSelf: "stretch",
    alignItems: "center",
  },
  quizzes: {
    height: 873,
    paddingTop: Padding.p_27xl,
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    flex: 1,
  },
});

export default Quizzes;
