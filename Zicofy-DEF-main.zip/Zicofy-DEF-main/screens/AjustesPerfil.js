import * as React from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
} from "react-native";
import { Image } from "expo-image";
import { Input } from "@rneui/themed";
import { useNavigation } from "@react-navigation/native";
import Property1Default3 from "../components/Property1Default3";
import { FontSize, FontFamily, Color, Padding } from "../GlobalStyles";

const AjustesPerfil = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.ajustesPerfil}>
      <View style={styles.contenido}>
        <View style={[styles.logo, styles.logoFlexBox]}>
          <Pressable style={styles.volver} onPress={() => navigation.goBack()}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/volver.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <ScrollView
          style={[styles.interactuable, styles.inputsSpaceBlock]}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.interactuableScrollViewContent}
        >
          <View style={[styles.iniciaSesion, styles.logoFlexBox]}>
            <Text style={styles.titulo}>Editar perfil</Text>
          </View>
          <View style={[styles.explicacion, styles.inputsSpaceBlock]}>
            <Text style={styles.texto}>
              <Text
                style={styles.actualizaTuInformacin}
              >{`Actualiza tu información aquí. Cuanto más sepamos de ti, `}</Text>
              <Text style={styles.msPersonalizada}>más personalizada</Text>
              <Text
                style={styles.actualizaTuInformacin}
              >{` será tu experiencia en Zicofy. La personalización mejora la selección de tu Zico.
¡Completa tu perfil ahora!`}</Text>
            </Text>
          </View>
          <View style={[styles.inputs, styles.inputsSpaceBlock]}>
            <Input
              style={styles.input}
              label="Correo electrónico"
              placeholder="Ingresa tu correo electrónico"
              required={false}
              leftIcon={{ name: "email-outline", type: "material-community" }}
              inputStyle={{ color: "#000" }}
            />
            <Input
              style={styles.input1}
              label="Nombre"
              placeholder="María"
              required={true}
              leftIcon={{ name: "account-outline", type: "material-community" }}
              inputStyle={{ color: "#0b0b0b" }}
            />
            <Input
              style={styles.input1}
              label="Fecha de nacimiento"
              placeholder="04-11-1998"
              leftIcon={{ name: "calendar-blank", type: "material-community" }}
              inputStyle={{ color: "#0b0b0b" }}
            />
            <Input
              style={styles.input1}
              label="Número de teléfono"
              placeholder="+34 123456789"
              leftIcon={{ name: "phone", type: "material-community" }}
              inputStyle={{ color: "#0b0b0b" }}
            />
          </View>
          <View style={[styles.inputs, styles.inputsSpaceBlock]}>
            <Property1Default3
              texto="Actualizar datos"
              property1DefaultPosition="unset"
              property1DefaultAlignSelf="stretch"
              property1DefaultBackgroundColor="#ffd7f3"
              textoFlex={1}
              onIniciarSesinPress={() =>
                navigation.navigate("DrawerRoot", { screen: "BottomTabsRoot" })
              }
            />
          </View>
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  logoFlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  inputsSpaceBlock: {
    marginTop: 20,
    alignSelf: "stretch",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  logo: {
    alignSelf: "stretch",
    justifyContent: "space-between",
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    textAlign: "center",
    color: Color.colorGray_200,
    flex: 1,
  },
  iniciaSesion: {
    justifyContent: "center",
    alignSelf: "stretch",
  },
  actualizaTuInformacin: {
    fontFamily: FontFamily.poppinsRegular,
    color: Color.colorGray_200,
  },
  msPersonalizada: {
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.colorLightskyblue,
  },
  texto: {
    fontSize: FontSize.size_lg,
    textAlign: "left",
    flex: 1,
  },
  explicacion: {
    flexDirection: "row",
    alignItems: "center",
  },
  input: {
    alignSelf: "stretch",
  },
  input1: {
    marginTop: 10,
    alignSelf: "stretch",
  },
  inputs: {
    alignItems: "center",
  },
  interactuable: {
    flex: 1,
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignSelf: "stretch",
    alignItems: "center",
    flex: 1,
  },
  ajustesPerfil: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    paddingTop: Padding.p_27xl,
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    flex: 1,
  },
});

export default AjustesPerfil;
