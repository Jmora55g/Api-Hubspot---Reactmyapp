import React, { useState } from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
} from "react-native";
import { Image } from "expo-image";
import { CheckBox } from "@ui-kitten/components";
import { useNavigation } from "@react-navigation/native";
import Property1Default3 from "../components/Property1Default3";
import { FontFamily, FontSize, Color, Padding } from "../GlobalStyles";

const QuizAdentroPreguntas = () => {
  const [checkboxchecked, setCheckboxchecked] = useState(false);
  const [checkbox1checked, setCheckbox1checked] = useState(false);
  const [checkbox2checked, setCheckbox2checked] = useState(false);
  const [checkbox3checked, setCheckbox3checked] = useState(false);
  const [checkbox4checked, setCheckbox4checked] = useState(false);
  const [checkbox5checked, setCheckbox5checked] = useState(false);
  const [checkbox6checked, setCheckbox6checked] = useState(false);
  const [checkbox7checked, setCheckbox7checked] = useState(false);
  const [checkbox8checked, setCheckbox8checked] = useState(false);
  const [checkbox9checked, setCheckbox9checked] = useState(false);
  const [checkbox10checked, setCheckbox10checked] = useState(false);
  const [checkbox11checked, setCheckbox11checked] = useState(false);
  const [checkbox12checked, setCheckbox12checked] = useState(false);
  const [checkbox13checked, setCheckbox13checked] = useState(false);
  const [checkbox14checked, setCheckbox14checked] = useState(false);
  const [checkbox15checked, setCheckbox15checked] = useState(false);
  const [checkbox16checked, setCheckbox16checked] = useState(false);
  const [checkbox17checked, setCheckbox17checked] = useState(false);
  const [checkbox18checked, setCheckbox18checked] = useState(false);
  const [checkbox19checked, setCheckbox19checked] = useState(false);
  const navigation = useNavigation();

  return (
    <View style={[styles.quizAdentroPreguntas, styles.logoFlexBox]}>
      <View style={[styles.contenido, styles.contenidoFlexBox]}>
        <View style={[styles.logo, styles.logoFlexBox]}>
          <Pressable style={styles.volver} onPress={() => navigation.goBack()}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/volver.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <ScrollView
          style={styles.interactuable}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.interactuableScrollViewContent}
        >
          <View style={[styles.iniciaSesion, styles.iniciaSesionFlexBox]}>
            <Text style={styles.titulo}>Test de Bienestar Emocional</Text>
          </View>
          <Pressable style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkboxchecked}
              onChange={() => setCheckboxchecked(!checkboxchecked)}
              check="checkbox"
            />
            <Text style={[styles.texto, styles.textoTypo]}>
              Prefiero contar todo lo que me preocupa, sin que me interrumpan.
            </Text>
          </Pressable>
          <Pressable style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkbox1checked}
              onChange={() => setCheckbox1checked(!checkbox1checked)}
            />
            <Text style={[styles.texto1, styles.textoTypo]}>
              Me incomoda que me escuchen sin decirme nada sobre lo que estoy
              contando.
            </Text>
          </Pressable>
          <View style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkbox2checked}
              onChange={() => setCheckbox2checked(!checkbox2checked)}
            />
            <Text style={[styles.texto1, styles.textoTypo]}>
              Me resulta interesante que me hagan preguntas sobre lo que estamos
              conversando y me lleve a pensar cosas que no me había planteado.
            </Text>
          </View>
          <Pressable style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkbox3checked}
              onChange={() => setCheckbox3checked(!checkbox3checked)}
            />
            <Text style={[styles.texto, styles.textoTypo]}>
              Siento que lo que me pasa tiene tanto que ver con mi familia que
              deberían estar ellos sentados a mi lado en estas conversaciones.
            </Text>
          </Pressable>
          <Pressable style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkbox4checked}
              onChange={() => setCheckbox4checked(!checkbox4checked)}
            />
            <Text style={[styles.texto, styles.textoTypo]}>
              Me siento más cómodo si mi interlocutor me escucha sin tener que
              mirarlo. Siento que me surgen más cosas para contarle.
            </Text>
          </Pressable>
          <Pressable style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkbox5checked}
              onChange={() => setCheckbox5checked(!checkbox5checked)}
            />
            <Text style={[styles.texto, styles.textoTypo]}>
              A veces, siento que necesito que me digan lo que debería hacer.
            </Text>
          </Pressable>
          <Pressable style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkbox6checked}
              onChange={() => setCheckbox6checked(!checkbox6checked)}
            />
            <Text style={[styles.texto, styles.textoTypo]}>
              Intento cambiar algunos hábitos que siento me hacen mal, pero no
              encuentro la forma.
            </Text>
          </Pressable>
          <Pressable style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkbox7checked}
              onChange={() => setCheckbox7checked(!checkbox7checked)}
            />
            <Text style={[styles.texto, styles.textoTypo]}>
              A veces siento que tropiezo una y otra vez con la misma piedra,
              ¿cómo puede ser que me vuelva a pasar?
            </Text>
          </Pressable>
          <Pressable style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkbox8checked}
              onChange={() => setCheckbox8checked(!checkbox8checked)}
            />
            <Text style={[styles.texto, styles.textoTypo]}>
              En ocasiones pienso que no pueden estar sucediéndome sólo a mí
              estas cosas, ¿cómo harán las demás personas en estas situaciones?
            </Text>
          </Pressable>
          <Pressable style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkbox9checked}
              onChange={() => setCheckbox9checked(!checkbox9checked)}
            />
            <Text style={[styles.texto, styles.textoTypo]}>
              A veces, frente a algunas situaciones vuelvo a sentirme como
              cuando era pequeño y siento que no puedo enfrentarlas sin ayuda de
              algún adulto.
            </Text>
          </Pressable>
          <Pressable style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkbox10checked}
              onChange={() => setCheckbox10checked(!checkbox10checked)}
            />
            <Text style={[styles.texto, styles.textoTypo]}>
              Cuando cuento lo que siento que me preocupa, me molesta que mi
              interlocutor no haga ni un gesto de estar sensibilizado por lo que
              me pasa.
            </Text>
          </Pressable>
          <Pressable style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkbox11checked}
              onChange={() => setCheckbox11checked(!checkbox11checked)}
            />
            <Text style={[styles.texto, styles.textoTypo]}>
              Yo prefiero sacar todo lo que me preocupa sin tener que estar
              pensando en cómo le cae a quien se lo estoy diciendo. En ocasiones
              me da lo mismo que esté o no esté ahí.
            </Text>
          </Pressable>
          <Pressable style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkbox12checked}
              onChange={() => setCheckbox12checked(!checkbox12checked)}
            />
            <Text style={[styles.texto, styles.textoTypo]}>
              Siento que abrí un grifo de emociones y estuve todo el tiempo
              descargándome y no di lugar ni a meter ni un comentario a mi
              interlocutor, ¡me siento tan aliviado!
            </Text>
          </Pressable>
          <Pressable style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkbox13checked}
              onChange={() => setCheckbox13checked(!checkbox13checked)}
            />
            <Text style={[styles.texto, styles.textoTypo]}>
              Necesito entender por qué me cuesta tanto relacionarme con algunas
              personas. Nunca me siento como un par y eso me hace retraerme y
              evitar esos momentos.
            </Text>
          </Pressable>
          <Pressable style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkbox14checked}
              onChange={() => setCheckbox14checked(!checkbox14checked)}
            />
            <Text style={[styles.texto, styles.textoTypo]}>
              Acabo de darme cuenta de que hice/dije algo exactamente igual a
              como lo hacía mi padre/madre.
            </Text>
          </Pressable>
          <Pressable style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkbox15checked}
              onChange={() => setCheckbox15checked(!checkbox15checked)}
            />
            <Text style={[styles.texto, styles.textoTypo]}>
              ¿Si elijo esta? ¿Y si elijo la otra? ¿O esta otra también?
              ¡Ahhhhgg! ¡No sé qué hacer! Y el tiempo pasa…
            </Text>
          </Pressable>
          <Pressable style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkbox16checked}
              onChange={() => setCheckbox16checked(!checkbox16checked)}
            />
            <Text style={[styles.texto1, styles.textoTypo]}>
              De todo lo que me pasa, la culpa la tienen mis
              padres/parientes/compañeros de clase/familia/etc… ¿Por qué tengo
              que ser yo quien haga algo con eso?
            </Text>
          </Pressable>
          <Pressable style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkbox17checked}
              onChange={() => setCheckbox17checked(!checkbox17checked)}
            />
            <Text style={[styles.texto, styles.textoTypo]}>
              Siento frustración porque no he podido hacer lo que quiero. Me
              parece que ya es tarde para intentarlo.
            </Text>
          </Pressable>
          <Pressable style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkbox18checked}
              onChange={() => setCheckbox18checked(!checkbox18checked)}
            />
            <Text style={[styles.texto, styles.textoTypo]}>
              Todos esperan algo específico de mí. Pero nadie me pregunta qué es
              lo que yo quiero.
            </Text>
          </Pressable>
          <Pressable style={[styles.pregunta1, styles.contenidoFlexBox]}>
            <CheckBox
              style={styles.checkbox}
              status="info"
              checked={checkbox19checked}
              onChange={() => setCheckbox19checked(!checkbox19checked)}
            />
            <Text style={[styles.texto, styles.textoTypo]}>
              No me interesa ahondar en el pasado. Sólo quiero resolver esto
              aquí y ahora. Me urge.
            </Text>
          </Pressable>
          <Pressable
            style={[styles.finalizarTest, styles.iniciaSesionFlexBox]}
            onPress={() => navigation.navigate("QuizCompletado")}
          >
            <Property1Default3
              texto="Finalizar Test de Bienestar"
              property1DefaultPosition="unset"
              property1DefaultAlignSelf="stretch"
              property1DefaultBackgroundColor="#ffd7f3"
              textoFlex={1}
              onIniciarSesinPress={() => navigation.navigate("QuizCompletado")}
            />
          </Pressable>
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  logoFlexBox: {
    justifyContent: "space-between",
    alignItems: "center",
  },
  contenidoFlexBox: {
    alignItems: "center",
    alignSelf: "stretch",
  },
  iniciaSesionFlexBox: {
    justifyContent: "center",
    alignSelf: "stretch",
    alignItems: "center",
  },
  textoTypo: {
    marginLeft: 10,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_base,
    textAlign: "left",
    color: Color.colorGray_200,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  logo: {
    flexDirection: "row",
    alignSelf: "stretch",
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    textAlign: "left",
    color: Color.colorGray_200,
    flex: 1,
  },
  iniciaSesion: {
    flexDirection: "row",
  },
  checkbox: {
    flexDirection: "row",
  },
  texto: {
    flex: 1,
  },
  pregunta1: {
    marginTop: 20,
    flexDirection: "row",
    alignSelf: "stretch",
  },
  texto1: {
    width: 340,
  },
  finalizarTest: {
    marginTop: 20,
  },
  interactuable: {
    marginTop: 20,
    alignSelf: "stretch",
    flex: 1,
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignSelf: "stretch",
    flex: 1,
  },
  quizAdentroPreguntas: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    paddingTop: Padding.p_27xl,
    paddingBottom: Padding.p_xl,
    width: "100%",
    flex: 1,
  },
});

export default QuizAdentroPreguntas;
