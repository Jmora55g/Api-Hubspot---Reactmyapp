import * as React from "react";
import { Pressable, StyleSheet, View, Text, TextInput } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontSize, Color, FontFamily, Padding, Border } from "../GlobalStyles";

const ZicochatConversacion = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.zicochatConversacion, styles.topBarFlexBox]}>
      <View style={[styles.contenido, styles.contenidoFlexBox]}>
        <View style={[styles.topBar, styles.topBarFlexBox]}>
          <Pressable style={styles.volver} onPress={() => navigation.goBack()}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/volver2.png")}
            />
          </Pressable>
          <View style={styles.userParentFlexBox}>
            <View style={styles.userParentFlexBox}>
              <View style={[styles.imagen1, styles.userParentFlexBox]}>
                <Image
                  style={styles.imagenIcon}
                  contentFit="cover"
                  source={require("../assets/imagen1.png")}
                />
              </View>
              <Image
                style={[styles.onlineIcon, styles.onlineIconPosition]}
                contentFit="cover"
                source={require("../assets/online.png")}
              />
            </View>
            <View style={[styles.nombre, styles.userParentFlexBox]}>
              <Text style={styles.texto}>Zico AI</Text>
            </View>
          </View>
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <View style={[styles.interactuable, styles.contenidoFlexBox]}>
          <View style={styles.messageFlexBox1}>
            <View style={styles.messageFlexBox}>
              <View style={[styles.username, styles.userParentFlexBox]}>
                <Text style={[styles.agustnRodrguez, styles.zicoAiTypo]}>
                  Agustín Rodríguez
                </Text>
              </View>
              <View style={[styles.mensaje, styles.mensajeFlexBox]}>
                <Text style={[styles.holaQueridaZico, styles.zicoFlexBox]}>
                  Hola querida Zico ¿cómo estás?
                </Text>
              </View>
            </View>
            <View style={[styles.user, styles.userParentFlexBox]}>
              <Image
                style={styles.userChild}
                contentFit="cover"
                source={require("../assets/ellipse-3.png")}
              />
            </View>
          </View>
          <View style={[styles.chatMessage, styles.messageFlexBox1]}>
            <View style={[styles.user1, styles.userParentFlexBox]}>
              <Image
                style={[styles.imagenIcon1, styles.frameItemLayout]}
                contentFit="cover"
                source={require("../assets/imagen11.png")}
              />
            </View>
            <View style={[styles.message1, styles.messageFlexBox]}>
              <View style={[styles.username, styles.userParentFlexBox]}>
                <Text style={[styles.zicoAi, styles.zicoFlexBox]}>Zico AI</Text>
              </View>
              <View style={[styles.mensaje, styles.mensajeFlexBox]}>
                <Text style={[styles.todoPerfectoAgus, styles.zicoFlexBox]}>
                  Todo perfecto Agus ¿En qué puedo ayudarte hoy?
                </Text>
              </View>
            </View>
          </View>
        </View>
      </View>
      <View style={[styles.frameParent, styles.mensajeFlexBox]}>
        <TextInput
          style={[styles.frameChild, styles.contenidoFlexBox]}
          placeholder="Escribe tu mensaje"
          autoCapitalize="sentences"
          multiline={true}
          placeholderTextColor="#797c7b"
        />
        <Pressable
          style={[styles.ellipseParent, styles.userParentFlexBox]}
          button="enviar_mensaje"
        >
          <Image
            style={[styles.frameItem, styles.frameItemLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-441.png")}
          />
          <Image
            style={[styles.frameInner, styles.onlineIconPosition]}
            contentFit="cover"
            source={require("../assets/vector-896.png")}
          />
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  topBarFlexBox: {
    justifyContent: "space-between",
    alignItems: "center",
  },
  contenidoFlexBox: {
    alignItems: "center",
    alignSelf: "stretch",
  },
  userParentFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  onlineIconPosition: {
    zIndex: 1,
    position: "absolute",
  },
  zicoAiTypo: {
    lineHeight: 14,
    fontSize: FontSize.size_sm,
    color: Color.colorGray_400,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  mensajeFlexBox: {
    backgroundColor: Color.colorLightskyblue,
    flexDirection: "row",
    alignSelf: "stretch",
  },
  zicoFlexBox: {
    textAlign: "left",
    flex: 1,
  },
  messageFlexBox1: {
    justifyContent: "flex-end",
    flexDirection: "row",
    alignSelf: "stretch",
  },
  frameItemLayout: {
    height: 40,
    width: 40,
  },
  messageFlexBox: {
    alignItems: "flex-end",
    flex: 1,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  imagenIcon: {
    borderRadius: 36,
    width: 72,
    height: 72,
  },
  imagen1: {
    zIndex: 0,
    flexDirection: "row",
  },
  onlineIcon: {
    marginTop: 22,
    marginLeft: 22,
    top: "50%",
    left: "50%",
    width: 8,
    height: 8,
  },
  texto: {
    fontSize: FontSize.size_xl,
    lineHeight: 16,
    textAlign: "center",
    color: Color.colorGray_400,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  nombre: {
    marginTop: 8,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  topBar: {
    flexDirection: "row",
    alignSelf: "stretch",
  },
  agustnRodrguez: {
    textAlign: "right",
    flex: 1,
  },
  username: {
    flexDirection: "row",
    alignSelf: "stretch",
  },
  holaQueridaZico: {
    color: Color.colorsNeutralWhite,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_base,
    textAlign: "left",
  },
  mensaje: {
    flexWrap: "wrap",
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: Padding.p_8xs,
    marginTop: 5,
    borderRadius: Border.br_xl,
  },
  userChild: {
    width: 41,
    height: 41,
  },
  user: {
    marginLeft: 6,
    flexDirection: "row",
  },
  imagenIcon1: {
    borderRadius: Border.br_12xl,
  },
  user1: {
    flexDirection: "row",
  },
  zicoAi: {
    lineHeight: 14,
    fontSize: FontSize.size_sm,
    color: Color.colorGray_400,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  todoPerfectoAgus: {
    display: "flex",
    color: Color.colorsNeutralWhite,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_base,
    textAlign: "left",
    alignSelf: "stretch",
    alignItems: "center",
  },
  message1: {
    marginLeft: 6,
  },
  chatMessage: {
    marginTop: 20,
  },
  interactuable: {
    marginTop: 40,
    alignSelf: "stretch",
    flex: 1,
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignSelf: "stretch",
    flex: 1,
  },
  frameChild: {
    backgroundColor: "#f3f6f6",
    padding: Padding.p_3xs,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    fontSize: 12,
    borderRadius: Border.br_xl,
    flexDirection: "row",
    alignSelf: "stretch",
    flex: 1,
  },
  frameItem: {
    zIndex: 0,
  },
  frameInner: {
    height: "60.5%",
    width: "53%",
    top: "23.25%",
    right: "17.75%",
    bottom: "16.25%",
    left: "29.25%",
    borderRadius: 2,
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
  },
  ellipseParent: {
    marginLeft: 15,
    flexDirection: "row",
  },
  frameParent: {
    padding: Padding.p_xl,
    justifyContent: "center",
    alignItems: "center",
  },
  zicochatConversacion: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    paddingTop: Padding.p_27xl,
    width: "100%",
    flex: 1,
  },
});

export default ZicochatConversacion;
