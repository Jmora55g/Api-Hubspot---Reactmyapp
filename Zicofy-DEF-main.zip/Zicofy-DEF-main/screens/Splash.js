import * as React from "react";
import { View, ImageBackground, StyleSheet } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Padding } from "../GlobalStyles";

const Splash = () => {
  return (
    <LinearGradient
      style={[styles.splash, styles.logoFlexBox]}
      locations={[0, 1]}
      colors={["#74c2ef", "#ffd7f3"]}
    >
      <View style={[styles.logo, styles.logoFlexBox]}>
        <ImageBackground
          style={styles.imagenIcon}
          resizeMode="cover"
          source={require("../assets/imagen.png")}
        />
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  logoFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  imagenIcon: {
    width: 97,
    height: 109,
  },
  logo: {
    flexDirection: "row",
  },
  splash: {
    flex: 1,
    width: "100%",
    height: 873,
    overflow: "hidden",
    paddingHorizontal: Padding.p_xl,
    paddingVertical: Padding.p_27xl,
    backgroundColor: "transparent",
  },
});

export default Splash;
