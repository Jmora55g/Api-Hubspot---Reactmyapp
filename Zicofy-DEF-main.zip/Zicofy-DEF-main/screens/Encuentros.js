import * as React from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  Text,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Padding, Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const Encuentros = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.encuentros}>
      <View style={[styles.contenido, styles.logoFlexBox]}>
        <View style={[styles.logo, styles.logoFlexBox]}>
          <Pressable
            style={styles.sidebar}
            onPress={() => navigation.toggleDrawer()}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/sidebar.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo1.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <View style={[styles.interactuable, styles.subtituloFlexBox]}>
          <View style={[styles.encuentros1, styles.navbarFlexBox]}>
            <Text style={[styles.titulo, styles.dataFlexBox]} numberOfLines={1}>
              Tu próximo encuentro
            </Text>
            <Text style={[styles.data, styles.dataTypo]} numberOfLines={1}>
              Jueves 9 de Noviembre, 16.00 hs
            </Text>
          </View>
          <View style={[styles.explicacion, styles.subtituloFlexBox]}>
            <Text
              style={[styles.texto, styles.dataTypo]}
            >{`Agenda encuentros con tu Zico, seleccionado por nuestra IA, en el calendario. 

¡Elige un horario, y comienza a trabajar en tu bienestar emocional!`}</Text>
          </View>
          <View style={[styles.subtitulo, styles.subtituloFlexBox]}>
            <Text
              style={[styles.subtitulo1, styles.tituloTypo]}
              numberOfLines={1}
            >
              Agenda tu encuentro
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  logoFlexBox: {
    alignSelf: "stretch",
    alignItems: "center",
  },
  subtituloFlexBox: {
    marginTop: 20,
    alignSelf: "stretch",
    alignItems: "center",
  },
  navbarFlexBox: {
    paddingVertical: Padding.p_xl,
    alignSelf: "stretch",
    alignItems: "center",
  },
  dataFlexBox: {
    color: Color.colorsNeutralWhite,
    lineHeight: 28,
    textAlign: "center",
    alignSelf: "stretch",
  },
  dataTypo: {
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_lg,
  },
  tituloTypo: {
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_lg,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  sidebar: {
    height: 17,
    width: 25,
  },
  logoIcon: {
    height: 45,
    width: 40,
  },
  notificationsIcon: {
    height: 27,
    width: 25,
  },
  logo: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  titulo: {
    textAlign: "center",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_lg,
  },
  data: {
    marginTop: 5,
    textAlign: "center",
    color: Color.colorsNeutralWhite,
    lineHeight: 28,
    alignSelf: "stretch",
  },
  encuentros1: {
    borderRadius: Border.br_mini,
    backgroundColor: Color.colorLightskyblue,
    paddingHorizontal: Padding.p_mini,
    justifyContent: "center",
  },
  texto: {
    color: Color.colorGray_200,
    textAlign: "left",
    flex: 1,
  },
  explicacion: {
    flexDirection: "row",
  },
  subtitulo1: {
    color: Color.colorGray_500,
    textAlign: "center",
    flex: 1,
  },
  subtitulo: {
    justifyContent: "center",
    flexDirection: "row",
  },
  interactuable: {
    flex: 1,
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    flex: 1,
  },
  encuentros: {
    height: 873,
    paddingTop: Padding.p_27xl,
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    flex: 1,
    backgroundColor: Color.colorsNeutralWhite,
  },
});

export default Encuentros;
