import * as React from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Component1 from "../components/Component1";
import Property1Default1 from "../components/Property1Default1";
import { Padding, Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const Onboarding2 = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.onboarding2, styles.logoFlexBox1]}>
      <View style={[styles.contenido, styles.contenidoSpaceBlock]}>
        <View style={[styles.logo, styles.logoFlexBox]}>
          <Pressable style={styles.volver} onPress={() => navigation.goBack()}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/volver.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <ScrollView
          style={styles.interactuable}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.interactuableScrollViewContent}
        >
          <View style={[styles.tituloPantalla, styles.botonFlexBox]}>
            <Text style={[styles.titulo, styles.textoFlexBox]}>
              Tu amigo graduado en psicología 📚
            </Text>
          </View>
          <View style={[styles.explicacion, styles.logoFlexBox]}>
            <Text style={[styles.texto, styles.textoFlexBox]}>
              <Text style={styles.completaNuestro}>{`Completa nuestro `}</Text>
              <Text style={styles.testDeBienestar}>Test de Bienestar</Text>
              <Text
                style={styles.completaNuestro}
              >{` y la IA te emparejará con tu `}</Text>
              <Text style={styles.testDeBienestar}>Zico ideal</Text>
              <Text style={styles.completaNuestro}>{`.

Programa `}</Text>
              <Text style={styles.testDeBienestar}>encuentros</Text>
              <Text
                style={styles.completaNuestro}
              >{`, chatea por videollamada y gestiona todo con facilidad desde nuestra app.

¡El primer encuentro es `}</Text>
              <Text style={styles.testDeBienestar}>GRATIS!</Text>
            </Text>
          </View>
          <View style={styles.ilustracion}>
            <ImageBackground
              style={styles.ilustracinIcon}
              resizeMode="cover"
              source={require("../assets/ilustracin.png")}
            />
          </View>
        </ScrollView>
      </View>
      <View style={[styles.barraBaja, styles.botonFlexBox]}>
        <View style={styles.botonFlexBox}>
          <Component1
            prop={require("../assets/21.png")}
            prop1={require("../assets/11.png")}
            prop2={require("../assets/21.png")}
            prop3={require("../assets/21.png")}
            viewPosition="unset"
          />
        </View>
        <View style={[styles.boton, styles.botonFlexBox]}>
          <Property1Default1
            texto="Conoce a tu Zico ideal"
            property1DefaultPosition="unset"
            textoFlex={1}
            textoFontSize={17}
            textoLineHeight={24}
            textoFontWeight="600"
            textoFontFamily="Poppins-SemiBold"
            textoColor="#292929"
            textoTextAlign="center"
            onBotnPress={() => navigation.navigate("Onboarding3")}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  logoFlexBox1: {
    justifyContent: "space-between",
    alignItems: "center",
  },
  contenidoSpaceBlock: {
    paddingHorizontal: Padding.p_xl,
    alignSelf: "stretch",
  },
  logoFlexBox: {
    flexDirection: "row",
    alignSelf: "stretch",
  },
  botonFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  textoFlexBox: {
    textAlign: "left",
    color: Color.colorGray_200,
    flex: 1,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  logo: {
    justifyContent: "space-between",
    alignItems: "center",
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
  },
  tituloPantalla: {
    flexDirection: "row",
    alignSelf: "stretch",
  },
  completaNuestro: {
    fontFamily: FontFamily.poppinsRegular,
  },
  testDeBienestar: {
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
  },
  texto: {
    fontSize: FontSize.size_lg,
  },
  explicacion: {
    marginTop: 20,
    alignItems: "center",
  },
  ilustracinIcon: {
    width: 271,
    height: 254,
  },
  ilustracion: {
    marginTop: 20,
    alignItems: "center",
  },
  interactuable: {
    marginTop: 20,
    alignSelf: "stretch",
    flex: 1,
  },
  contenido: {
    paddingVertical: 0,
    alignItems: "center",
    flex: 1,
  },
  boton: {
    marginTop: 15,
    alignSelf: "stretch",
  },
  barraBaja: {
    borderTopLeftRadius: Border.br_mini,
    borderTopRightRadius: Border.br_mini,
    backgroundColor: Color.colorLightskyblue,
    paddingTop: Padding.p_xl,
    paddingBottom: Padding.p_11xl,
    paddingHorizontal: Padding.p_xl,
    alignSelf: "stretch",
  },
  onboarding2: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    paddingTop: Padding.p_27xl,
    width: "100%",
    flex: 1,
  },
});

export default Onboarding2;
