import * as React from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
  Linking,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontSize, FontFamily, Color, Padding } from "../GlobalStyles";

const PoliticaPrivacidad = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.politicaPrivacidad, styles.contenidoFlexBox]}>
      <View style={[styles.contenido, styles.contenidoFlexBox]}>
        <View style={[styles.logo, styles.logoFlexBox]}>
          <Pressable style={styles.volver} onPress={() => navigation.goBack()}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/volver11.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <ScrollView
          style={[styles.interactuable, styles.explicacionSpaceBlock]}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.interactuableScrollViewContent}
        >
          <View style={[styles.iniciaSesion, styles.logoFlexBox]}>
            <Text style={[styles.titulo, styles.textoFlexBox]}>
              Política de privacidad
            </Text>
          </View>
          <View style={[styles.explicacion, styles.explicacionSpaceBlock]}>
            <Text style={[styles.texto, styles.textoFlexBox]}>
              <Text style={styles.polticaDePrivacidad}>{`Política de Privacidad
`}</Text>
              <Text style={styles.polticaDeProteccinDeDato}>
                {`POLÍTICA DE PROTECCIÓN DE DATOS PERSONALES
1. Introducción
Esta política de protección de datos personales (la “Política de Protección de Datos”) informa a los usuarios, que contactan con ZICOFY y los Suscriptores registrados (los “Suscriptores”, conforme se define en las “Condiciones Legales”) de la plataforma web y de la aplicación móvil de la Plataforma (conforme se define en las “Condiciones Legales”) que acceden a la misma a través de web ZICOFY (www.zicofy.com), sobre el tratamiento de sus datos personales que ZICOFY, proyecto representado por Mateo Agustín Fuentes (matt@zicofy.com) y Agustín Rodriguez (agus@zicofy.com) llevará a cabo como responsable del tratamiento. Esta Política de Protección de Datos forma parte de las Condiciones Legales gestionada por ZICOFY.
Los datos de contacto de ZICOFY son los siguientes: Calle Lanza, 11, Bajo Izquierda, 41003 Sevilla. Dirección de correo electrónico: hola@zicofy.com. Asimismo, para resolver cualquier duda relacionada con el tratamiento de sus datos personales puede ponerse en contacto directamente con cualquiera de los co-fundadores de ZICOFY en las siguientes direcciones: matt@zicofy.com y agus@zicofy.com.
Cualquier término definido utilizado que no se defina expresamente en la Política de Protección de Datos tendrá el significado que se le atribuye en las Condiciones Legales. Esta Política de Protección de Datos regula la recogida y el tratamiento por parte de ZICOFY de los datos personales de los Suscriptores que resulta del acceso a la Plataforma. EL SUSCRIPTOR DEBE LEER CON ATENCIÓN LA POLÍTICA DE PROTECCIÓN DE DATOS COMO PARTE DE LAS CONDICIONES LEGALES CADA VEZ QUE SE PROPONGA UTILIZAR LA PLATAFORMA O CUALQUIERA DE SUS CONTENIDOS O DE SUS SERVICIOS.
En todo caso, ZICOFY se reserva el derecho de modificar en cualquier momento la Política de Protección de Datos, advirtiéndolo oportunamente cuando proceda.
2. Categorías de datos personales tratados
Inicialmente todo Suscriptor puede contactar con ZICOFY a través de los diferentes canales que se presentan en el sitio web (www.zicofy.com), o si lo prefiere, con personal de ZICOFY a través del email: hola@zicofy.com.
El chatbot por WhatsApp es un mecanismo automatizado (un robot) que no toma decisiones con efectos jurídicos sobre los Suscriptores. El mismo no utiliza sistemas de inteligencia artificial. Dicho chatbot solo resuelve dudas iniciales de los Suscriptores sobre la Plataforma.
Los datos personales que el Suscriptor voluntariamente facilite a ZICOFY, a través de los medios de contacto disponibles -incluyendo el chatbot-, para realizar cualquier consulta o para contratar un servicio de los Zicos (conforme se define en las “Condiciones Legales”) registrándose en la Plataforma (como, por ejemplo, nombre, apellidos, email y otros datos identificativos o los datos de tarjeta de crédito para el cobro de los servicios), o los que se generen posteriormente serán objeto de tratamiento y ZICOFY será el responsable de dicho tratamiento.
Los datos que se soliciten al Suscriptor a través de los medios de contacto disponibles -incluyendo el chatbot- tendrán carácter obligatorio (si éstos son necesarios para prestar los servicios solicitados por el Suscriptor) salvo que se indique lo contrario. En el caso de que el Suscriptor no facilite los datos solicitados con carácter obligatorio, ZICOFY no podrá tramitar la solicitud correspondiente. Al introducir sus datos personales, el Suscriptor garantiza a ZICOFY que dichos datos son correctos, completos y veraces y que se refieren únicamente al Suscriptor y no a terceras personas.
En el caso de que los Suscriptores accedan a la Plataforma como beneficiarios de a) un programa de empresa (en el que la empresa abone el importe total del uso de la Plataforma en beneficio de sus trabajadores o un código de descuento) –“Programas de Empresas”- o b) un programa de un partner de ZICOFY –“Programas de Partners”-, las empresas o los partners facilitarán a ZICOFY datos identificativos de los Suscriptores (p.ej., su dirección de email) con el fin de que ZICOFY pueda reconocer a los Suscriptores que se registran y acceden a la Plataforma como beneficiarios de Programas de Empresas o Programas de Partners. La base jurídica para realizar dicho tratamiento es que dicha cesión es necesaria para que los Suscriptores puedan beneficiarse de los Programas de Empresas o de los Programas de Partners y que ZICOFY pueda gestionar los accesos de los Suscriptores a la Plataforma.
El Suscriptor queda informado de que una vez que se complete la conexión entre Zico y Suscriptor a través de la plataforma y se inicie la prestación de servicios de Encuentros, el Zico será el responsable único de los datos del Suscriptor que se recojan y se generen durante la prestación del servicio. ZICOFY actuará únicamente como plataforma de comunicación utilizada por el Zico para comunicarse con el Suscriptor y, por tanto, tendrá la condición única de prestador de servicios de alojamiento de datos y encargado del tratamiento.
Datos sensibles. BAJO NINGUNA CIRCUNSTANCIA EXISTIRÁ EL MANEJO DE DATOS MÉDICOS, DATOS DE SALUD O DE HISTORIA CLÍNICA EN LA PLATAFORMA. ZICOFY no recogerá nunca este tipo de datos, ya que de ninguna manera están asociados con su actividad. De forma excepcional, ZICOFY podría recoger algún dato sensible del Suscriptor sujeto siempre a su consentimiento libre y expreso (p.ej., al completar de forma voluntaria encuestas de satisfacción y de calidad del servicio) o si dicho tratamiento de datos es necesario para la prestación del servicio de Encuentros (p.ej., al completar determinadas preguntas que pueden realizarse con el fin de identificar el Zico más apropiado al Suscriptor).
3. Finalidades y bases jurídicas del tratamiento
Salvo que otra cosa se indique al Suscriptor, la recogida y tratamiento de los datos personales por ZICOFY tiene como finalidad:
La gestión y control de las solicitudes de información de los Suscriptores sobre la Plataforma.En caso de que los Suscriptores contacten con ZICOFY a través del chatbot o a través del email de contacto, el responsable del tratamiento tratará los datos personales de los Suscriptores para poder gestionar dicha solicitud.Controlar la seguridad informática de la Plataforma.
La base legal para llevar a cabo dicho tratamiento es que éste es necesario para que ZICOFY pueda atender las consultas de los Suscriptores y gestionar la seguridad de la Plataforma.
La gestión, desarrollo y control de la relación contractual derivada del uso del servicio de la Plataforma, incluyendo:
El pago de los servicios recibidos a través del acceso a la Plataforma.
Gestionar y controlar los Programas de Empresas y de Partners.
La aceptación de esta Política de Protección de Datos, las Condiciones Legales y de cualesquiera otras condiciones generales o particulares aceptadas.
Gestionar su registro como Suscriptor en la Plataforma online ZICOFY, propiedad de ZICOFY, a través de cualquiera de los medios habilitados para ello, la web o la aplicación móvil.
La puesta a disposición de los medios técnicos de ZICOFY para permitir su utilización por los Suscriptores conforme a las Condiciones Legales.
Proponer a los Zicos para aquellas cuestiones que le preocupan.
Verificar, cuando sea necesario, la calidad de los servicios prestados al Suscriptor a través de ZICOFY en los términos expuestos en las Condiciones Legales.
Atender las solicitudes, consultas o sugerencias que, en su caso, el Suscriptor realice a ZICOFY a través de ZICOFY.
Controlar la seguridad informática de la Plataforma.
Gestión y control de promociones sobre la Plataforma.
El envío por e-mail de información vinculada de forma inherente a la utilización de ZICOFY, así como a los cambios y actualizaciones que ZICOFY pueda realizar en ellas.
La base legal para llevar a cabo dicho tratamiento es que éste es necesario para que ZICOFY pueda prestar sus servicios y poner a disposición del Suscriptor sus servicios de intermediación, así como gestionar la seguridad de la Plataforma.
El cumplimiento por ZICOFY de la normativa aplicable
Dar cumplimiento a cualquier norma que sea de aplicación a ZICOFY.
Dar respuesta a requerimientos de autoridades competentes.
La base legal para llevar a cabo dicho tratamiento es que éste es necesario para que ZICOFY pueda dar cumplimiento a cualquier obligación legal que le sea de aplicación.
Marketing (comunicaciones comerciales sobre la Plataforma y newsletters).
Envío de newsletters por medios electrónicos. El envío de newsletters se llevará a cabo:
o cuando el Suscriptor lo solicite expresamente (i.e., facilitando sus datos de contacto a través del sitio web para darse de alta en dichos envíos o solicitándoselo expresamente al chatbot)
o si de conformidad con la normativa ZICOFY puede enviar las newsletters sobre la base de su interés legítimo empresarial (por ejemplo, a Suscriptores registrados), otorgando un derecho de oposición.
El Suscriptor tiene derecho a revocar el consentimiento en cualquier momento a través de hola@zicofy.com.
Además, ZICOFY podrá, en base al interés legítimo empresarial:
Realizar encuestas de satisfacción, calidad del servicio y bienestar.
El envío de comunicaciones comerciales, por medios electrónicos sobre la Plataforma de ZICOFY, incluyendo: información sobre los Zicos, los beneficios de la plataforma, promociones y novedades sobre la plataforma.
El Suscriptor puede en todo caso oponerse en cualquier momento a las actividades de marketing a través de hola@zicofy.com.
Los envíos de marketing se seguirán realizando siempre que el Suscriptor siga registrado en la Plataforma y no se haya opuesto a recibir comunicaciones comerciales, aunque no tenga un plan contratado.
4. Plazo de conservación de los datos
Los datos personales de los Suscriptores serán tratados por ZICOFY durante la utilización de la Plataforma de ZICOFY por el Suscriptor y, tras ello, por un periodo de cinco años salvo que, excepcionalmente, fuera de aplicación a ZICOFY un plazo de prescripción de cualesquiera acciones legales o contractuales superior. Este plazo puede ser aplicable a todos los datos.
5. Cesiones de datos y transferencias internacionales
El usuario (Zico o Suscriptor) entiende y acepta que, si solicita/ofrece servicios en ZICOFY, los datos identificativos del usuario (Zico o Suscriptor) y la información preliminar facilitada por el mismo sobre los servicios que solicita/ofrece podrán ser comunicados a otros usuarios (Zico o Suscriptor) como contraparte necesaria de la prestación del servicio solicitado/ofertado.
Además, ZICOFY podrá realizar las siguientes cesiones y/o transferencias internacionales de datos personales:
En relación con los Suscriptores beneficiarios de Programas de Empresas (en los que las empresas paguen la totalidad de los servicios a los trabajadores de sus plantillas) o Programas de Partners, ZICOFY cederá necesariamente a las empresas y partners datos personales de los Suscriptores con el fin de que dichas entidades puedan controlar el uso por parte de los Suscriptores de la Plataforma. ZICOFY no cederá ni a las empresas ni a los partners datos sensibles de los Suscriptores. ZICOFY puede preparar reportes sobre el uso de la Plataforma para las empresas y partners que solo contendrán información agregada. En el supuesto de que la empresa o el partner esté ubicado fuera del Espacio Económico Europeo (el “EEE”) –en países que no ofrecen un nivel de protección de datos equivalente al nivel del EEE- y la cesión implique una transferencia internacional de datos, ZICOFY y la empresa o el partner revisarán y firmaran cualquier documentación que sea necesaria para implementar las garantías adecuadas necesarias para cubrir dicha transferencia. El Suscriptor queda informado de que si la empresa o el partner están ubicados fuera del EEE, ZICOFY tendrá que necesariamente ceder los datos fuera del EEE para que el Suscriptor se pueda beneficiar de los Programas de Empresas o Programas de Partners. Puede obtener información más específica sobre esta cuestión dirigiéndose al siguiente email: hola@zicofy.com.
Además, excepcionalmente, ZICOFY podrá ceder esos datos a un tercero, incluso a una compañía que esté ubicada fuera del Espacio Económico Europeo (el “EEE”), en el caso de que adquiera todo o parte del negocio de la plataforma de ZICOFY con la finalidad de que el Suscriptor pueda seguir recibiendo el servicio.
6. Procedimiento de registro
El Suscriptor que desee acceder y disfrutar de los contenidos y funcionalidades deberá registrarse previamente como Suscriptor conforme a lo establecido en las Condiciones Legales. Una vez registrado, podrá acceder a las secciones de la Plataforma reservadas a Suscriptores registrados mediante su nombre de usuario y contraseña, sin necesidad de volver a registrarse nuevamente.
La primera vez que el Suscriptor acceda a la Plataforma deberá indicar aquellas cuestiones sobre por las que está solicitando tener Encuentros a los efectos de que se le asigne un Zico. Asimismo, una vez asignado un Zico, el Suscriptor facilitará a éste los datos personales que en cada momento considere, de manera libre y responsable, oportunos a los efectos del correcto desarrollo de los Encuentros. De acuerdo con lo anterior, los Zicos con los que el Suscriptor contacte serán los exclusivos responsables del tratamiento de los datos que los Suscriptores les quieran facilitar a estos efectos por medio de los Encuentros entre el Zico y el Suscriptor. Respecto de los datos personales obtenidos por el Zico o que se generen en virtud de los Encuentros entablados entre el Suscriptor y el Zico, ZICOFY se limitará a prestar un servicio de alojamiento de esos datos y, en su caso, de provisión de herramientas de búsqueda o enlace de contenidos.
Mediante el registro y la utilización del servicio proporcionado a través de la Plataforma, el Suscriptor consiente expresamente el tratamiento de sus datos personales (incluidos los datos especialmente protegidos, así como imágenes, vídeos o audios) por ZICOFY para los fines que se han descrito anteriormente, en calidad de encargado del tratamiento, y que están relacionados con la gestión y explotación de ZICOFY por ZICOFY o sus sucesores o cesionarios. ZICOFY no es responsable del tratamiento de los datos sensibles que el Suscriptor facilite a través de la Plataforma.
En el supuesto de que el Suscriptor decida cambiar de Zico, su nombre de usuario y los datos relativos al motivo de los Encuentros serán comunicados al nuevo Zico. No obstante, toda la información generada con ocasión de las comunicaciones entre el Zico y el Suscriptor sólo será comunicada si el Suscriptor así lo autoriza expresamente.
El Suscriptor es asimismo consciente de que ZICOFY no tiene obligación de conservar todos los datos intercambiados en los Encuentros o comunicaciones de manera indefinida, por lo que esos datos podrán cancelarse y no resultar accesibles cada cierto tiempo. El Suscriptor es, por tanto, responsable de conservar aquellos datos de los Encuentros o comunicaciones según entienda necesario u oportuno.
El Suscriptor registrado es responsable de la custodia de su nombre de usuario y contraseña, que son de uso personal e intransferible y notificará a ZICOFY inmediatamente si sospecha usos por terceros de su nombre de usuario y contraseña. Podrá gestionar y modificar los datos de su perfil en todo momento a través de los canales indicados en el sitio web (www.zicofy.com). ZICOFY se reserva el derecho a cancelar el registro del Suscriptor en cualquier momento y por cualquier causa sin obligación de indemnización alguna al Suscriptor, p.ej., si existen sospechas de que los datos (p.ej., de edad) facilitados por un Suscriptor durante el registro pueden no ser veraces.
7. Menores de edad
Como se indica en las Condiciones Legales, los menores de edad no podrán usar la plataforma, por lo que deberán abstenerse asimismo de facilitar cualesquiera datos.
8. Datos de terceros
Para usar la plataforma no es necesario facilitar datos personales de terceros.
Con carácter excepcional, si el usuario (Suscriptor o Zico) tuviese que proporcionar datos de terceros, será necesario que el usuario (Suscriptor o Zico) haya obtenido el consentimiento previo e informado del tercero en cuestión. En particular, para que se entienda que el consentimiento es informado, los terceros deberán haber sido informados por el usuario (Suscriptor o Zico) y haber aceptado las Condiciones Legales y esta Política de Protección de Datos. Es responsabilidad única del usuario (Suscriptor o Zico) cumplir con el deber de información indicado y haber obtenido los consentimientos previos de los terceros sin que ZICOFY o el usuario receptor (Suscriptor o Zico) de los datos deban realizar ninguna actuación adicional frente a dichos terceros.
9. Utilización de cookies
ZICOFY utiliza cookies cuando un Suscriptor navega por el sitio web de ZICOFY. Puede solicitar más información acerca del tratamiento de estas cookies dirigiéndose al siguiente email: hola@zicofy.com.
10. Ejercicio de derechos por el suscriptor
Para el ejercicio de los derechos de acceso, rectificación, supresión, oposición, portabilidad y limitación del tratamiento, así como cualesquiera otros derechos que procedan conforme a la normativa aplicable, debe dirigirse por email a hola@zicofy.com, acreditando la identidad del solicitante. Si lo que pretende el Suscriptor es suspender el pago del servicio o cancelar por completo su cuenta, podrá hacerlo a través de los canales indicados en nuestro sitio web (www.zicofy.com).
En relación con la recogida y tratamiento de sus datos personales, siempre puede ponerse en contacto con nosotros en cualquier momento para:
Acceder a sus datos personales y a cualquier otra información indicada en el Artículo 15.1 del RGPD.
Rectificar sus datos personales que sean inexactos o estén incompletos de acuerdo con el Artículo 16 del RGPD.
Suprimir sus datos personales de acuerdo con el Artículo 17 del RGPD.
Limitar el tratamiento de sus datos personales de acuerdo con el Artículo 18 del RGPD.
Solicitar la portabilidad de sus datos de acuerdo con el Artículo 20 del RGPD.
Oponerse al tratamiento de sus datos personales de acuerdo con el artículo 21 del RGPD.
Por último, se informa a todos los usuarios que tienen siempre a su disposición la `}
              </Text>
              <Text style={styles.polticaDeProteccinDeDato}>
                <Text style={styles.agenciaEspaolaDe}>
                  Agencia Española de Protección de Datos
                </Text>
              </Text>
              <Text style={styles.polticaDeProteccinDeDato}>
                {" "}
                en caso que sea necesario presentar reclamaciones en materia de
                protección de datos.
              </Text>
            </Text>
          </View>
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  contenidoFlexBox: {
    alignItems: "center",
    flex: 1,
  },
  logoFlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  explicacionSpaceBlock: {
    marginTop: 20,
    alignSelf: "stretch",
  },
  textoFlexBox: {
    textAlign: "left",
    flex: 1,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  logo: {
    alignSelf: "stretch",
    justifyContent: "space-between",
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    color: Color.colorGray_200,
  },
  iniciaSesion: {
    justifyContent: "center",
    alignSelf: "stretch",
  },
  polticaDePrivacidad: {
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
  },
  polticaDeProteccinDeDato: {
    fontFamily: FontFamily.poppinsRegular,
  },
  agenciaEspaolaDe: {
    textDecoration: "underline",
  },
  texto: {
    fontSize: FontSize.size_3xs,
    lineHeight: 20,
    color: Color.colorBlack,
  },
  explicacion: {
    flexDirection: "row",
    alignItems: "center",
  },
  interactuable: {
    flex: 1,
    marginTop: 20,
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignSelf: "stretch",
  },
  politicaPrivacidad: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    overflow: "hidden",
    paddingTop: Padding.p_27xl,
    justifyContent: "space-between",
    width: "100%",
  },
});

export default PoliticaPrivacidad;
