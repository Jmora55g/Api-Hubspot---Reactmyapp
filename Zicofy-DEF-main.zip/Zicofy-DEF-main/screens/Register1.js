import * as React from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
} from "react-native";
import { Image } from "expo-image";
import { Input } from "@rneui/themed";
import { useNavigation } from "@react-navigation/native";
import Property1Default3 from "../components/Property1Default3";
import { FontFamily, Color, FontSize, Padding } from "../GlobalStyles";

const Register1 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.register1}>
      <View style={styles.contenido}>
        <View style={[styles.logo, styles.logoFlexBox]}>
          <Pressable style={styles.volver} onPress={() => navigation.goBack()}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/volver11.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <ScrollView
          style={styles.interactuable}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.interactuableScrollViewContent}
        >
          <View style={[styles.iniciaSesion, styles.texto1FlexBox]}>
            <Text style={[styles.titulo, styles.textoFlexBox]}>
              Crear cuenta gratuita
            </Text>
          </View>
          <Pressable
            style={[styles.explicacion, styles.logoFlexBox]}
            onPress={() => navigation.navigate("Login1")}
          >
            <Text style={[styles.texto, styles.textoFlexBox]}>
              <Text
                style={styles.creaTuCuenta}
              >{`Crea tu cuenta gratuita ahora. Si ya tienes una cuenta `}</Text>
              <Text style={styles.iniciaSesinAqu}>¡Inicia sesión aquí!</Text>
            </Text>
          </Pressable>
          <Input
            style={styles.input}
            label="Correo electrónico"
            placeholder="Ingresa tu correo electrónico"
            leftIcon={{ name: "email-outline", type: "material-community" }}
            inputStyle={{ color: "#a4a4a4" }}
          />
          <Input
            style={styles.input}
            label="Contraseña"
            placeholder="***********"
            leftIcon={{ name: "lock-outline", type: "material-community" }}
            rightIcon={{ name: "eye-off-outline", type: "material-community" }}
            inputStyle={{ color: "#292929" }}
          />
          <Input
            style={styles.input}
            label="Confirma tu contraseña"
            placeholder="***********"
            leftIcon={{ name: "lock-outline", type: "material-community" }}
            rightIcon={{ name: "eye-off-outline", type: "material-community" }}
            inputStyle={{ color: "#292929" }}
          />
          <View style={styles.iniciarSesion}>
            <Property1Default3
              texto="Crear cuenta gratuita"
              property1DefaultPosition="unset"
              property1DefaultAlignSelf="stretch"
              property1DefaultBackgroundColor="#ffd7f3"
              textoFlex={1}
              onIniciarSesinPress={() => navigation.navigate("Register2")}
            />
          </View>
          <View style={[styles.texto1, styles.texto1FlexBox]}>
            <Text
              style={[styles.oRegistrarmeCon, styles.tituloTypo]}
              numberOfLines={1}
            >
              o registrarme con
            </Text>
          </View>
          <View style={[styles.google, styles.texto1FlexBox]}>
            <Image
              style={styles.icono}
              contentFit="cover"
              source={require("../assets/vector5.png")}
            />
          </View>
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  logoFlexBox: {
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  texto1FlexBox: {
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
  },
  textoFlexBox: {
    textAlign: "left",
    flex: 1,
  },
  tituloTypo: {
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    color: Color.colorGray_200,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  logo: {
    justifyContent: "space-between",
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    color: Color.colorGray_200,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  iniciaSesion: {
    alignSelf: "stretch",
  },
  creaTuCuenta: {
    fontFamily: FontFamily.poppinsRegular,
    color: Color.colorGray_200,
  },
  iniciaSesinAqu: {
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.colorLightskyblue,
  },
  texto: {
    fontSize: FontSize.size_lg,
  },
  explicacion: {
    marginTop: 20,
  },
  input: {
    marginTop: 20,
    alignSelf: "stretch",
  },
  iniciarSesion: {
    marginTop: 20,
    alignSelf: "stretch",
    alignItems: "center",
  },
  oRegistrarmeCon: {
    fontSize: FontSize.size_base,
    textAlign: "center",
    transform: [
      {
        rotate: "-0.33deg",
      },
    ],
    color: Color.colorGray_200,
    flex: 1,
  },
  texto1: {
    marginTop: 20,
    alignSelf: "stretch",
  },
  icono: {
    width: 30,
    height: 30,
  },
  google: {
    marginTop: 20,
  },
  interactuable: {
    marginTop: 20,
    alignSelf: "stretch",
    flex: 1,
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignSelf: "stretch",
    alignItems: "center",
    flex: 1,
  },
  register1: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    paddingTop: Padding.p_27xl,
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    flex: 1,
  },
});

export default Register1;
