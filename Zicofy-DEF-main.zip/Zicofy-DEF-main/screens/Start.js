import * as React from "react";
import {
  View,
  ImageBackground,
  StyleSheet,
  Pressable,
  Text,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import Property1Default3 from "../components/Property1Default3";
import { FontSize, FontFamily, Color, Padding } from "../GlobalStyles";

const Start = () => {
  const navigation = useNavigation();

  return (
    <LinearGradient
      style={styles.start}
      locations={[0, 0.94, 1]}
      colors={["#74c2ef", "#f2d5f3", "#ffd7f3"]}
    >
      <View style={[styles.contenido, styles.contenidoFlexBox]}>
        <View style={styles.logoZicofy}>
          <ImageBackground
            style={styles.imagenIcon}
            resizeMode="center"
            source={require("../assets/isologotipozicofy.png")}
          />
        </View>
        <View style={styles.botonesFlexBox}>
          <View style={styles.contenidoFlexBox}>
            <Property1Default3
              texto="Iniciar sesión"
              property1DefaultPosition="unset"
              property1DefaultAlignSelf="stretch"
              property1DefaultBackgroundColor="#ffd7f3"
              textoFlex={1}
              onIniciarSesinPress={() => navigation.navigate("Login1")}
            />
          </View>
          <View style={styles.botonesFlexBox}>
            <Property1Default3
              texto="Registrarse"
              property1DefaultPosition="unset"
              property1DefaultAlignSelf="stretch"
              property1DefaultBackgroundColor="#fff4fc"
              textoFlex={1}
              onIniciarSesinPress={() => navigation.navigate("Register1")}
            />
          </View>
          <View style={[styles.onboarding, styles.botonesFlexBox]}>
            <Pressable
              numberOfLines={1}
              onPress={() => navigation.navigate("Onboarding1")}
            >
              <Text style={styles.quEsZicofy}>¿Qué es Zicofy?</Text>
            </Pressable>
          </View>
        </View>
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  contenidoFlexBox: {
    alignSelf: "stretch",
    alignItems: "center",
  },
  botonesFlexBox: {
    marginTop: 20,
    alignSelf: "stretch",
    alignItems: "center",
  },
  imagenIcon: {
    width: 380,
    height: 98,
  },
  logoZicofy: {
    alignItems: "center",
  },
  quEsZicofy: {
    fontSize: FontSize.size_sm,
    fontWeight: "300",
    fontFamily: FontFamily.poppinsLight,
    color: Color.colorGray_200,
    textAlign: "center",
    flex: 1,
  },
  onboarding: {
    flexDirection: "row",
    justifyContent: "center",
  },
  contenido: {
    justifyContent: "center",
  },
  start: {
    width: "100%",
    height: 873,
    overflow: "hidden",
    paddingHorizontal: Padding.p_xl,
    paddingVertical: Padding.p_27xl,
    backgroundColor: "transparent",
    justifyContent: "center",
    alignItems: "center",
    flex: 1,
  },
});

export default Start;
