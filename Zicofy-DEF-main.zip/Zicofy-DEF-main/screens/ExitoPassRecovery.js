import * as React from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Padding } from "../GlobalStyles";

const ExitoPassRecovery = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.exitoPassRecovery, styles.contenidoFlexBox]}>
      <View style={[styles.contenido, styles.contenidoFlexBox]}>
        <View style={[styles.logo, styles.logoFlexBox]}>
          <Pressable style={styles.volver} onPress={() => navigation.goBack()}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/volver.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <ScrollView
          style={[styles.interactuable, styles.explicacionSpaceBlock]}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.interactuableScrollViewContent}
        >
          <View style={[styles.iniciaSesion, styles.logoFlexBox]}>
            <Text style={[styles.titulo, styles.textoFlexBox]}>
              Recuperar contraseña
            </Text>
          </View>
          <View style={[styles.explicacion, styles.explicacionSpaceBlock]}>
            <Text
              style={[styles.texto, styles.textoFlexBox]}
            >{`¡Perfecto! Ya enviamos tu correo de recuperación a {{correo.usuario}}.`}</Text>
          </View>
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  contenidoFlexBox: {
    alignItems: "center",
    flex: 1,
  },
  logoFlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  explicacionSpaceBlock: {
    marginTop: 20,
    alignSelf: "stretch",
  },
  textoFlexBox: {
    textAlign: "left",
    color: Color.colorGray_200,
    flex: 1,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  logo: {
    alignSelf: "stretch",
    justifyContent: "space-between",
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
  },
  iniciaSesion: {
    justifyContent: "center",
    alignSelf: "stretch",
  },
  texto: {
    fontSize: FontSize.size_lg,
    fontFamily: FontFamily.poppinsRegular,
  },
  explicacion: {
    flexDirection: "row",
    alignItems: "center",
  },
  interactuable: {
    flex: 1,
    marginTop: 20,
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignSelf: "stretch",
  },
  exitoPassRecovery: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    paddingTop: Padding.p_27xl,
    justifyContent: "space-between",
    width: "100%",
  },
});

export default ExitoPassRecovery;
