import * as React from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
  Linking,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Padding } from "../GlobalStyles";

const TerminosCondiciones = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.terminosCondiciones, styles.contenidoFlexBox]}>
      <View style={[styles.contenido, styles.contenidoFlexBox]}>
        <View style={[styles.logo, styles.logoFlexBox]}>
          <Pressable style={styles.volver} onPress={() => navigation.goBack()}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/volver11.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <ScrollView
          style={[styles.interactuable, styles.explicacionSpaceBlock]}
          horizontal={false}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.interactuableScrollViewContent}
        >
          <View style={[styles.iniciaSesion, styles.logoFlexBox]}>
            <Text style={[styles.titulo, styles.textoFlexBox]}>
              Términos y condiciones
            </Text>
          </View>
          <View style={[styles.explicacion, styles.explicacionSpaceBlock]}>
            <Text style={[styles.texto, styles.textoFlexBox]}>
              <Text style={styles.trminosYCondiciones}>{`Términos y condiciones
`}</Text>
              <Text style={styles.leaEstosTrminosYCondicion}>
                {`LEA ESTOS TÉRMINOS Y CONDICIONES LEGALES DETENIDAMENTE ANTES DE ACCEDER A LA PLATAFORMA Y A USAR Y/O ACEPTAR LOS SERVICIOS. CUALQUIER PERSONA HUMANA QUE NO ACEPTE ESTOS TÉRMINOS Y CONDICIONES LEGALES, LOS CUALES TIENEN UN CARÁCTER OBLIGATORIO Y VINCULANTE, DEBERÁ ABSTENERSE DE SUSCRIBIRSE A LOS PLANES O SERVICIOS QUE OTORGA ZICOFY TRAVÉS DE LA PLATAFORMA.
EL SUSCRIPTOR RECONOCE Y ACEPTA QUE MEDIANTE EL INGRESO Y USO DE LA PLATAFORMA: (I) ZICOFY NO PRESTA SERVICIOS DE BIENESTAR EMOCIONAL, ATENCIÓN MÉDICA, DE SALUD MENTAL, PSICODIAGNÓSTICOS, DE TERAPIA U OTROS RELACIONADOS (II) LOS ZICOS (CONFORME SE DEFINEN MÁS ABAJO) SON RECIÉN GRADUADOS EN PSICOLOGÍA REALIZANDO UN MÁSTER O EL PROGRAMA PIR (PSICÓLOGO RESIDENTE INTERNO), NO PROFESIONALES DE LA SALUD MENTAL, POR LO QUE BAJO NINGUNA CIRCUNSTANCIA CONSIDERARÁ SU ACCIONAR COMO INTRUSISMO PROFESIONAL, (III) BAJO NINGUNA CIRCUNSTANCIA CONSIDERARÁ QUE LOS SERVICIOS QUE REALICEN LOS ZICOS SON ENCOMENDADOS POR ZICOFY; Y (IV) ACEPTA LA ÚLTIMA VERSIÓN DE LOS TÉRMINOS Y CONDICIONES AQUÍ ESCRITOS.
NO UTILICE EL SITIO WEB PARA NECESIDADES MÉDICAS. SI SU SALUD O INTEGRIDAD ESTÁN EN GRAVE PELIGRO, LLAME AL NÚMERO DE EMERGENCIAS DEL LUGAR DE SU RESIDENCIA INMEDIATAMENTE (PUEDE CONSULTAR ESTOS NÚMEROS A TRAVÉS DEL `}
              </Text>
              <Text style={styles.leaEstosTrminosYCondicion}>
                <Text style={styles.sitioWebDe}>
                  SITIO WEB DE LA GUARDIA CIVIL ESPAÑOLA
                </Text>
              </Text>
              <Text style={styles.leaEstosTrminosYCondicion}>
                {`).
SI ESTÁ PENSANDO EN EL SUICIDIO O SI ESTÁ CONSIDERANDO LLEVAR A CABO ACCIONES QUE PUEDAN PONERLO EN PELIGRO A USTED O A TERCEROS, DEBE LLAMAR AL NÚMERO DE EMERGENCIAS DEL LUGAR DE SU RESIDENCIA INMEDIATAMENTE.
1. Introducción
Los presentes Términos y Condiciones Particulares (a partir de ahora, los “Términos y Condiciones” o “Condiciones Legales”) aplicables a los Zicos (conforme se definen más abajo) y a los Suscriptores (conforme se definen más abajo) regulan el acceso y/o uso que Ud. haga, como persona humana, de la plataforma virtual (la “Plataforma”) de ZICOFY (conforme se definen más abajo).
ZICOFY es un proyecto representado por Mateo Agustín Fuentes (matt@zicofy.com) y Agustín Hernan Rodríguez (agus@zicofy.com). Los datos de contacto de ZICOFY son los siguientes: domicilio corporativo, Calle Lanza, 11, Bajo Izquierda, 41003 Sevilla; dirección de correo electrónico, hola@zicofy.com. Para más información, puede enviar un correo electrónico a: hola@zicofy.com.
2. Definiciones
“ZICOFY” es una plataforma online, accesible a través del portal web de ZICOFY (www.zicofy.com), propiedad de ZICOFY (la “Plataforma”), que se pone a disposición de los Suscriptores provenientes de internet.
ZICOFY a través de la Plataforma facilita la intermediación entre personas humanas (en adelante, “Suscriptores”) que solicitan a través de la Plataforma servicios de encuentros en línea para compartir, por esa vía, una conversación (en adelante, los “Encuentros”) con otras personas humanas recién graduadas del Grado en Psicología que pueden estar realizando un Máster o el programa PIR (Psicólogo Interno Residente) (en adelante, “Zicos”) que aceptan, a su propia cuenta y riesgo, comercializar estos Encuentros a través de la Plataforma; todo ello mediante el acceso y uso de la Plataforma, siendo únicamente ZICOFY un tercero intermediario que permite la conexión entre los Suscriptores y los Zicos.
ZICOFY tiene como misión tratar de mejorar el bienestar emocional a través de la interconexión de personas humanas (Suscriptores) con otras personas humanas (Zicos) que tienen vocación de ayudar utilizando su mayor conocimiento sobre bienestar emocional e instrucción académica, pero de ninguna manera ZICOFY ofrece servicios de bienestar emocional, atención médica, de salud mental, psicodiagnósticos, de terapia u otros relacionados, sino que únicamente se limita a brindar un servicio de conexión entre Suscriptores y Zicos.
Los Zicos NO SON PROFESIONALES DE LA SALUD MENTAL, sino que son recién graduados del Grado en Psicología y que pueden estar cursando un Máster o realizando el programa PIR (Psicólogo Interno Residente). Los Zicos, con vocación relacionada a sus estudios, se ofrecen para brindar Encuentros en línea, pero en ningún caso debe confundirse la labor de un Zico con la labor de un psicólogo clínico, psiquiatra o cualquier otro profesional de la salud mental, sino que son meramente recién graduados con mayor conocimiento sobre bienestar emocional e instrucción académica que se ofrecen para tener charlas como cualquiera podría tener con un amigo, a través de estos Encuentros en línea.
ZICOFY en su servicio ÚNICAMENTE se dedica a: (i) facilitar el encuentro entre Suscriptores y Zicos para la realización del vínculo contractual arriba mencionado y (ii) servir de medio de envío de comunicaciones entre los Suscriptores y los Zicos.
3. Advertencias importantes en relación con el uso de los encuentros en general, de la plataforma. Uso responsable
Los Suscriptores deben diferenciar los servicios que prestan los Zicos a los Suscriptores, a través de los Encuentros, de los servicios de ZICOFY:
1. La prestación de servicios se realiza por los Zicos a los Suscriptores, siendo ZICOFY únicamente el encargado de conectar a ambos a través de la Plataforma; conexión por la cual cobra una suscripción mensual.2. Los Encuentros son ofrecidos y prestados exclusivamente por los Zicos, por su cuenta y en su propio nombre, y no por ZICOFY. ZICOFY no presta servicios de Encuentros, sino que es una herramienta que facilita los encuentros en línea entre Zicos y Suscriptores.3. ZICOFY exclusivamente pone en contacto a Zicos y Suscriptores facilitándoles, además, los medios técnicos para hacer posibles estos Encuentros.4. Por lo tanto, sólo los Zicos son responsables de cualquier reclamación de los Suscriptores o de terceros en relación con los Encuentros o la actuación de los Zicos en general. ZICOFY es, pues, totalmente ajena a la prestación de los Encuentros por los Zicos o a su actuación. Los Zicos prestan sus servicios con total autonomía e independencia.
La plataforma no podrá usarse para ninguna actividad médica ni tampoco para aquellas labores de diagnóstico, tratamiento o seguimiento de patologías, trastornos o problemas psicológicos que requieran cualificaciones que no concurren en los Zicos y requieran una terapia brindada por un profesional matriculado de la salud mental.
El contacto online que se ofrece por medio de los Encuentros no es, en ningún caso, equivalente o sustitutivo de una terapia brindada por un profesional matriculado de la salud mental. Cuando ésta sea necesaria, el Suscriptor y el Zico deben abstenerse de usar la Plataforma.
Por tanto, LOS ENCUENTROS NO ESTÁN DESTINADOS PARA EL DIAGNÓSTICO MÉDICO, LA PRESCRIPCIÓN DE MEDICAMENTOS, NI PARA LA PRESTACIÓN DE SERVICIOS DE PSICOLOGÍA. EN CASO DE QUE USTED ESTÉ BUSCANDO O NECESITE ESE TIPO DE SERVICIOS MÉDICOS O DE ATENCIÓN PSICOLÓGICA (POR EJEMPLO, SI CONSIDERA QUE SU SALUD MENTAL O FÍSICA CORRE PELIGRO, SI ESTÁ PENSANDO EN EL SUICIDIO O SI PUEDE ACTUAR EN MODO QUE PONGA EN RIESGO SU SALUD O LA DE TERCEROS O ENTIENDE QUE CUALQUIER OTRA PERSONA PUEDE ESTAR EN PELIGRO; O SI TIENE ALGUNA EMERGENCIA MÉDICA, PSICOLÓGICA O PSIQUIÁTRICA) DEBE ABSTENERSE DE UTILIZAR LA PLATAFORMA Y CONTACTAR INMEDIATAMENTE CON UN CENTRO MÉDICO O UN SERVICIO DE URGENCIAS.
Los Suscriptores deben ser mayores de edad y tener capacidad legal de obrar plena para usar la Plataforma. La utilización de la Plataforma por menores de edad está expresamente prohibida.
Los Suscriptores se comprometen expresamente a hacer un uso adecuado de los Encuentros y de la Plataforma. En particular, se comprometen a:
1. Utilizarla en su propio nombre y por cuenta propia, bajo su entera y sola responsabilidad y para fines personales.2. No usarlos con finalidad lucrativa, promocional o comercial, ya sea promocionando su establecimiento o prestaciones o perjudicando los de terceros, sin perjuicio de la actuación de los Zicos dentro de la legalidad vigente.3. No archivar, descargar, reproducir, distribuir, modificar, exhibir, ejecutar, publicar, licenciar, crear trabajos derivados, poner a la venta, o (salvo lo autorizado de modo expreso en estas Condiciones Legales) usar contenidos o información contenida en el servicio de la Plataforma u obtenidos a través de ella o en ella.4. No difundir contenidos, delictivos, violentos, pornográficos, racistas, xenófobo, ofensivos, de apología del terrorismo o, en general, contrarios a la ley o al orden público.5. No introducir en la red virus informáticos o realizar actuaciones susceptibles de alterar, estropear, interrumpir o generar errores o daños en los documentos electrónicos, datos o sistemas físicos y lógicos de ZICOFY o de terceras personas; así como no obstaculizar el acceso de otros Suscriptores al sitio web y a sus servicios mediante el consumo masivo de los recursos informáticos a través de los cuales ZICOFY presta sus servicios. Además, Usted acepta no subir, publicar, enviar por correo electrónico o transmitir por ningún otro medio ningún material diseñado para interrumpir, destruir o limitar la funcionalidad de ningún software, hardware o equipo de Encuentros asociado al servicio proporcionado a través de la Plataforma, como por ejemplo virus informáticos u otros códigos de ordenador, archivos o programas. Podemos resolver o restringir su uso del servicio si infringe estas Condiciones Legales o si incurre en uso ilegal o fraudulento del servicio.6. No intentar acceder a las cuentas de otros Suscriptores a áreas restringidas de los sistemas informáticos de ZICOFY o de terceros ni, en su caso, extraer información.7. No vulnerar los derechos de intimidad, imagen, honor, privacidad, protección de datos, propiedad intelectual o industrial, así como no violar la confidencialidad de la información de ZICOFY o de los Suscriptores. En particular, el contenido de los Encuentros deberá ser confidencial para los Zicos que mantendrán la máxima confidencialidad respecto de éstos, adoptando las debidas medidas de seguridad.8. No suplantar la identidad de otros Suscriptores, de las administraciones públicas o de un tercero.9. No reproducir, copiar, distribuir, poner a disposición o de cualquier otra forma comunicar públicamente, transformar o modificar los contenidos disponibles en la Plataforma o en cualquiera de los portales y aplicaciones móvil, a menos que se cuente con la autorización del titular de los correspondientes derechos o ello resulte legalmente permitido.10. No recabar datos con finalidad publicitaria y no remitir publicidad y comunicaciones con fines de venta u otras de naturaleza comercial sin que medie su previa solicitud o consentimiento. Todos los contenidos la Plataforma como textos, fotografías, gráficos, imágenes, iconos, tecnología, software, así como su diseño gráfico y códigos fuente, constituyen una obra cuya propiedad pertenece a ZICOFY, sin que puedan entenderse cedidos al Suscriptor ninguno de los derechos de explotación sobre los mismos más allá de lo estrictamente necesario para el correcto uso de la Plataforma.
Asimismo, todas las marcas, nombres comerciales o signos distintivos de cualquier clase que aparecen en la Plataforma o en cualquiera de los portales que son propiedad de ZICOFY (o bien de terceros con los que ésta tiene acuerdos), sin que pueda entenderse que el uso o acceso al mismo atribuya al Suscriptor derecho alguno sobre ellos. La distribución, modificación, cesión o comunicación pública de los contenidos y cualquier otro acto que no haya sido expresamente autorizado por el titular de los derechos de explotación quedan prohibidos.
4. Aceptación de las condiciones legales
La mera utilización de la Plataforma conlleva automáticamente la aceptación plena y sin reservas por los Suscriptores y los Zicos de todas y cada una de las presentes Condiciones Legales en la versión publicada por ZICOFY en cada momento. En consecuencia, el Suscriptor y el Zico deben leer periódicamente las Condiciones Legales para conocer sus variaciones, que no necesariamente deberán ser advertidas.
Además de las Condiciones Legales, resultarán de aplicación a los Suscriptores y a los Zicos aquellas otras condiciones generales y/o particulares que suscriban en relación con la utilización de determinados recursos y/o contenidos puestos a su disposición en la web. De surgir un conflicto entre estas Condiciones Legales y otras condiciones especificadas para un área o servicio concreto de la Plataforma, éstas prevalecerán en lo referente al uso o acceso a esa área o servicio de la Plataforma. Asimismo, en caso de contradicción entre cualesquiera condiciones particulares y generales, prevalecerán las particulares.
Al conjunto de términos y condiciones que resulte de las Condiciones Legales y las diversas condiciones generales y particulares aplicables a cada Suscriptor y Zico en relación con el servicio se denominará la “Relación Contractual”.
5. Registro
El registro en la Plataforma a través del sitio web www.zicofy.com es necesario para poder recibir el servicio de Encuentros así como, en su caso, para la navegación y disfrute de ciertas funcionalidades en las distintas secciones del sitio web. En concreto, los Suscriptores podrán registrarse por medio de email y contraseña.
La recogida, tratamiento y finalidad del uso de datos personales se regirá por lo establecido al respecto en las presentes Condiciones Legales así como en la Política de Protección de Datos de la Plataforma. Se entenderá y presumirá que los datos personales incluidos por los Suscriptores para poder usar los servicios de Encuentros han sido introducidos directamente por el Suscriptor, y que, por lo tanto, será el único responsable de su veracidad o inexactitud.
Asimismo, ZICOFY podrá habilitar, en su caso, otros medios de registro, en cuyo caso, los Suscriptores deberán tener en cuenta si el registro se efectúa directamente en la Plataforma por los medios que ZICOFY determine en cada momento (por ejemplo, completando el formulario habilitado en la web o respondiendo a las preguntas que a este efecto se formulen por teléfono o por correo electrónico) o bien por medio de plataformas de terceros, en cuyo caso, Usted tendrá que tener en cuenta las condiciones legales y de privacidad aplicables en tales plataformas, de cuyo funcionamiento ZICOFY no es responsable.
Para utilizar la Plataforma alojada en el sitio web www.zicofy.com, se deberá tener acceso a Internet y un dispositivo compatible.
6. Posición de neutralidad de Zicofy y exclusión de responsabilidad en relación con los encuentros
En relación con los Encuentros, ZICOFY se limitará a ser un proveedor de servicios de intermediación para el alojamiento y el enlace a contenidos (principalmente, los Encuentros).
ZICOFY no tiene obligación de ejercer ningún control o supervisión del contenido de los Encuentros. En este sentido, ZICOFY no tiene obligación de revisar contenidos cargados o publicados en la Plataforma por Zicos o Suscriptores y, entre éstos, los Encuentros. Por todo ello, ZICOFY no asume responsabilidad alguna respecto de ellos. Lo previsto en este párrafo se entenderá sin perjuicio de los procedimientos de detección y retirada de contenidos previstos más abajo.
Usted exonera a ZICOFY de cualquier responsabilidad en relación a su participación en los Encuentros o la utilización de los contenidos creados por otros Suscriptores o Zicos, incluido por cualquier acto u omisión de los Zicos o Suscriptores. No hacemos ninguna manifestación ni prestamos garantía alguna acerca de ningún contenido o los Encuentros.
Una vez cumplido el rol de ZICOFY de meramente hacer intermediación para la conexión entre el Suscriptor y el Zico, la relación del Suscriptor con el Zico es directa y exclusiva entre ellos sin participación alguna de ZICOFY, que no tiene obligación de validar ni controlar los Encuentros ni demás servicios prestados por los Zicos a los Suscriptores. Por ello, Usted debe mantener el correspondiente nivel de cuidado, atención y diligencia. Adicionalmente, dado que la finalidad de la Plataforma no es que se ofrezcan o presten en ella servicios o asesoramiento médico, Usted como Suscriptor debe acudir a profesionales médicos o profesionales de la salud mental, y no a la Plataforma, en caso de que tenga necesidad de ellos o para cualquier patología mental, psiquiátrica o física. El consejo del Zico no es ni puede ser equivalente o sustitutivo del consejo médico. Por último, Usted como Suscriptor debe ser consciente de que los servicios ofrecidos por los Zicos a través de los Encuentros no son ni sustitutivos ni equivalentes a una sesión con un profesional de la salud mental matriculado, tal como puede ser un psicólogo o un psiquiatra. Usted debe valorar las ventajas e inconvenientes de la utilización de esta Plataforma online por medio de los Encuentros para obtener los servicios de los Zicos y decidir si se ajustan a sus necesidades o no.
ZICOFY no tiene obligación de verificar las credenciales, titulación o calidad de los Zicos o de los servicios que los Zicos presten a los Suscriptores, si bien los Zicos deben proporcionar a ZICOFY ciertos datos necesarios para su registro. Los Zicos no son empleados, colaboradores o representantes de ZICOFY, sino que son prestatarios de servicios independientes que, únicamente, usan la Plataforma para a través de ella lograr la conexión necesaria para luego prestar sus servicios a los Suscriptores de manera independiente y obtener una contraprestación por ello.
Los Suscriptores y Zicos aceptan que cualquier acción legal o responsabilidad civil que pretenda obtener por hechos u omisiones de Zicos, o Suscriptores o terceros deberán dirigirse exclusivamente contra ellos y no contra ZICOFY. Tanto el Zico como el Suscriptor compensarán y mantendrán indemne a ZICOFY de cualquier daño o perjuicio resultante de una reclamación, judicial o extrajudicial, de un Suscriptor o Zico o terceros por cualquier motivo relacionado con su conducta en la Plataforma. Serán beneficiarios de la anterior obligación de indemnizar, además de a ZICOFY, sus entidades vinculadas, filiales y sus administradores, empleados, colaboradores y agentes. La obligación de indemnizar incluirá los gastos de representación y asistencia jurídica y otros gastos legales o procesales.
Sin perjuicio de lo anterior, los Suscriptores podrán y deberán denunciar cualquier irregularidad o infracción que detecten en relación con otros Suscriptores o Zicos o terceros. En tal caso, ZICOFY podrá:
Retirar, cancelar y/o denunciar ante las autoridades competentes cualesquiera actos, omisiones o contenidos de los Suscriptores o Zicos o terceros en el caso de que resulten contrarios a la Relación Contractual, al Ordenamiento o a los derechos de terceros, incluidos los derechos de propiedad intelectual, industrial, de imagen, a la intimidad y al honor. Lo anterior incluirá la facultad de revelar a las autoridades competentes y a los terceros que acrediten un interés legítimo legalmente protegido los datos de identificación (y aquellos otros legalmente oportunos) de los Suscriptores previsiblemente responsables de infracciones denunciadas, de conformidad con la normativa de protección de datos de carácter personal.
Cancelar la cuenta de cualquier Suscriptor o Zico que haya cometido esos actos u omisiones o que sea responsables de esos contenidos.
ZICOFY se reserva la facultad de mantener o rehabilitar el contenido o una cuenta si se demuestra que su solicitud ha resultado falsa o abusiva; y la facultad de cancelar la cuenta del Suscriptor o Zico o tercero que denunció abusivamente o la adopción de cualquier otra medida oportuna.
ZICOFY podrá adoptar, a su sola decisión y criterio, las medidas que estime oportunas para el mejor funcionamiento de la Plataforma y la mayor satisfacción de los Suscriptores, incluyendo el establecimiento de restricciones, barreras o medidas automáticas para prevenir la realización de conductas contrarias a las Condiciones Legales, sin que ello implique asunción de responsabilidad por alguna por ellas.
Las denuncias deberán enviarse, bajo responsabilidad y compromiso de que la información proporcionada es exacta y veraz, indicando los siguientes extremos: (i) datos personales que permitan la identificación y el contacto del reclamante; y (ii) especificación de la supuesta actividad ilícita llevada a cabo en la Plataforma y justificación de la misma, incluyendo, en su caso, indicación los de derechos infringidos y de los hechos infractores, así como de su localización en la Plataforma. Estas notificaciones deberán ser enviadas a hola@zicofy.com.
ZICOFY puede poner a disposición de los Suscriptores, si así lo decide, otros mecanismos para llevar a cabo estas notificaciones.
7. Exclusión de obligaciones y garantías por la puesta a disposición de la plataforma
En relación con el servicio que presta ZICOFY (esto es, puesta a disposición de la Plataforma para facilitar el contacto entre Suscriptores y Zicos) y que son distintos de los servicios de los Zicos a los Suscriptores, ZICOFY asume sólo las obligaciones contractuales previstas en las presentes Condiciones Legales y no presta garantía alguna a los Suscriptores.
En particular, ZICOFY declina toda responsabilidad por, entre otros:
Los actos u omisiones de los Zicos, que son los únicos responsables por ellos. En este sentido, Usted debe revisar las advertencias efectuadas en el apartado 3 de estas Condiciones Legales.
El funcionamiento correcto, continuo o ininterrumpido de la web y/o de la aplicación móvil, que ZICOFY podrá cesar en cualquier momento a su discreción sin perjuicio del respeto a los compromisos contractuales específicamente asumidos a cambio de una contraprestación económica y en virtud de condiciones específicas distintas de estas Condiciones Legales. De la misma manera, ZICOFY no garantiza la compatibilidad de la web y/o la aplicación móvil con los dispositivos de acceso de los Suscriptores, ya sean estos ordenadores, navegadores, dispositivos móviles o de otro tipo.
La exactitud de los anuncios o contenidos patrocinados en la web y/o la aplicación móvil, siendo su responsable el anunciante o patrocinador.
La adecuación de la Plataforma a las necesidades o expectativas de los Suscriptores.
El nivel de satisfacción, calidad de vida, ganancia o rentabilidad o la ausencia de pérdidas o daños como consecuencia de la utilización de la Plataforma.
La veracidad, exactitud y vigencia de los datos correspondientes a los Suscriptores.
La solvencia, fiabilidad técnica, comercial, moral o financiera de los Suscriptores.
La licitud, exactitud, veracidad, y vigencia de lo afirmado por los Suscriptores en los Encuentros o en la web y/o aplicación móvil.
La conclusión, buen fin o regularidad de la relación mantenida entre Suscriptores y los Zicos a través de los Encuentros.
El almacenamiento adecuado, la preservación o no, pérdida de los contenidos o manifestaciones de los Suscriptores en los Encuentros o en la Plataforma.
La imposibilidad de acceso al sitio web, la existencia de vicios y defectos de toda clase de los contenidos transmitidos, difundidos, almacenados, puestos a disposición a los que se haya accedido a través de la web y/o aplicación móvil o de los servicios que se ofrecen.
La presencia de virus o de otros elementos en los contenidos que puedan producir alteraciones en los sistemas informáticos, documentos electrónicos o datos de los Suscriptores o Zicos.
El incumplimiento de las leyes, la buena fe, el orden público, los usos del tráfico y el presente aviso legal como consecuencia del uso incorrecto de la Plataforma. En particular, y a modo ejemplificativo, ZICOFY no se hace responsable de las actuaciones de terceros que vulneren derechos de propiedad intelectual e industrial, secretos empresariales, derechos al honor, a la intimidad personal y familiar y a la propia imagen, protección de datos de carácter personal, así como la normativa en materia de competencia desleal y publicidad ilícita.
Cualquier responsabilidad respecto a la información que se halle fuera de la Plataforma (i.e., la web o la aplicación móvil). La función de los enlaces que aparecen en la Plataforma o en el sitio web es exclusivamente la de informar al Suscriptor sobre la existencia de otras fuentes susceptibles de ampliar los contenidos que se ofrecen a través de la Plataforma. Tampoco se garantiza el funcionamiento o accesibilidad de los sitios enlazados; ZICOFY ni sugiere, invita o recomienda la visita a los mismos, por lo que tampoco será responsable del resultado obtenido.
ZICOFY no se responsabiliza del establecimiento de hipervínculos por parte de terceros. El establecimiento de un hipervínculo no implica en ningún caso la existencia de relaciones entre ZICOFY y el propietario del sitio web en la que se establezca, ni la aceptación y aprobación por parte de ZICOFY de sus contenidos o servicios. Aquellas personas que se propongan establecer un hipervínculo deberán previamente solicitar autorización por escrito a ZICOFY. En todo caso, el hipervínculo únicamente permitirá el acceso a la página de inicio del sitio web www.zicofy.com o la aplicación móvil. Usted deberá abstenerse de realizar manifestaciones o indicaciones falsas, inexactas o incorrectas sobre ZICOFY, la Plataforma o cualquier elemento derivado de esta o incluir contenidos ilícitos, contrarios a las buenas costumbres y al orden público.
ZICOFY no se responsabiliza del uso que cada Suscriptor dé a los materiales puestos a disposición en la web y en la aplicación móvil, ni de las actuaciones que realice en base a los mismos.
LOS SERVICIOS E INFORMACIONES CONTENIDAS EN LA PLATAFORMA DE LAS QUE ZICOFY SEA EL ORGANIZADOR (ESTO ES, DISTINTOS DE LOS ENCUENTROS) SE OFRECEN “TAL CUAL”, “SEGÚN SU DISPONIBILIDAD” Y SIN GARANTÍA DE NINGÚN TIPO, EXPLÍCITA O IMPLÍCITA, TALES COMO LAS GARANTÍAS DE TÍTULO, DE NO INFRACCIÓN, DE COMERCIABILIDAD Y ADECUACIÓN PARA UN FIN CONCRETO, Y CUALQUIER GARANTÍA IMPLÍCITA POR CUALQUIER USO DE RENDIMIENTO O USO COMERCIAL, LOS CUALES SE HALLAN EXPLÍCITAMENTE EXCLUIDOS. ZICOFY, Y NUESTROS DIRECTORES, EMPLEADOS, AGENTES, SUMINISTRADORES Y SOCIOS NO GARANTIZAN QUE: (I) LOS SERVICIOS SEAN SEGUROS O ESTÉN DISPONIBLES EN UN MOMENTO O EN UNA PÁGINA WEB DETERMINADOS; (II) LOS DEFECTOS O ERRORES SEAN SUBSANADOS; (III) EL CONTENIDO O SOFTWARE DISPONIBLE EN, O A TRAVÉS DE, LOS SERVICIOS NO CONTENGA VIRUS U OTROS COMPONENTES DAÑINOS; (IV) EL RESULTADO DEL USO DE LOS SERVICIOS SATISFAGA SUS EXIGENCIAS. DEBE SABER QUE HACE USO DE LOS SERVICIOS POR SU CUENTA Y RIESGO.
8. Pagos y suscripciones
El pago por los servicios prestados por ZICOFY se hará a través un sistema o pasarela de pago. El pago de la cuota correspondiente dentro del plazo pactado a través de la pasarela de pago es liberatorio para el Suscriptor. Ello implica que una vez que él haya realizado el pago correspondiente por los Encuentros, el Zico no podrá exigir cantidad alguna por dichos servicios al Suscriptor. Del mismo modo, en los casos en los que los Suscriptores sean beneficiarios de Programas de Empresas (en los que las empresas pagan la totalidad de los servicios) o Programas de Partners de ZICOFY, el pago por parte de la empresa cliente o el partner de ZICOFY, es liberatorio para dichas empresas o partners.
El precio de los servicios de ZICOFY será cargado a los Suscriptores, o en los casos de Suscriptores beneficiarios de Programas de Empresas o de Programas de Partners a las Empresas y/o Partners, en la periodicidad que corresponda según el plan escogido y de forma continuada desde la suscripción, salvo cancelación realizada conforme a estas Condiciones Legales con anterioridad a la fecha de renovación del plan. El día del cargo puede cambiar (por ejemplo, si el método de pago no se ha configurado correctamente o si la suscripción se inició en un día no contenido en el periodo de facturación correspondiente).
El sistema o pasarela de pago será indicado en la Plataforma en cada momento y estará operado por un tercero que será, frente al Suscriptor, el único responsable de su funcionamiento y del tratamiento de sus datos de pago (con independencia de que el sistema o pasarela sea accesible o no desde la Plataforma). Lea las condiciones de ese tercero antes de aceptar el uso de su sistema de pago. En todo caso, su utilización requerirá de un método de pago aceptado, válido, legítimo y vigente. Puede encontrar y modificar los detalles específicos de su suscripción y medio de pago en la Plataforma a través de los canales indicados en nuestro sitio web (www.zicofy.com). Debe tener presente que el emisor de determinados métodos de pago puede cobrar un cargo por operación en moneda extranjera o por otros cargos. Por favor, consulte con su proveedor de medios de pago para obtener detalles.
El impago de cualquier pago debido, cualquiera que sea la causa, (incluyendo, insolvencia, caducidad, insuficiencia de fondos o por alguna otra razón) determinará que ZICOFY pueda suspender su acceso a la plataforma y/o a los Encuentros hasta que obtenga un método de pago válido.
El Suscriptor puede suspender su suscripción en cualquier momento, y seguirá teniendo acceso a la Plataforma y/o a los Encuentros hasta el final del periodo de facturación. Si el Suscriptor desea revocar su consentimiento otorgado al Zico con el fin de finalizar los Encuentros con él, deberá notificarlo al Zico y/o escribir a la dirección de correo electrónico hola@zicofy.com para solicitar el cambio de Zico. Si lo que pretende el Suscriptor es suspender el pago del servicio, podrá hacerlo desde la Plataforma a través de los canales indicados en nuestro sitio web (www.zicofy.com).
Si el Suscriptor se inscribió usando su cuenta con un tercero (en todo o incluso sólo a efectos de pago) y desea cancelar su suscripción en la Plataforma, es posible que tenga que hacerlo a través de dicho tercero. Por ejemplo, puede que tenga que visitar su cuenta con el correspondiente tercero y desactivar la renovación automática del servicio, o darse de baja de éste, a través de dicho tercero. En tal caso, consulte con el tercero antes de llevar a cabo su suscripción desde esa cuenta.
ZICOFY se reserva el derecho de tomar las medidas judiciales y extrajudiciales que estime pertinentes para obtener el pago de los montos debidos por el Suscriptor a través de la Plataforma.
9. Condiciones particulares de promociones y descuentos
ZICOFY se reserva el derecho de ofertar libremente cualesquiera promociones o descuentos en los términos y condiciones que estime oportuno en cada momento y se reserva el derecho de modificar, total o parcialmente, las presentes Condiciones en cualquier momento.
1. Periodo gratuito de prueba
Todos los planes incluyen un periodo gratuito de prueba sin requisito de permanencia. Durante dicho periodo de prueba, el Suscriptor podrá libremente y sin coste alguno cancelar la suscripción; no obstante, si el Suscriptor no expresa su oposición a continuar con el servicio o mantiene más Encuentros con el Zico, se entenderá que el Suscriptor desea continuar con el plan inicialmente seleccionado y, en su caso, accede a la renovación automática.
2. Descuento “Programa para Estudiantes”
Todos los Suscriptores que se encuentren en condición de estudiantes de una carrera de grado o máster podrán solicitar un 20% de descuento en cualquier plan que elijan. Este descuento tendrá validez hasta la fecha de graduación del Suscriptor. La manera de acceder al descuento es completando el formulario que se encuentra el sitio web (www.zicofy.com) y una vez validada la información requerida para comprobar que el Suscriptor es un estudiante, el Suscriptor recibirá por correo electrónico la correspondiente confirmación y un código de descuento que podrá utilizar al proceder con la compra de una suscripción a través del sistema o pasarela de pagos.
3. Otras Promociones
Los Suscriptores, exceptuando aquellos que pertenezcan a Programas de Empresas o Programas de Partners, podrán beneficiarse de promociones adicionales dependiendo de su suscripción (p. ej. códigos de descuento) acordadas entre ZICOFY y otras entidades.
10. Contraseña y acceso a la cuenta
El Suscriptor que haya creado una cuenta en la Plataforma a través de la web de ZICOFY (www.zicofy.com) o de la aplicación móvil, deberá mantener el control sobre ella evitando accesos por terceros. Para ello, el Suscriptor no deberá revelar a nadie ni la contraseña ni los detalles de la cuenta ni del medio de pago asociado (por ejemplo, los últimos cuatro dígitos de su tarjeta de crédito o débito, o su dirección de correo electrónico).
El Suscriptor deberá tener cuidado con cualquier comunicación en la que se le pida que envíe información de su tarjeta de crédito, medio de pago o, en general, de su cuenta, pues puede traer como consecuencia una usurpación de identidad y otros perjuicios patrimoniales. Deberán acceder siempre a su información directamente desde cualquiera de los portales web vinculados o desde la aplicación móvil oficial y no a través de un hiperenlace en un correo electrónico o de ninguna otra comunicación electrónica, aunque parezca oficial. Podemos cancelar su cuenta o bloquearla por motivos de seguridad.
11. Derechos de propiedad intelectual e industrial de Zicofy y sobre los contenidos facilitados por el suscriptor
ZICOFY es dueño del dominio www.zicofy.com y autor de la propiedad intelectual e industrial de la Plataforma “ZICOFY” y cualquiera de los portales web o aplicaciones móvil vinculados a ella.
En ningún caso se entenderá que el acceso, navegación y utilización de la Plataforma, portales web o la aplicación móvil implica una renuncia, transmisión, licencia o cesión total o parcial de dichos derechos por parte de ZICOFY. Los Suscriptores disponen de un derecho de uso de los contenidos y/o servicios de la Plataforma dentro de un ámbito estrictamente en los términos establecidos en estas Condiciones Legales.
Las referencias a marcas o nombres comerciales de ZICOFY llevan implícitas la prohibición sobre su uso sin el consentimiento de los legítimos titulares de ZICOFY.
Quedan reservados todos los derechos de propiedad intelectual e industrial sobre los contenidos y/o servicios de la Plataforma del sitio web vinculado (ZICOFY) y la aplicación móvil y, en particular, queda prohibido modificar, copiar, reproducir, comunicar públicamente, transformar o distribuir, por cualquier medio y bajo cualquier forma, la totalidad o parte de sus contenidos si no se cuenta con la autorización previa, expresa y por escrito de ZICOFY.
El Suscriptor reconoce y acepta que toda la propiedad intelectual e industrial sobre los contenidos y/o cualesquiera otros elementos insertados en la Plataforma (incluyendo, sin limitación, marcas, logotipos, nombres comerciales, textos, imágenes, gráficos, diseños, sonidos, bases de datos, software, diagramas de flujo, presentación, audio y vídeo), pertenecen a ZICOFY, no implicando el acceso a la Plataforma y/o aceptación de los presentes, cesión de derecho alguna a favor del Suscriptor.
En caso que existan contenidos que el Suscriptor cargue o publique en la Plataforma distintos de los intercambiados por medio de los Encuentros serán denominados los “Contenidos de Suscriptor”. Con carácter general, ZICOFY no “usa” los Contenidos de Suscriptor. ZICOFY se limita a disponer los medios técnicos para que los Suscriptores puedan crear, alojar, poner a disposición, usar y acceder a esos contenidos. No obstante, en ciertas circunstancias y jurisdicciones, puede ser necesario o conveniente que ZICOFY disponga de una licencia para prestar los Servicios (en adelante, el “Uso para la Prestación del Servicio”). Por ello, el Suscriptor autoriza a que ZICOFY utilice, para todo el mundo y durante todo su plazo de duración, todos los derechos de propiedad intelectual (incluyendo los de reproducción, distribución, comunicación pública o transformación), propiedad industrial, imagen o cualesquiera otros relativos a los Contenidos de Suscriptor en cualesquiera soportes conocidos (la “Licencia para la Prestación del Servicio”). La Licencia para la Prestación del Servicio comprenderá, de ser necesario o conveniente para tal fin, la facultad de ZICOFY de crear y explotar, con el mismo alcance indicado en este párrafo, obras derivadas de los Contenidos de Suscriptor. Al margen de lo anterior, ZICOFY puede llevar a cabo usos de los Contenidos de Suscriptor con la exclusiva finalidad de demostrar el funcionamiento de la Plataforma para promoverlo, para mejorarlo o adaptarlo a las tendencias o gustos de los Suscriptores y en general para desarrollar su negocio (el “Uso Propio”).
Con el alcance necesario o conveniente para llevar a cabo el Uso Propio, el Suscriptor autoriza a ZICOFY a explotar, para todo el mundo y durante todo su plazo de duración legal, todos los derechos de propiedad intelectual (incluyendo los de reproducción, distribución, comunicación pública o transformación), propiedad industrial, imagen o cualesquiera otros relativos a los Contenidos de Suscriptor facilitados por el Suscriptor en cualesquiera soportes conocidos (la “Licencia para el Uso Propio” y junto con la Licencia para la Prestación del Servicio, las “Licencias”). La Licencia para el Uso Propio comprenderá la facultad de ZICOFY de crear y explotar, con el mismo alcance indicado en este párrafo, obras derivadas de los Contenidos de Suscriptor. Este derecho de ZICOFY es concedido con carácter no exclusivo, irrevocable, gratuito, universal y plenamente sublicenciable. La Licencia para la Prestación del Servicio incluye, además, la facultad (pero no la obligación) de conservar una copia de seguridad de dichos Contenidos de Suscriptor a fin de acreditar el cumplimiento de las obligaciones legales de ZICOFY o de un Suscriptor o para colaborar con las autoridades públicas durante un plazo máximo correspondiente a la prescripción de las obligaciones legales. La baja del Suscriptor o del Contenido de Suscriptor no afectará a la Licencia de Uso Propio, que podrá explotarse por todo el plazo de duración legal de los derechos a ellos relativos, a salvo siempre la posibilidad de revocar expresamente la autorización respecto de aquellos derechos personalísimos en los que la Ley prevea esa posibilidad (como el derecho a la imagen del Suscriptor). El Suscriptor garantiza a ZICOFY que cuenta con los derechos necesarios para conceder las Licencias y que la utilización de los derechos de propiedad intelectual, industrial, de imagen o de la naturaleza que corresponda de conformidad con lo previsto no supone infracción legal, ni vulneración de los derechos de cualquier clase de tercero, ni incumplimiento de obligaciones contraídas con terceros ni constituye competencia desleal. En el supuesto de que existan dudas acerca de la licitud de la utilización de tales Contenidos de Suscriptor en la Plataforma, los portales a ella vinculados y en la aplicación móvil, ZICOFY recomienda a los Suscriptores que eviten emplearlos.
12. Protección de datos
Para acceder a determinados recursos de la Plataforma ya sea a través de la web o de la aplicación móvil, los Suscriptores deberán proporcionar previamente a ZICOFY, que actúa como mero gestor de la Plataforma, y, en su caso, a los Zicos ciertos datos de carácter personal (los “Datos Personales”). ZICOFY y, en su caso, los Zicos tratarán los Datos Personales con las finalidades así como bajo las condiciones definidas en la Política de Protección de Datos Personales.
En todo caso, el Suscriptor garantiza la autenticidad y actualidad de todos aquellos datos que comuniquen a ZICOFY a través de la Plataforma siendo el Suscriptor el único responsable de sus manifestaciones y de su actualización.
13. Duración del servicio proporcionado a través de la plataforma
La prestación del servicio tiene, en principio, una duración indefinida. No obstante, ZICOFY está autorizada para dar por terminada o suspender en todo o en parte la prestación en cualquier momento, sin perjuicio del respeto a los compromisos contractuales específicamente asumidos a cambio de una contraprestación económica y en virtud de condiciones específicas distintas de estas Condiciones Legales. La terminación del servicio en todo o en parte no obligará a ZICOFY a advertirlo previamente a los Suscriptores.
Todo Suscriptor puede terminar el uso de la Plataforma en cualquier momento.
14. Cesión del contrato
Ni el Suscriptor ni el Zico podrán ceder la Relación Contractual, en todo o en parte, y los derechos u obligaciones de ella derivados salvo autorización previa expresa y por escrito de ZICOFY.
ZICOFY (o quien explote la Plataforma en cada momento) podrán ceder la Relación Contractual, en todo o en parte, y todos o algunos de los derechos u obligaciones derivados de ella a cualquier tercero de su elección, sin previa autorización de los Suscriptores o comunicación previa a éstos, lo que conllevará la posibilidad de ceder a ese tercero los Datos Personales correspondientes para la explotación de esos derechos o el cumplimiento de las Relaciones Contractuales en que ese tercero quede subrogado como consecuencia de la cesión con el alcance previsto en la Política de Protección de Datos publicada.
15. Comunicaciones
Toda comunicación entre las partes deberá hacerse por escrito, sea por correo, telefax, WhatsApp, chat o correo electrónico enviados, en el caso de ZICOFY, a las direcciones indicadas en las Condiciones Legales. En el caso del Suscriptor, podrán hacerse las comunicaciones a los datos de contacto que éste haya facilitado y también mediante la publicación de un aviso en forma de banner o de otro tipo para avisar de determinados cambios. Se considerarán debidamente entregadas y recibidas las comunicaciones efectuadas por carta con acuse de recibo y las efectuadas por telegrama, telefax, WhatsApp, chat o correo electrónico cuando pueda acreditarse su recepción. Toda comunicación enviada a las direcciones facilitadas por los Suscriptores se entenderá correctamente efectuada, excepto si hubieran previamente notificado a ZICOFY un cambio de dirección con una antelación mínima de 15 días hábiles.
16. Modificacion de la relación contractual
Los Suscriptores son conscientes de que ZICOFY podrá modificar las presentes Condiciones Legales y la Relación Contractual en cualquier momento sin necesidad de informar de ello a los mismos. Los Suscriptores deberán consultar periódicamente las Condiciones Legales para conocer su versión aplicable en cada momento.
17. Miscelánea
Las presentes Condiciones Legales son la manifestación expresa de la voluntad de las partes en relación con su objeto e invalidan los acuerdos verbales y escritos alcanzados al respecto con anterioridad a su aceptación por el Suscriptor.
En caso de discrepancia entre las versiones de las Condiciones Legales, Política de Protección de Datos y/o cualquier otra documentación en los diferentes idiomas en los que hayan sido facilitadas por ZICOFY, prevalecerá su versión en español, siempre que sea legalmente posible.
La declaración de nulidad o invalidez de cualquier cláusula contenida en las presentes Condiciones Legales no afectará a la validez y eficacia de las demás cláusulas, que se interpretarán y aplicarán en el sentido lícito más próximo al que se derivase de la aplicación de la cláusula nula.
La renuncia por alguna de las partes al cumplimiento de cualquiera de las disposiciones de estas Condiciones Legales por la otra parte no constituirá una renuncia al derecho a reclamar el cumplimiento del resto de disposiciones de estas Condiciones Legales o de cualquier otra obligación. El retraso o la omisión de las partes en el ejercicio de algún derecho que le correspondiera por virtud de las Condiciones Legales tampoco constituirán una renuncia al derecho correspondiente.
18. Ley aplicable y jurisdicción
La Relación Contractual se regirá por la ley española.
Los Suscriptores, Zicos y ZICOFY se someten, con renuncia a cualquier otro fuero que pueda corresponderles, a los Jueces y Tribunales de la ciudad de Sevilla (España) en relación con cualquier disputa sobre la validez, eficacia, cumplimiento, interpretación, ejecución o cualquier otra cuestión relativa a la Relación Contractual.`}
              </Text>
            </Text>
          </View>
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  contenidoFlexBox: {
    alignItems: "center",
    flex: 1,
  },
  logoFlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  explicacionSpaceBlock: {
    marginTop: 20,
    alignSelf: "stretch",
  },
  textoFlexBox: {
    textAlign: "left",
    color: Color.colorGray_200,
    flex: 1,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  logo: {
    alignSelf: "stretch",
    justifyContent: "space-between",
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
  },
  iniciaSesion: {
    justifyContent: "center",
    alignSelf: "stretch",
  },
  trminosYCondiciones: {
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
  },
  leaEstosTrminosYCondicion: {
    fontFamily: FontFamily.poppinsRegular,
  },
  sitioWebDe: {
    textDecoration: "underline",
  },
  texto: {
    fontSize: FontSize.size_3xs,
    lineHeight: 20,
  },
  explicacion: {
    flexDirection: "row",
    alignItems: "center",
  },
  interactuable: {
    flex: 1,
    marginTop: 20,
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignSelf: "stretch",
  },
  terminosCondiciones: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    overflow: "hidden",
    paddingTop: Padding.p_27xl,
    justifyContent: "space-between",
    width: "100%",
  },
});

export default TerminosCondiciones;
