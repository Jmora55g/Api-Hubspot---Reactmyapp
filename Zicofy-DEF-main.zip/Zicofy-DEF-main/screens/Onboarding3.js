import * as React from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Component from "../components/Component";
import Property1Default1 from "../components/Property1Default1";
import { Padding, Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const Onboarding3 = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.onboarding3, styles.logoFlexBox1]}>
      <View style={[styles.contenido, styles.contenidoSpaceBlock]}>
        <View style={[styles.logo, styles.logoFlexBox]}>
          <Pressable style={styles.volver} onPress={() => navigation.goBack()}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/volver.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <ScrollView
          style={styles.interactuable}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.interactuableScrollViewContent}
        >
          <View style={[styles.tituloPantalla, styles.botnFlexBox]}>
            <Text style={[styles.titulo, styles.textoFlexBox]}>
              Conversa con las mentes maestras 💬
            </Text>
          </View>
          <View style={[styles.explicacion, styles.logoFlexBox]}>
            <Text style={[styles.texto, styles.textoFlexBox]}>
              <Text style={styles.con}>{`Con `}</Text>
              <Text style={styles.zicochat}>ZicoChat</Text>
              <Text
                style={styles.con}
              >{`, dialoga con IA's inspiradas en destacados `}</Text>
              <Text style={styles.zicochat}>psicólogos históricos</Text>
              <Text style={styles.con}>{` como Freud, Kahneman, Maslow y más.

Descubre nuevas perspectivas y enriquece tu entendimiento del `}</Text>
              <Text style={styles.zicochat}>bienestar emocional</Text>
              <Text style={styles.con}>.</Text>
            </Text>
          </View>
          <View style={styles.ilustracion}>
            <ImageBackground
              style={styles.ilustracionIcon}
              resizeMode="cover"
              source={require("../assets/artboard2copy1.png")}
            />
          </View>
        </ScrollView>
      </View>
      <View style={[styles.barraBaja, styles.botnFlexBox]}>
        <View style={styles.botnFlexBox}>
          <Component
            prop={require("../assets/21.png")}
            prop1={require("../assets/21.png")}
            prop2={require("../assets/11.png")}
            prop3={require("../assets/21.png")}
            viewPosition="unset"
          />
        </View>
        <View style={[styles.botn, styles.botnFlexBox]}>
          <Property1Default1
            property1DefaultPosition="unset"
            textoFlex={1}
            textoFontSize={17}
            textoLineHeight={24}
            textoFontWeight="600"
            textoFontFamily="Poppins-SemiBold"
            textoColor="#292929"
            textoTextAlign="center"
            onBotnPress={() => navigation.navigate("Onboarding4")}
            onTextoPress={() => {}}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  logoFlexBox1: {
    justifyContent: "space-between",
    alignItems: "center",
  },
  contenidoSpaceBlock: {
    paddingHorizontal: Padding.p_xl,
    alignSelf: "stretch",
  },
  logoFlexBox: {
    flexDirection: "row",
    alignSelf: "stretch",
  },
  botnFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  textoFlexBox: {
    textAlign: "left",
    color: Color.colorGray_200,
    flex: 1,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  logo: {
    justifyContent: "space-between",
    alignItems: "center",
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
  },
  tituloPantalla: {
    flexDirection: "row",
    alignSelf: "stretch",
  },
  con: {
    fontFamily: FontFamily.poppinsRegular,
  },
  zicochat: {
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
  },
  texto: {
    fontSize: FontSize.size_lg,
  },
  explicacion: {
    marginTop: 20,
    alignItems: "center",
  },
  ilustracionIcon: {
    width: 288,
    height: 254,
  },
  ilustracion: {
    marginTop: 20,
    alignItems: "center",
  },
  interactuable: {
    marginTop: 20,
    alignSelf: "stretch",
    flex: 1,
  },
  contenido: {
    paddingVertical: 0,
    alignItems: "center",
    flex: 1,
  },
  botn: {
    marginTop: 15,
    alignSelf: "stretch",
  },
  barraBaja: {
    borderTopLeftRadius: Border.br_mini,
    borderTopRightRadius: Border.br_mini,
    backgroundColor: Color.colorLightskyblue,
    paddingTop: Padding.p_xl,
    paddingBottom: Padding.p_11xl,
    paddingHorizontal: Padding.p_xl,
    alignSelf: "stretch",
  },
  onboarding3: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    paddingTop: Padding.p_27xl,
    width: "100%",
    flex: 1,
  },
});

export default Onboarding3;
