import * as React from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
  TouchableHighlight,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, Padding, FontFamily, FontSize, Border } from "../GlobalStyles";

const HomeScreen = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.home, styles.homeBg]}>
      <View style={[styles.contenido, styles.bannerSpaceBlock1]}>
        <View style={styles.logo}>
          <Pressable
            style={styles.sidebar}
            onPress={() => navigation.toggleDrawer()}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/sidebar.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo1.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="center"
            source={require("../assets/notifications.png")}
          />
        </View>
        <ScrollView
          style={[styles.interactuable, styles.bannerSpaceBlock]}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.interactuableScrollViewContent}
        >
          <View style={styles.saludo}>
            <Text style={styles.titulo}>Hola Agustín, buen día!</Text>
          </View>
          <Pressable
            style={[styles.banner, styles.bannerSpaceBlock]}
            onPress={() =>
              navigation.navigate("DrawerRoot", { screen: "BottomTabsRoot" })
            }
          >
            <View style={styles.textos}>
              <Text style={styles.encuentros1A}>Encuentros 1 a 1</Text>
              <Text style={styles.trabajaEnTu} numberOfLines={1}>
                Trabaja en tu bienestar emocional con tu Zico.
              </Text>
              <Text style={styles.agendaTuEncuentro} numberOfLines={1}>
                Agenda tu encuentro
              </Text>
            </View>
            <View style={styles.icono}>
              <Image
                style={styles.vectorIcon}
                contentFit="center"
                source={require("../assets/vector8.png")}
              />
            </View>
          </Pressable>
          <View style={[styles.botones, styles.bannerSpaceBlock]}>
            <Pressable style={[styles.tests, styles.testsFlexBox]}>
              <Image
                style={styles.testsChild}
                contentFit="cover"
                source={require("../assets/frame-509.png")}
              />
              <Pressable
                style={styles.testsWrapper}
                onPress={() =>
                  navigation.navigate("DrawerRoot", {
                    screen: "BottomTabsRoot",
                  })
                }
              >
                <Text style={[styles.tests1, styles.textoTypo]}>Tests</Text>
              </Pressable>
            </Pressable>
            <Pressable
              style={[styles.zicochat, styles.testsFlexBox]}
              ZicoChat="button"
              onPress={() =>
                navigation.navigate("DrawerRoot", { screen: "BottomTabsRoot" })
              }
            >
              <Image
                style={styles.zicochatChild}
                contentFit="cover"
                source={require("../assets/frame-507.png")}
              />
              <View style={styles.testsWrapper}>
                <Text style={[styles.texto, styles.textoFlexBox]}>
                  ZicoChat
                </Text>
              </View>
            </Pressable>
          </View>
          <View style={styles.frase}>
            <Text style={[styles.hechoEsMejor, styles.textoFlexBox]}>
              Hecho es mejor que perfecto
            </Text>
            <Image
              style={styles.vectorIcon1}
              contentFit="center"
              source={require("../assets/vector9.png")}
            />
          </View>
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  homeBg: {
    backgroundColor: Color.colorsNeutralWhite,
    justifyContent: "space-between",
  },
  bannerSpaceBlock1: {
    paddingHorizontal: Padding.p_xl,
    alignItems: "center",
  },
  bannerSpaceBlock: {
    marginTop: 20,
    alignSelf: "stretch",
  },
  testsFlexBox: {
    paddingVertical: Padding.p_xl,
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  textoTypo: {
    color: Color.colorDimgray_200,
    fontFamily: FontFamily.epilogueBold,
    fontWeight: "700",
  },
  textoFlexBox: {
    display: "flex",
    lineHeight: 32,
    fontSize: FontSize.size_sm,
    textAlign: "left",
    alignSelf: "stretch",
    alignItems: "center",
    flex: 1,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  sidebar: {
    height: 17,
    width: 25,
  },
  logoIcon: {
    height: 45,
    width: 40,
  },
  notificationsIcon: {
    height: 27,
    width: 25,
  },
  logo: {
    flexDirection: "row",
    alignSelf: "stretch",
    justifyContent: "space-between",
    alignItems: "center",
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    color: Color.colorGray_200,
    textAlign: "left",
    flex: 1,
  },
  saludo: {
    justifyContent: "center",
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  encuentros1A: {
    fontSize: FontSize.size_xl,
    fontWeight: "800",
    fontFamily: FontFamily.poppinsExtraBold,
    color: Color.colorsNeutralWhite,
    textAlign: "left",
    alignSelf: "stretch",
  },
  trabajaEnTu: {
    fontSize: FontSize.size_mini,
    fontWeight: "300",
    fontFamily: FontFamily.poppinsLight,
    opacity: 0.9,
    marginTop: 5,
    color: Color.colorsNeutralWhite,
    textAlign: "left",
    alignSelf: "stretch",
  },
  agendaTuEncuentro: {
    fontSize: FontSize.size_lg,
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    marginTop: 5,
    color: Color.colorsNeutralWhite,
    textAlign: "left",
    alignSelf: "stretch",
  },
  textos: {
    justifyContent: "center",
    alignSelf: "stretch",
    flex: 1,
  },
  vectorIcon: {
    width: 55,
    height: 116,
  },
  icono: {
    width: 89,
    marginLeft: 20,
    justifyContent: "center",
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  banner: {
    borderRadius: Border.br_xl,
    backgroundColor: Color.colorLightskyblue,
    paddingVertical: Padding.p_mini,
    justifyContent: "center",
    flexDirection: "row",
    paddingHorizontal: Padding.p_xl,
    alignItems: "center",
  },
  testsChild: {
    width: 17,
    height: 19,
  },
  tests1: {
    lineHeight: 32,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.epilogueBold,
    textAlign: "left",
    flex: 1,
  },
  testsWrapper: {
    marginLeft: 19,
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  tests: {
    paddingHorizontal: Padding.p_3xs,
    backgroundColor: Color.colorWhitesmoke_100,
    paddingVertical: Padding.p_xl,
    borderRadius: Border.br_mini,
    justifyContent: "center",
    flex: 1,
  },
  zicochatChild: {
    width: 20,
    height: 18,
  },
  texto: {
    color: Color.colorDimgray_200,
    fontFamily: FontFamily.epilogueBold,
    fontWeight: "700",
  },
  zicochat: {
    marginLeft: 10,
    paddingHorizontal: Padding.p_3xs,
    backgroundColor: Color.colorWhitesmoke_100,
    paddingVertical: Padding.p_xl,
    borderRadius: Border.br_mini,
    justifyContent: "center",
    flex: 1,
  },
  botones: {
    justifyContent: "center",
    flexDirection: "row",
  },
  hechoEsMejor: {
    fontFamily: FontFamily.poppinsRegular,
    color: Color.colorBlack,
  },
  vectorIcon1: {
    width: 27,
    height: 20,
    marginLeft: 11,
  },
  frase: {
    backgroundColor: "#f8f6f6",
    padding: Padding.p_mini,
    borderRadius: Border.br_mini,
    justifyContent: "center",
    marginTop: 20,
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  interactuable: {
    flex: 1,
  },
  contenido: {
    paddingVertical: 0,
    alignSelf: "stretch",
    flex: 1,
  },
  home: {
    height: 873,
    paddingTop: Padding.p_27xl,
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    flex: 1,
  },
});

export default HomeScreen;
