import * as React from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  Text,
  Linking,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Color, Border, Padding } from "../GlobalStyles";

const AjustesPlanes = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.ajustesPlanes, styles.contenidoFlexBox]}>
      <View style={[styles.contenido, styles.contenidoFlexBox]}>
        <View style={[styles.logo, styles.logoFlexBox]}>
          <Pressable style={styles.volver} onPress={() => navigation.goBack()}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/volver.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <View style={styles.interactuable}>
          <View style={[styles.mejoraSuscripcion, styles.botonFlexBox]}>
            <Text style={styles.titulo}>Mejora tu suscripción</Text>
          </View>
          <Pressable
            style={styles.planShadowBox}
            boton="plan_basico"
            onPress={() => navigation.navigate("AjustesPlanBasico")}
          >
            <View
              style={[
                styles.planBsico1EncuentroMensuaWrapper,
                styles.logoFlexBox,
              ]}
            >
              <Text style={styles.planBsico1ContainerFlexBox}>
                <Text style={styles.planBsicoTypo}>{`Plan básico
`}</Text>
                <Text style={styles.encuentroMensual}>1 encuentro mensual</Text>
              </Text>
            </View>
            <View style={[styles.boton, styles.botonFlexBox]}>
              <Image
                style={styles.vectorIcon}
                contentFit="center"
                source={require("../assets/vector4.png")}
              />
            </View>
          </Pressable>
          <Pressable
            style={styles.planShadowBox}
            boton="plan_estandar"
            onPress={() => navigation.navigate("AjustesPlanEstandar")}
          >
            <View
              style={[
                styles.planBsico1EncuentroMensuaWrapper,
                styles.logoFlexBox,
              ]}
            >
              <Text style={styles.planBsico1ContainerFlexBox}>
                <Text style={styles.planBsicoTypo}>{`Plan estándar
`}</Text>
                <Text style={styles.encuentroMensual}>
                  2 encuentros mensual
                </Text>
              </Text>
            </View>
            <View style={[styles.boton, styles.botonFlexBox]}>
              <Image
                style={styles.vectorIcon}
                contentFit="center"
                source={require("../assets/vector4.png")}
              />
            </View>
          </Pressable>
          <Pressable
            style={styles.planShadowBox}
            boton="plan_premium"
            onPress={() => navigation.navigate("AjustesPlanPremium")}
          >
            <View
              style={[
                styles.planBsico1EncuentroMensuaWrapper,
                styles.logoFlexBox,
              ]}
            >
              <Text style={styles.planBsico1ContainerFlexBox}>
                <Text style={styles.planBsicoTypo}>{`Plan premium
`}</Text>
                <Text style={styles.encuentroMensual}>
                  4 encuentros mensuales
                </Text>
              </Text>
            </View>
            <View style={[styles.boton, styles.botonFlexBox]}>
              <Image
                style={styles.vectorIcon}
                contentFit="center"
                source={require("../assets/vector4.png")}
              />
            </View>
          </Pressable>
          <Pressable
            style={styles.planShadowBox}
            onPress={() =>
              Linking.openURL(
                "https://billing.stripe.com/p/login/3csbKo81T7iT2WI288"
              )
            }
          >
            <View
              style={[
                styles.planBsico1EncuentroMensuaWrapper,
                styles.logoFlexBox,
              ]}
            >
              <Text
                style={[styles.administraTuSuscripcin, styles.planBsicoTypo]}
              >
                Administra tu suscripción
              </Text>
            </View>
            <View style={[styles.boton, styles.botonFlexBox]}>
              <Image
                style={styles.vectorIcon}
                contentFit="center"
                source={require("../assets/vector4.png")}
              />
            </View>
          </Pressable>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  contenidoFlexBox: {
    alignItems: "center",
    flex: 1,
  },
  logoFlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  botonFlexBox: {
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
  },
  planBsicoTypo: {
    fontFamily: FontFamily.epilogueExtraBold,
    fontWeight: "800",
    fontSize: FontSize.size_3xl,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  logo: {
    alignSelf: "stretch",
    justifyContent: "space-between",
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    color: Color.colorGray_200,
    textAlign: "center",
    flex: 1,
  },
  mejoraSuscripcion: {
    alignSelf: "stretch",
  },
  encuentroMensual: {
    fontSize: FontSize.size_mini,
    fontFamily: FontFamily.epilogueRegular,
  },
  planBsico1ContainerFlexBox: {
    textAlign: "left",
    color: Color.colorsNeutralWhite,
    flex: 1,
  },
  planBsico1EncuentroMensuaWrapper: {
    flex: 1,
  },
  vectorIcon: {
    width: 14,
    height: 14,
  },
  boton: {
    borderRadius: Border.br_61xl,
    padding: Padding.p_3xs,
    marginLeft: 5,
    backgroundColor: Color.colorsNeutralWhite,
  },
  planShadowBox: {
    padding: Padding.p_xl,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorLightskyblue,
    borderRadius: Border.br_xl,
    justifyContent: "center",
    marginTop: 20,
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  administraTuSuscripcin: {
    textAlign: "left",
    color: Color.colorsNeutralWhite,
    flex: 1,
  },
  interactuable: {
    marginTop: 20,
    alignSelf: "stretch",
    alignItems: "center",
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignSelf: "stretch",
  },
  ajustesPlanes: {
    height: 873,
    paddingTop: Padding.p_27xl,
    justifyContent: "space-between",
    width: "100%",
    backgroundColor: Color.colorsNeutralWhite,
  },
});

export default AjustesPlanes;
