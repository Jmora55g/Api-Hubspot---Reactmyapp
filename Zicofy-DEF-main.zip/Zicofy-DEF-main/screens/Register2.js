import * as React from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Property1Default3 from "../components/Property1Default3";
import { Color, FontSize, FontFamily, Padding } from "../GlobalStyles";

const Register2 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.register2}>
      <View style={styles.contenido}>
        <View style={[styles.logo, styles.logoFlexBox]}>
          <Pressable style={styles.volver} onPress={() => navigation.goBack()}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/volver11.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <ScrollView
          style={[styles.interactuable, styles.explicacionSpaceBlock]}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.interactuableScrollViewContent}
        >
          <View style={[styles.iniciaSesion, styles.logoFlexBox]}>
            <Text style={[styles.titulo, styles.textoFlexBox]}>
              ¡Ya casi estamos! 🎉
            </Text>
          </View>
          <View style={[styles.explicacion, styles.explicacionSpaceBlock]}>
            <Text style={[styles.texto, styles.textoFlexBox]}>
              <Text
                style={styles.alRegistrarteEn}
              >{`Al registrarte en Zicofy, accedes sin costo a `}</Text>
              <Text style={styles.zicochat}>ZicoChat</Text>
              <Text style={styles.alRegistrarteEn}>{` y nuestro `}</Text>
              <Text style={styles.zicochat}>Test de Bienestar</Text>
              <Text
                style={styles.alRegistrarteEn}
              >{`, herramientas geniales para explorar y entender mejor tu `}</Text>
              <Text style={styles.zicochat}>bienestar emocional</Text>
              <Text style={styles.alRegistrarteEn}>{`.

Si deseas profundizar más, puedes optar por una suscripción de pago para agendar encuentros personalizados.

Para brindarte estas herramientas, necesitamos tu aceptación y consentimiento a nuestros términos y condiciones y política de privacidad`}</Text>
            </Text>
          </View>
          <View style={[styles.explicacion, styles.explicacionSpaceBlock]}>
            <Pressable
              onPress={() => navigation.navigate("TerminosCondiciones")}
            >
              <Text style={styles.texto2Typo}>
                Leer términos y condiciones.
              </Text>
            </Pressable>
          </View>
          <Pressable
            style={[styles.explicacion, styles.explicacionSpaceBlock]}
            onPress={() => navigation.navigate("PoliticaPrivacidad")}
          >
            <Text style={styles.texto2Typo}>Leer política de privacidad.</Text>
          </Pressable>
          <View style={[styles.iniciarSesion, styles.explicacionSpaceBlock]}>
            <Property1Default3
              texto="Acepto crear mi cuenta"
              property1DefaultPosition="unset"
              property1DefaultAlignSelf="stretch"
              property1DefaultBackgroundColor="#ffd7f3"
              textoFlex={1}
              onIniciarSesinPress={() => navigation.navigate("Register3")}
            />
          </View>
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  logoFlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  explicacionSpaceBlock: {
    marginTop: 20,
    alignSelf: "stretch",
  },
  textoFlexBox: {
    textAlign: "left",
    color: Color.colorGray_200,
    flex: 1,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  logo: {
    alignSelf: "stretch",
    justifyContent: "space-between",
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
  },
  iniciaSesion: {
    alignSelf: "stretch",
  },
  alRegistrarteEn: {
    fontFamily: FontFamily.poppinsRegular,
  },
  zicochat: {
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
  },
  texto: {
    fontSize: FontSize.size_lg,
  },
  explicacion: {
    flexDirection: "row",
    alignItems: "center",
  },
  texto2Typo: {
    color: Color.colorLightskyblue,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    textAlign: "left",
    flex: 1,
  },
  iniciarSesion: {
    justifyContent: "center",
    alignItems: "center",
  },
  interactuable: {
    flex: 1,
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignSelf: "stretch",
    alignItems: "center",
    flex: 1,
  },
  register2: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    paddingTop: Padding.p_27xl,
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    flex: 1,
  },
});

export default Register2;
