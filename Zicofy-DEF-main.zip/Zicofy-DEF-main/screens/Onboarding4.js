import * as React from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Component from "../components/Component";
import Property1Default1 from "../components/Property1Default1";
import { Padding, Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const Onboarding4 = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.onboarding4, styles.logoFlexBox]}>
      <View style={[styles.contenido, styles.contenidoSpaceBlock]}>
        <View style={[styles.logo, styles.logoFlexBox]}>
          <Pressable style={styles.volver} onPress={() => navigation.goBack()}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/volver.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <ScrollView
          style={styles.interactuable}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.interactuableScrollViewContent}
        >
          <View style={[styles.tituloPantalla, styles.barraBajaFlexBox]}>
            <Text style={[styles.titulo, styles.textoFlexBox]}>
              ¡Crea tu cuenta gratuita de Zicofy! 🙌🏻
            </Text>
          </View>
          <View style={styles.explicacion}>
            <Text style={[styles.texto, styles.textoFlexBox]}>
              <Text style={styles.crearTuCuenta}>{`Crear tu cuenta es `}</Text>
              <Text style={styles.sperFcilY}>súper fácil y rápido</Text>
              <Text style={styles.crearTuCuenta}>{`.

Solo necesitas unos minutos para empezar tu camino hacia un `}</Text>
              <Text style={styles.sperFcilY}>bienestar emocional</Text>
              <Text style={styles.crearTuCuenta}>{` mejor con Zicofy. 

¡Vamos, estamos aquí para acompañarte!`}</Text>
            </Text>
          </View>
          <View style={[styles.ilustracion, styles.barraBajaFlexBox]}>
            <ImageBackground
              style={styles.ilustracionIcon}
              resizeMode="cover"
              source={require("../assets/ilustracion.png")}
            />
          </View>
        </ScrollView>
      </View>
      <View style={[styles.barraBaja, styles.barraBajaFlexBox]}>
        <View style={styles.barraBajaFlexBox}>
          <Component
            prop={require("../assets/21.png")}
            prop1={require("../assets/21.png")}
            prop2={require("../assets/11.png")}
            prop3={require("../assets/21.png")}
            viewPosition="unset"
          />
        </View>
        <View style={styles.botonFlexBox}>
          <Property1Default1
            texto="Crear cuenta GRATUITA"
            property1DefaultPosition="unset"
            textoFlex={1}
            textoFontSize={17}
            textoLineHeight={24}
            textoFontWeight="600"
            textoFontFamily="Poppins-SemiBold"
            textoColor="#292929"
            textoTextAlign="center"
            onBotnPress={() => navigation.navigate("Register1")}
          />
        </View>
        <View style={[styles.texto1, styles.botonFlexBox]}>
          <Pressable
            numberOfLines={1}
            onPress={() => navigation.navigate("Login1")}
          >
            <Text style={styles.yaTengoCuentaIniciaSesin}>
              Ya tengo cuenta, inicia sesión
            </Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  logoFlexBox: {
    justifyContent: "space-between",
    alignItems: "center",
  },
  contenidoSpaceBlock: {
    paddingHorizontal: Padding.p_xl,
    alignSelf: "stretch",
  },
  barraBajaFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  textoFlexBox: {
    textAlign: "left",
    color: Color.colorGray_200,
    flex: 1,
  },
  botonFlexBox: {
    marginTop: 15,
    justifyContent: "center",
    alignSelf: "stretch",
    alignItems: "center",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  logo: {
    flexDirection: "row",
    alignSelf: "stretch",
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
  },
  tituloPantalla: {
    flexDirection: "row",
    alignSelf: "stretch",
  },
  crearTuCuenta: {
    fontFamily: FontFamily.poppinsRegular,
  },
  sperFcilY: {
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
  },
  texto: {
    fontSize: FontSize.size_lg,
  },
  explicacion: {
    marginTop: 20,
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  ilustracionIcon: {
    width: 369,
    height: 215,
  },
  ilustracion: {
    marginTop: 20,
  },
  interactuable: {
    marginTop: 20,
    alignSelf: "stretch",
    flex: 1,
  },
  contenido: {
    paddingVertical: 0,
    alignItems: "center",
    flex: 1,
  },
  yaTengoCuentaIniciaSesin: {
    fontSize: FontSize.size_sm,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.colorThistle,
    textAlign: "center",
    flex: 1,
  },
  texto1: {
    flexDirection: "row",
  },
  barraBaja: {
    borderTopLeftRadius: Border.br_mini,
    borderTopRightRadius: Border.br_mini,
    backgroundColor: Color.colorLightskyblue,
    paddingTop: Padding.p_xl,
    paddingBottom: Padding.p_11xl,
    paddingHorizontal: Padding.p_xl,
    alignSelf: "stretch",
  },
  onboarding4: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    paddingTop: Padding.p_27xl,
    width: "100%",
    flex: 1,
  },
});

export default Onboarding4;
