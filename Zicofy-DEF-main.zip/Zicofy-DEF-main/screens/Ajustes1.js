import React, { useState, useCallback } from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
  Linking,
  Modal,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import ModalLogOut from "../components/ModalLogOut";
import { Padding, Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const Ajustes1 = () => {
  const navigation = useNavigation();
  const [boton6Visible, setBoton6Visible] = useState(false);

  const openBoton6 = useCallback(() => {
    setBoton6Visible(true);
  }, []);

  const closeBoton6 = useCallback(() => {
    setBoton6Visible(false);
  }, []);

  return (
    <>
      <View style={styles.ajustes}>
        <View style={styles.contenido}>
          <View style={[styles.logo, styles.logoFlexBox]}>
            <Pressable
              style={styles.volver}
              onPress={() => navigation.goBack()}
            >
              <Image
                style={styles.icon}
                contentFit="cover"
                source={require("../assets/volver.png")}
              />
            </Pressable>
            <ImageBackground
              style={styles.logoIcon}
              resizeMode="center"
              source={require("../assets/logo.png")}
            />
            <Image
              style={styles.notificationsIcon}
              contentFit="cover"
              source={require("../assets/notifications.png")}
            />
          </View>
          <ScrollView
            style={[styles.interactuable, styles.botonesSpaceBlock]}
            showsVerticalScrollIndicator={true}
            showsHorizontalScrollIndicator={true}
            contentContainerStyle={styles.interactuableScrollViewContent}
          >
            <View style={[styles.tituloPantalla, styles.logoFlexBox]}>
              <Text style={styles.titulo}>Ajustes</Text>
            </View>
            <View style={[styles.botones, styles.botonesSpaceBlock]}>
              <Pressable
                style={styles.botonFlexBox}
                onPress={() => navigation.navigate("AjustesPerfil")}
              >
                <Image
                  style={styles.icon1}
                  contentFit="cover"
                  source={require("../assets/icon1.png")}
                />
                <View style={[styles.editarPerfil, styles.logoFlexBox]}>
                  <Text style={styles.texto}>Editar perfil</Text>
                </View>
              </Pressable>
              <Pressable
                style={[styles.boton1, styles.botonFlexBox]}
                onPress={() => navigation.navigate("AjustesSeguridad")}
              >
                <Image
                  style={styles.icon2}
                  contentFit="cover"
                  source={require("../assets/icon2.png")}
                />
                <View style={[styles.editarPerfil, styles.logoFlexBox]}>
                  <Text style={styles.texto}>Seguridad</Text>
                </View>
              </Pressable>
              <Pressable
                style={[styles.boton1, styles.botonFlexBox]}
                onPress={() => navigation.navigate("AjustesPlanes")}
              >
                <Image
                  style={styles.icon3}
                  contentFit="cover"
                  source={require("../assets/icon3.png")}
                />
                <View style={[styles.editarPerfil, styles.logoFlexBox]}>
                  <Text style={styles.texto}>Mi suscripción</Text>
                </View>
              </Pressable>
              <Pressable
                style={[styles.boton1, styles.botonFlexBox]}
                onPress={() => Linking.openURL("https://zicofy.com/contacto/")}
              >
                <Image
                  style={styles.icon4}
                  contentFit="cover"
                  source={require("../assets/icon4.png")}
                />
                <View style={[styles.editarPerfil, styles.logoFlexBox]}>
                  <Text style={styles.texto}>Ayuda y soporte</Text>
                </View>
              </Pressable>
              <Pressable
                style={[styles.boton1, styles.botonFlexBox]}
                onPress={() => navigation.navigate("TerminosCondiciones")}
              >
                <Image
                  style={styles.icon4}
                  contentFit="cover"
                  source={require("../assets/icon5.png")}
                />
                <View style={[styles.editarPerfil, styles.logoFlexBox]}>
                  <Text style={styles.texto}>Términos y condiciones</Text>
                </View>
              </Pressable>
              <Pressable
                style={[styles.boton1, styles.botonFlexBox]}
                onPress={() => navigation.navigate("PoliticaPrivacidad")}
              >
                <Image
                  style={styles.icon4}
                  contentFit="cover"
                  source={require("../assets/icon5.png")}
                />
                <View style={[styles.editarPerfil, styles.logoFlexBox]}>
                  <Text style={styles.texto}>Política de privacidad</Text>
                </View>
              </Pressable>
              <Pressable
                style={[styles.boton1, styles.botonFlexBox]}
                onPress={openBoton6}
              >
                <Image
                  style={styles.icon7}
                  contentFit="cover"
                  source={require("../assets/icon6.png")}
                />
                <View style={[styles.editarPerfil, styles.logoFlexBox]}>
                  <Text style={styles.texto}>Cerrar sesión</Text>
                </View>
              </Pressable>
            </View>
          </ScrollView>
        </View>
      </View>

      <Modal animationType="fade" transparent visible={boton6Visible}>
        <View style={styles.boton6Overlay}>
          <Pressable style={styles.boton6Bg} onPress={closeBoton6} />
          <ModalLogOut onClose={closeBoton6} />
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  logoFlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  botonesSpaceBlock: {
    marginTop: 20,
    alignSelf: "stretch",
  },
  botonFlexBox: {
    paddingVertical: Padding.p_3xs,
    paddingHorizontal: Padding.p_mini,
    backgroundColor: Color.colorWhitesmoke_200,
    borderRadius: Border.br_mini,
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  logo: {
    alignSelf: "stretch",
    justifyContent: "space-between",
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    color: Color.colorGray_200,
    textAlign: "center",
    flex: 1,
  },
  tituloPantalla: {
    justifyContent: "center",
    alignSelf: "stretch",
  },
  icon1: {
    width: 24,
    height: 22,
  },
  texto: {
    fontSize: FontSize.size_lg,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.colorBlack,
    textAlign: "left",
    flex: 1,
  },
  editarPerfil: {
    marginLeft: 15,
    flex: 1,
  },
  icon2: {
    width: 22,
    height: 25,
  },
  boton1: {
    marginTop: 10,
  },
  icon3: {
    height: 20,
    width: 27,
  },
  icon4: {
    width: 27,
    height: 25,
  },
  boton6Overlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(113, 113, 113, 0.3)",
  },
  boton6Bg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    left: 0,
    top: 0,
  },
  icon7: {
    height: 23,
    width: 24,
  },
  botones: {
    alignItems: "center",
  },
  interactuable: {
    flex: 1,
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignSelf: "stretch",
    alignItems: "center",
    flex: 1,
  },
  ajustes: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    paddingTop: Padding.p_27xl,
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    flex: 1,
  },
});

export default Ajustes1;
