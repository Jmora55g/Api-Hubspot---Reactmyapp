import * as React from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Property1Default3 from "../components/Property1Default3";
import { Color, Border, FontSize, FontFamily, Padding } from "../GlobalStyles";

const QuizAdentro = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.quizAdentro}>
      <View style={[styles.contenido, styles.contenidoFlexBox]}>
        <View style={[styles.logo, styles.logoFlexBox]}>
          <Pressable style={styles.volver} onPress={() => navigation.goBack()}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/volver.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <ScrollView
          style={[styles.interactuable, styles.contenidoFlexBox]}
          showsVerticalScrollIndicator={true}
          showsHorizontalScrollIndicator={true}
          contentContainerStyle={styles.interactuableScrollViewContent}
        >
          <View style={[styles.interactuableInner, styles.iniciarSesionLayout]}>
            <ImageBackground
              style={[styles.frameChild, styles.contenidoFlexBox]}
              resizeMode="center"
              source={require("../assets/rectangle1153.png")}
            />
          </View>
          <View style={[styles.iniciaSesion, styles.logoFlexBox]}>
            <Text style={[styles.titulo, styles.textoFlexBox]}>
              Test de Bienestar Emocional
            </Text>
          </View>
          <View style={[styles.explicacion, styles.logoFlexBox]}>
            <Text
              style={[styles.texto, styles.textoFlexBox]}
            >{`😊 Con tu info, vamos a encontrar el Zico perfecto para ti, para que chatear sea aún más agradable
Queremos que te sientas súper conectado y comprendido 🤝. ¿Nos ayudas? 
Por favor, selecciona los ítems que más te representen en las conversaciones 📝`}</Text>
          </View>
          <Pressable
            style={[styles.iniciarSesion, styles.iniciarSesionLayout]}
            boton="comenzar_test"
            onPress={() => navigation.navigate("QuizAdentroPreguntas")}
          >
            <Property1Default3
              texto="Comenzar Test de Bienestar"
              property1DefaultPosition="unset"
              property1DefaultAlignSelf="stretch"
              property1DefaultBackgroundColor="#ffd7f3"
              textoFlex={1}
              onIniciarSesinPress={() =>
                navigation.navigate("QuizAdentroPreguntas")
              }
            />
          </Pressable>
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  contenidoFlexBox: {
    alignSelf: "stretch",
    flex: 1,
  },
  logoFlexBox: {
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  iniciarSesionLayout: {
    width: 380,
    alignItems: "center",
  },
  textoFlexBox: {
    textAlign: "left",
    color: Color.colorGray_200,
    flex: 1,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  logo: {
    justifyContent: "space-between",
  },
  frameChild: {
    borderRadius: Border.br_mini,
  },
  interactuableInner: {
    height: 250,
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
  },
  iniciaSesion: {
    justifyContent: "center",
    marginTop: 20,
  },
  texto: {
    fontSize: FontSize.size_lg,
    fontFamily: FontFamily.poppinsRegular,
  },
  explicacion: {
    marginTop: 20,
  },
  iniciarSesion: {
    marginTop: 20,
  },
  interactuable: {
    marginTop: 20,
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignItems: "center",
  },
  quizAdentro: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    paddingTop: Padding.p_27xl,
    paddingBottom: Padding.p_xl,
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    flex: 1,
  },
});

export default QuizAdentro;
