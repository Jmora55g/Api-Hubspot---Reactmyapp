import * as React from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Property1Default3 from "../components/Property1Default3";
import { Color, FontSize, FontFamily, Padding } from "../GlobalStyles";

const Register3 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.register3}>
      <View style={[styles.contenido, styles.contenidoFlexBox]}>
        <View style={styles.logoFlexBox}>
          <Pressable style={styles.volver} onPress={() => navigation.goBack()}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/volver11.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <ScrollView
          style={[styles.interactuable, styles.contenidoFlexBox]}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.interactuableScrollViewContent}
        >
          <View style={styles.logoFlexBox}>
            <Text style={[styles.titulo, styles.textoFlexBox]}>
              ¡Bienvenido a Zicofy!
            </Text>
          </View>
          <View style={[styles.explicacion, styles.logoFlexBox]}>
            <Text
              style={[styles.texto, styles.textoFlexBox]}
            >{`¡Gracias por registrarte en nuestra aplicación!
¡Ya puedes comenzar a utilizar tu cuenta gratuita!`}</Text>
          </View>
          <View style={styles.ilustracion}>
            <ImageBackground
              style={styles.artboard222}
              resizeMode="cover"
              source={require("../assets/artboard222.png")}
            />
          </View>
          <View style={styles.iniciarSesion}>
            <Property1Default3
              texto="Ir al menú principal"
              property1DefaultPosition="unset"
              property1DefaultAlignSelf="stretch"
              property1DefaultBackgroundColor="#ffd7f3"
              textoFlex={1}
              onIniciarSesinPress={() => navigation.navigate("Login1")}
            />
          </View>
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  contenidoFlexBox: {
    flex: 1,
    alignSelf: "stretch",
  },
  textoFlexBox: {
    textAlign: "left",
    color: Color.colorGray_200,
    flex: 1,
  },
  logoFlexBox: {
    flexDirection: "row",
    alignSelf: "stretch",
    justifyContent: "space-between",
    alignItems: "center",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
  },
  texto: {
    fontSize: FontSize.size_lg,
    fontFamily: FontFamily.poppinsRegular,
  },
  explicacion: {
    marginTop: 20,
  },
  artboard222: {
    width: 372,
    height: 246,
  },
  ilustracion: {
    justifyContent: "center",
    marginTop: 20,
    alignItems: "center",
  },
  iniciarSesion: {
    marginTop: 20,
    alignSelf: "stretch",
    alignItems: "center",
  },
  interactuable: {
    marginTop: 20,
    alignSelf: "stretch",
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignSelf: "stretch",
    alignItems: "center",
  },
  register3: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    paddingTop: Padding.p_27xl,
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    flex: 1,
  },
});

export default Register3;
