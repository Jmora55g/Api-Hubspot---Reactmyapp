import * as React from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, FontSize, Border, Padding } from "../GlobalStyles";

const Zicochat = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.zicochat, styles.logoFlexBox]}>
      <View style={styles.contenido}>
        <View style={[styles.logo, styles.logoFlexBox]}>
          <Pressable
            style={styles.sidebar}
            onPress={() => navigation.toggleDrawer()}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/sidebar.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo1.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <ScrollView
          style={[styles.interactuable, styles.subtituloSpaceBlock]}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.interactuableScrollViewContent}
        >
          <View style={styles.explicacion}>
            <Text style={[styles.texto, styles.textoFlexBox]}>
              <Text style={styles.bienvenidoA}>{`Bienvenido a `}</Text>
              <Text style={styles.zicochat1}>ZicoChat</Text>
              <Text
                style={styles.bienvenidoA}
              >{`, donde puedes charlar con IA's inspiradas en los grandes psicólogos de la historia.

Explora ideas, obtén insights y diviértete aprendiendo, `}</Text>
              <Text style={styles.zicochat1}>¡todo de forma gratuita!</Text>
              <Text style={styles.bienvenidoA}>
                {" "}
                Escoge un contacto y comienza a descubrir.
              </Text>
            </Text>
          </View>
          <View style={[styles.subtitulo, styles.subtituloSpaceBlock]}>
            <Text style={styles.subtitulo1} numberOfLines={1}>
              Disponibles
            </Text>
          </View>
          <View style={[styles.chatsDisponibles, styles.subtituloSpaceBlock]}>
            <Pressable
              style={styles.zicoAi}
              onPress={() => navigation.navigate("ZicochatConversacion")}
            >
              <View style={styles.fotoPerfil}>
                <Image
                  style={styles.imagenIcon}
                  contentFit="cover"
                  source={require("../assets/imagen2.png")}
                />
              </View>
              <Pressable
                style={styles.textos}
                Zico="button"
                onPress={() => navigation.navigate("ZicochatConversacion")}
              >
                <View style={styles.nombreWrapper}>
                  <Text style={[styles.nombre, styles.textoFlexBox]}>
                    Zico AI
                  </Text>
                </View>
                <View style={styles.descripcionWrapper}>
                  <Text style={[styles.descripcion, styles.textoFlexBox]}>
                    Hablemos sobre tí
                  </Text>
                </View>
              </Pressable>
            </Pressable>
            <Pressable
              style={[styles.subtitulo, styles.subtituloSpaceBlock]}
              onPress={() => {}}
            >
              <View style={styles.fotoPerfil1}>
                <Image
                  style={styles.imagenIcon}
                  contentFit="cover"
                  source={require("../assets/imagen3.png")}
                />
              </View>
              <Pressable
                style={styles.textos}
                Zico="button"
                onPress={() => navigation.navigate("ZicochatConversacion")}
              >
                <View style={styles.nombreWrapper}>
                  <Text style={[styles.nombre, styles.textoFlexBox]}>
                    Sigmund Freud
                  </Text>
                </View>
                <View style={styles.descripcionWrapper}>
                  <Text style={[styles.descripcion, styles.textoFlexBox]}>
                    Descifrando sueños, revelando secretos
                  </Text>
                </View>
              </Pressable>
            </Pressable>
            <Pressable style={[styles.subtitulo, styles.subtituloSpaceBlock]}>
              <View style={styles.fotoPerfil1}>
                <Image
                  style={styles.imagenIcon}
                  contentFit="cover"
                  source={require("../assets/imagen4.png")}
                />
              </View>
              <Pressable
                style={styles.textos}
                Zico="button"
                onPress={() => navigation.navigate("ZicochatConversacion")}
              >
                <View style={styles.nombreWrapper}>
                  <Text style={[styles.nombre, styles.textoFlexBox]}>
                    Wilhelm Wundt
                  </Text>
                </View>
                <View style={styles.descripcionWrapper}>
                  <Text style={[styles.descripcion, styles.textoFlexBox]}>
                    Observando la mente, creando ciencia
                  </Text>
                </View>
              </Pressable>
            </Pressable>
            <Pressable style={[styles.subtitulo, styles.subtituloSpaceBlock]}>
              <View style={styles.fotoPerfil1}>
                <Image
                  style={styles.imagenIcon}
                  contentFit="cover"
                  source={require("../assets/imagen5.png")}
                />
              </View>
              <Pressable
                style={styles.textos}
                Zico="button"
                onPress={() => navigation.navigate("ZicochatConversacion")}
              >
                <View style={styles.nombreWrapper}>
                  <Text style={[styles.nombre, styles.textoFlexBox]}>
                    Abraham Maslow
                  </Text>
                </View>
                <View style={styles.descripcionWrapper}>
                  <Text style={[styles.descripcion, styles.textoFlexBox]}>
                    Ascendiendo hacia la autorrealización
                  </Text>
                </View>
              </Pressable>
            </Pressable>
            <Pressable style={[styles.subtitulo, styles.subtituloSpaceBlock]}>
              <View style={styles.fotoPerfil1}>
                <Image
                  style={styles.imagenIcon}
                  contentFit="cover"
                  source={require("../assets/imagen6.png")}
                />
              </View>
              <Pressable
                style={styles.textos}
                Zico="button"
                onPress={() => navigation.navigate("ZicochatConversacion")}
              >
                <View style={styles.nombreWrapper}>
                  <Text style={[styles.nombre, styles.textoFlexBox]}>
                    Daniel Kahneman
                  </Text>
                </View>
                <View style={styles.descripcionWrapper}>
                  <Text style={[styles.descripcion, styles.textoFlexBox]}>
                    Desentrañando la lógica de la ilógica
                  </Text>
                </View>
              </Pressable>
            </Pressable>
            <Pressable style={[styles.subtitulo, styles.subtituloSpaceBlock]}>
              <View style={styles.fotoPerfil1}>
                <Image
                  style={styles.imagenIcon}
                  contentFit="cover"
                  source={require("../assets/imagen7.png")}
                />
              </View>
              <Pressable
                style={styles.textos}
                Zico="button"
                onPress={() => navigation.navigate("ZicochatConversacion")}
              >
                <View style={styles.nombreWrapper}>
                  <Text style={[styles.nombre, styles.textoFlexBox]}>
                    Ivan Pavlov
                  </Text>
                </View>
                <View style={styles.descripcionWrapper}>
                  <Text style={[styles.descripcion, styles.textoFlexBox]}>
                    Descubriendo patrones
                  </Text>
                </View>
              </Pressable>
            </Pressable>
          </View>
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  logoFlexBox: {
    justifyContent: "space-between",
    alignItems: "center",
  },
  subtituloSpaceBlock: {
    marginTop: 20,
    alignSelf: "stretch",
  },
  textoFlexBox: {
    textAlign: "left",
    flex: 1,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  sidebar: {
    height: 17,
    width: 25,
  },
  logoIcon: {
    height: 45,
    width: 40,
  },
  notificationsIcon: {
    height: 27,
    width: 25,
  },
  logo: {
    flexDirection: "row",
    alignSelf: "stretch",
  },
  bienvenidoA: {
    fontFamily: FontFamily.poppinsRegular,
  },
  zicochat1: {
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
  },
  texto: {
    color: Color.colorGray_200,
    fontSize: FontSize.size_lg,
  },
  explicacion: {
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  subtitulo1: {
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.colorGray_500,
    textAlign: "center",
    fontSize: FontSize.size_lg,
    flex: 1,
  },
  subtitulo: {
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
  },
  imagenIcon: {
    borderRadius: Border.br_12xl,
    width: 54,
    height: 52,
  },
  fotoPerfil: {
    justifyContent: "center",
    alignItems: "center",
  },
  nombre: {
    lineHeight: 18,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    color: Color.colorLightskyblue,
    fontSize: FontSize.size_lg,
  },
  nombreWrapper: {
    alignItems: "flex-end",
    justifyContent: "center",
    flexDirection: "row",
    alignSelf: "stretch",
    flex: 1,
  },
  descripcion: {
    fontSize: FontSize.size_sm,
    lineHeight: 12,
    color: Color.colorGray_100,
    fontFamily: FontFamily.poppinsRegular,
  },
  descripcionWrapper: {
    marginTop: 8,
    justifyContent: "center",
    flexDirection: "row",
    alignSelf: "stretch",
    flex: 1,
  },
  textos: {
    marginLeft: 10,
    justifyContent: "center",
    alignSelf: "stretch",
    alignItems: "center",
    flex: 1,
  },
  zicoAi: {
    justifyContent: "center",
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  fotoPerfil1: {
    justifyContent: "center",
    alignSelf: "stretch",
    alignItems: "center",
  },
  chatsDisponibles: {
    justifyContent: "center",
    alignItems: "center",
  },
  interactuable: {
    flex: 1,
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignSelf: "stretch",
    alignItems: "center",
    flex: 1,
  },
  zicochat: {
    height: 873,
    paddingTop: Padding.p_27xl,
    width: "100%",
    flex: 1,
    backgroundColor: Color.colorsNeutralWhite,
    justifyContent: "space-between",
  },
});

export default Zicochat;
