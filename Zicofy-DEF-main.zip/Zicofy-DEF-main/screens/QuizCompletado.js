import * as React from "react";
import {
  View,
  Pressable,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Text,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Property1Default3 from "../components/Property1Default3";
import { Color, FontSize, FontFamily, Padding } from "../GlobalStyles";

const QuizCompletado = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.quizCompletado, styles.logoFlexBox1]}>
      <View style={styles.contenido}>
        <View style={[styles.logo, styles.logoFlexBox]}>
          <Pressable style={styles.volver} onPress={() => navigation.goBack()}>
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/volver.png")}
            />
          </Pressable>
          <ImageBackground
            style={styles.logoIcon}
            resizeMode="center"
            source={require("../assets/logo.png")}
          />
          <Image
            style={styles.notificationsIcon}
            contentFit="cover"
            source={require("../assets/notifications.png")}
          />
        </View>
        <ScrollView
          style={styles.interactuable}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.interactuableScrollViewContent}
        >
          <View style={[styles.iniciaSesion, styles.ilustracionFlexBox]}>
            <Text style={[styles.titulo, styles.textoFlexBox]}>
              ¡Felicitaciones! Completaste el Test
            </Text>
          </View>
          <View style={[styles.explicacion, styles.logoFlexBox]}>
            <Text
              style={[styles.texto, styles.textoFlexBox]}
            >{`😊 Con tu info, vamos a encontrar el Zico perfecto para ti, para que chatear sea aún más agradable
¡Recibirás tus resultados por correo!`}</Text>
          </View>
          <View style={[styles.ilustracion, styles.ilustracionFlexBox]}>
            <ImageBackground
              style={styles.artboard222}
              resizeMode="cover"
              source={require("../assets/artboard222.png")}
            />
          </View>
          <Pressable
            style={styles.finalizarTest}
            onPress={() =>
              navigation.navigate("DrawerRoot", { screen: "BottomTabsRoot" })
            }
          >
            <Property1Default3
              texto="Volver al inicio"
              property1DefaultPosition="unset"
              property1DefaultAlignSelf="stretch"
              property1DefaultBackgroundColor="#ffd7f3"
              textoFlex={1}
              onIniciarSesinPress={() =>
                navigation.navigate("DrawerRoot", { screen: "BottomTabsRoot" })
              }
            />
          </Pressable>
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  interactuableScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  logoFlexBox1: {
    justifyContent: "space-between",
    alignItems: "center",
  },
  logoFlexBox: {
    flexDirection: "row",
    alignSelf: "stretch",
  },
  ilustracionFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  textoFlexBox: {
    textAlign: "left",
    color: Color.colorGray_200,
    flex: 1,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  volver: {
    width: 15,
    height: 22,
  },
  logoIcon: {
    width: 40,
    height: 45,
  },
  notificationsIcon: {
    width: 25,
    height: 27,
  },
  logo: {
    justifyContent: "space-between",
    alignItems: "center",
  },
  titulo: {
    fontSize: FontSize.size_11xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
  },
  iniciaSesion: {
    flexDirection: "row",
    alignSelf: "stretch",
  },
  texto: {
    fontSize: FontSize.size_lg,
    fontFamily: FontFamily.poppinsRegular,
  },
  explicacion: {
    marginTop: 20,
    alignItems: "center",
  },
  artboard222: {
    width: 372,
    height: 246,
  },
  ilustracion: {
    marginTop: 20,
  },
  finalizarTest: {
    marginTop: 20,
    alignSelf: "stretch",
    alignItems: "center",
  },
  interactuable: {
    marginTop: 20,
    alignSelf: "stretch",
    flex: 1,
  },
  contenido: {
    paddingHorizontal: Padding.p_xl,
    paddingVertical: 0,
    alignSelf: "stretch",
    alignItems: "center",
  },
  quizCompletado: {
    backgroundColor: Color.colorsNeutralWhite,
    height: 873,
    paddingTop: Padding.p_27xl,
    paddingBottom: Padding.p_xl,
    width: "100%",
    flex: 1,
  },
});

export default QuizCompletado;
