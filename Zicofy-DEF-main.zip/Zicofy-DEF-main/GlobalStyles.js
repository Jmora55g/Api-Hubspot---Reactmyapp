/* fonts */
export const FontFamily = {
  poppinsLight: "Poppins-Light",
  poppinsSemiBold: "Poppins-SemiBold",
  poppinsRegular: "Poppins-Regular",
  poppinsBold: "Poppins-Bold",
  poppinsMedium: "Poppins-Medium",
  epilogueExtraBold: "Epilogue-ExtraBold",
  epilogueRegular: "Epilogue-Regular",
  poppinsExtraBold: "Poppins-ExtraBold",
  epilogueBold: "Epilogue-Bold",
  interSemiBold: "Inter-SemiBold",
};
/* font sizes */
export const FontSize = {
  size_sm: 14,
  size_mid: 17,
  size_lg: 18,
  size_11xl: 30,
  size_base: 16,
  size_3xl: 22,
  size_mini: 15,
  size_3xs: 10,
  size_xl: 20,
};
/* Colors */
export const Color = {
  colorGray_100: "#797c7b",
  colorGray_200: "#292929",
  colorGray_500: "#371b34",
  colorGray_400: "#000e08",
  colorThistle: "#ffd7f3",
  colorsNeutralWhite: "#fff",
  colorLightskyblue: "#74c2ef",
  colorSalmon: "#f86969",
  colorGainsboro: "#e6e4ea",
  colorWhitesmoke_200: "#f4f4f7",
  colorWhitesmoke_100: "#f4f3f1",
  colorWhitesmoke_300: "#eaeaea",
  colorIndianred: "rgba(208, 74, 74, 0.03)",
  colorBlack: "#000",
  colorDimgray_200: "#573927",
};
/* Paddings */
export const Padding = {
  p_xl: 20,
  p_27xl: 46,
  p_10xl: 29,
  p_sm: 14,
  p_11xl: 30,
  p_3xs: 10,
  p_mini: 15,
  p_8xs: 5,
  p_31xl: 50,
  p_3xl: 22,
  p_6xl: 25,
};
/* border radiuses */
export const Border = {
  br_6xl: 25,
  br_mini: 15,
  br_xl: 20,
  br_61xl: 80,
  br_12xl: 31,
  br_11xl: 30,
};
